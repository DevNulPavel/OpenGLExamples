#import "OpenGLRenderer.h"
#import "matrixUtil.h"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"


#define GetGLError(){                                   \
	GLenum err = glGetError();							\
	while (err != GL_NO_ERROR) {						\
		NSLog(@"GLError %s set in File:%s Line:%d\n",	\
				GetGLErrorString(err),					\
				__FILE__,								\
				__LINE__);								\
		err = glGetError();								\
	}													\
}

enum {
	POS_ATTRIB_IDX = 0,
	NORMAL_ATTRIB_IDX = 1,
	TEXCOORD_ATTRIB_IDX = 2
};

#ifndef NULL
#define NULL 0
#endif

#define BUFFER_OFFSET(i) ((char *)NULL + (i))



static GLsizei GetGLTypeSize(GLenum type){
    switch (type) {
        case GL_BYTE:
            return sizeof(GLbyte);
        case GL_UNSIGNED_BYTE:
            return sizeof(GLubyte);
        case GL_SHORT:
            return sizeof(GLshort);
        case GL_UNSIGNED_SHORT:
            return sizeof(GLushort);
        case GL_INT:
            return sizeof(GLint);
        case GL_UNSIGNED_INT:
            return sizeof(GLuint);
        case GL_FLOAT:
            return sizeof(GLfloat);
    }
    return 0;
}


@implementation OpenGLRenderer

demoModel* _characterModel;
GLfloat _characterAngle;
GLint _lightX;
GLint _lightY;
GLint _lightZ;
GLuint _viewWidth;
GLuint _viewHeight;

GLuint _characterShaderProgram;
GLuint _characterVertexAttObject;
GLuint _characterTexureObject;
GLuint _characterNormalsObject;
GLuint _shadowProgram;

GLuint _defaultFBO;

GLint _characterMvpMatrixLocation;
GLint _characterModelViewLocation;
GLint _characterNormalMatrixLocation;
GLint _characterLightPosLocation;
GLint _characterTextureLocation;
GLint _characterNormalsTextureLocation;


- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);

	_viewWidth = width;
	_viewHeight = height;
}

- (void) render {

    // очистим буфферы для отображения
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// включаем шейдер для отрисовки
	glUseProgram(_characterShaderProgram);
	
	// вычислим матрицу проекции в массив projection
    GLfloat projection[16];
	mtxLoadPerspective(projection, 90, (float)_viewWidth / (float)_viewHeight, 5.0, 10000);
	
	// обновляем матрицу модели
    GLfloat modelView[16];
	mtxLoadTranslate(modelView, 0, 0, -400);  // матрица с помещением модели в нужное место
	mtxRotateApply(modelView, _characterAngle, 0, 1, 0);   // крутим модель по таймеру
    mtxRotateApply(modelView, -90.0, 1, 0, 0);              // постоянный поворот модели, чтобы нормально смотреть на нее
	
	// умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    GLfloat mvp[16];
    mtxMultiply(mvp, projection, modelView);
    
    // создаем матрицу для нормалей
    GLfloat srcNormal[9];
    mtx3x3FromTopLeftOf4x4(srcNormal, modelView);
    GLfloat inverseRes[9];
    mtx3x3Invert(inverseRes, srcNormal);
    GLfloat normalMatrix[9];
    mtx3x3Transpose(normalMatrix, inverseRes);
    
	// помещаем матрицу модельвидпроекция в шейдер (указываем)
	glUniformMatrix4fv(_characterMvpMatrixLocation, 1, GL_FALSE, mvp);
    // матрица модели вида
    glUniformMatrix4fv(_characterModelViewLocation, 1, GL_FALSE, modelView);
    // помещаем матрицу нормалей в шейдер (указываем)
    glUniformMatrix3fv(_characterNormalMatrixLocation, 1, GL_FALSE, normalMatrix);
    // указываем позицию света
    glUniform3f(_characterLightPosLocation, _lightX, _lightY, _lightZ);
    
    // текстура модели
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _characterTexureObject);
    glUniform1i(_characterTextureLocation, 0);
    
    // карта нормалей
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, _characterNormalsObject);
    glUniform1i(_characterNormalsTextureLocation, 1);
    
    
	// включаем объект аттрибутов вершин
	glBindVertexArray(_characterVertexAttObject);
	
	// порядок отрисовки
	glCullFace(GL_BACK);
	
	// отрисовка персонажа по индексами
    glDrawElements(GL_TRIANGLES, _characterModel->numElements, _characterModel->elementType, 0);
	
	// увеличиваем угол поворота персонажа
	_characterAngle++;
}


// создание объекта аттрибутов вершин
- (GLuint) buildVAO:(demoModel*)model {
	GLuint vaoName = 0;
	
	// создание 1го объекта
	glGenVertexArrays(1, &vaoName);
    // включаем работу с этим объектом
	glBindVertexArray(vaoName);

    // буффер позиций вершин
    GLuint posBufferObj = 0;
    
    // создаем буффер вершин
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    
    // подгружаем данные, которые будут использоваться для вершин
    glBufferData(GL_ARRAY_BUFFER, model->positionArraySize, model->positions, GL_STATIC_DRAW);
    
    // включаем работу с индексами вершин
    glEnableVertexAttribArray(POS_ATTRIB_IDX);
    
    // размер в байтах каждой вершины
    GLsizei posTypeSize = GetGLTypeSize(model->positionType);
    
    // теперь указываем формат в данных
    glVertexAttribPointer(POS_ATTRIB_IDX,		// индекс аттрибута в шейдере
                          model->positionSize,	// из скольки элементов состоит (вершина из 3х значений)
                          model->positionType,	// тип данных
                          GL_FALSE,				// данные не являются нормализованными
                          model->positionSize*posTypeSize, // шаг между отдельными элементами в байтах 3*sizeof(float)
                          BUFFER_OFFSET(0));	// данные с нулевым оффсетом
    
    
    // есть ли нормали????
    if(model->normals) {
        GLuint normalBufferName = 0;
        
        // создаем буффер объект для нормалей
        glGenBuffers(1, &normalBufferName);
        glBindBuffer(GL_ARRAY_BUFFER, normalBufferName);
        
        // выделяем память и подгружаем данные нормалей
        glBufferData(GL_ARRAY_BUFFER, model->normalArraySize, model->normals, GL_STATIC_DRAW);
        
        // включаем работу с нормалями каждой вершины
        glEnableVertexAttribArray(NORMAL_ATTRIB_IDX);
        
        // вычисляем размер каждой отдельной нормали
        GLsizei normalTypeSize = GetGLTypeSize(model->normalType);
        
        glVertexAttribPointer(NORMAL_ATTRIB_IDX,	// What attibute index will this array feed in the vertex shader (see buildProgram)
                              model->normalSize,	// How many elements are there per normal?
                              model->normalType,	// What is the type of this data?
                              GL_FALSE,				// Do we want to normalize this data (0-1 range for fixed-pont types)
                              model->normalSize*normalTypeSize, // What is the stride (i.e. bytes between normals)?
                              BUFFER_OFFSET(0));	// What is the offset in the VBO to the normal data?
    }
    
    // все то же самое для текстурных координат
    if(model->texcoords) {
        GLuint texcoordBufferName;
        
        glGenBuffers(1, &texcoordBufferName);
        glBindBuffer(GL_ARRAY_BUFFER, texcoordBufferName);
        
        glBufferData(GL_ARRAY_BUFFER, model->texcoordArraySize, model->texcoords, GL_STATIC_DRAW);
        
        glEnableVertexAttribArray(TEXCOORD_ATTRIB_IDX);
        
        GLsizei texcoordTypeSize = GetGLTypeSize(model->texcoordType);
        
        glVertexAttribPointer(TEXCOORD_ATTRIB_IDX,	// What attibute index will this array feed in the vertex shader (see buildProgram)
                              model->texcoordSize,	// How many elements are there per texture coord?
                              model->texcoordType,	// What is the type of this data in the array?
                              GL_TRUE,				// Do we want to normalize this data (0-1 range for fixed-point types)
                              model->texcoordSize*texcoordTypeSize,  // What is the stride (i.e. bytes between texcoords)?
                              BUFFER_OFFSET(0));	// What is the offset in the VBO to the texcoord data?
    }
    
    GLuint elementBufferName;	
    
    // создание буффера индексов
    glGenBuffers(1, &elementBufferName);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferName);
    
    // выделяем и подгружаем
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, model->elementArraySize, model->elements, GL_STATIC_DRAW);
	
	GetGLError();
	
	return vaoName;
}

-(void)destroyVAO:(GLuint) vaoName{
	GLuint index;
	GLuint bufName;
	
	// включаем работу с объектом буффера вершин
	glBindVertexArray(vaoName);
	
	// удаляем все доступные подбуфферы
	for(index = 0; index < 16; index++) {
		glGetVertexAttribiv(index , GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
		
		if(bufName) {
			glDeleteBuffers(1, &bufName);
		}
	}
	
	// дергаем буффер индексов
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
	
    // уничтожаем, если есть
	if(bufName){
		glDeleteBuffers(1, &bufName);
	}
	
    // удаляем сам буффер аттрибутов
	glDeleteVertexArrays(1, &vaoName);
	
	GetGLError();
}

// создание объекта текстуры
-(GLuint) buildTexture:(demoImage*) image {
	GLuint texName;
	
	// создаем объект
	glGenTextures(1, &texName);
	glBindTexture(GL_TEXTURE_2D, texName);
	
	// настраиваем характеристики
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	
	// Indicate that pixel rows are tightly packed 
	//  (defaults to stride of 4 which is kind of only good for
	//  RGBA or FLOAT data types)
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	
	// выделяем память на видеокарте и подгружаем эти данные
	glTexImage2D(GL_TEXTURE_2D, 0, image->format, image->width, image->height, 0,
				 image->format, image->type, image->data);

	// создаем мипмапы текстуры
	glGenerateMipmap(GL_TEXTURE_2D);
	
	GetGLError();
	
	return texName;
}

// удалить присоединенные текстуры из буффера кадра
-(void) deleteFBOAttachment:(GLenum) attachment {
    GLint param;
    GLuint objName;
	
    glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER, attachment,
                                          GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
                                          &param);
	
    if(GL_RENDERBUFFER == param) {
        glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER, attachment,
                                              GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
                                              &param);
		
        objName = ((GLuint*)(&param))[0];
        glDeleteRenderbuffers(1, &objName);
    }
    else if(GL_TEXTURE == param){
        glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER, attachment,
                                              GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
                                              &param);
		
        objName = ((GLuint*)(&param))[0];
        glDeleteTextures(1, &objName);
    }
    
}

-(void) destroyFBO:(GLuint) fboName {
	if(0 == fboName) {
		return;
	}
    
    glBindFramebuffer(GL_FRAMEBUFFER, fboName);
    GLint maxColorAttachments = 1;
	glGetIntegerv(GL_MAX_COLOR_ATTACHMENTS, &maxColorAttachments);
	
	GLint colorAttachment;
    for(colorAttachment = 0; colorAttachment < maxColorAttachments; colorAttachment++) {
		[self deleteFBOAttachment:(GL_COLOR_ATTACHMENT0+colorAttachment)];
	}
	
	// удаляем буффер глубины
    [self deleteFBOAttachment:GL_DEPTH_ATTACHMENT];
	// и маски
    [self deleteFBOAttachment:GL_STENCIL_ATTACHMENT];
	
    glDeleteFramebuffers(1,&fboName);
}

// создание шейдерной программы
-(GLuint) buildProgramWithVertexSource:(demoSource*)vertexSource
					withFragmentSource:(demoSource*)fragmentSource
							withNormal:(BOOL)hasNormal
						  withTexcoord:(BOOL)hasTexcoord
{
	GLuint prgName;
	
	GLint logLength, status;
	
	// строка
	GLchar* sourceString = NULL;  
	
    // определяем версию языка, которая доступна
	float  glLanguageVersion;
	
	sscanf((char *)glGetString(GL_SHADING_LANGUAGE_VERSION), "%f", &glLanguageVersion);
	
	GLuint version = 100 * glLanguageVersion;
	
	// Get the size of the version preprocessor string info so we know 
	//  how much memory to allocate for our sourceString
	const GLsizei versionStringSize = sizeof("#version 123\n");
	
	// создание объекта программы
	prgName = glCreateProgram();
	
    // задаем соответствие названия в шейдере и аттрибутов вершин
	glBindAttribLocation(prgName, POS_ATTRIB_IDX, "inPosition");
	if(hasNormal) {
		glBindAttribLocation(prgName, NORMAL_ATTRIB_IDX, "inNormal");
	}
	if(hasTexcoord) {
		glBindAttribLocation(prgName, TEXCOORD_ATTRIB_IDX, "inTexcoord");
	}
	
	/////////////////////////////////
	// создание вершинного шейдера //
	/////////////////////////////////
	
	// выделяем память под строку версии шейдера
	sourceString = malloc(vertexSource->byteSize + versionStringSize);
	
	// добавляем версию к шейдеру
	sprintf(sourceString, "#version %d\n%s", version, vertexSource->string);
	
    // создаем вершинный шейдер
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);	
	glShaderSource(vertexShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(vertexShader);
	glGetShaderiv(vertexShader, GL_INFO_LOG_LENGTH, &logLength);
	
    // инфа
	if (logLength > 0) {
		GLchar *log = (GLchar*) malloc(logLength);
		glGetShaderInfoLog(vertexShader, logLength, &logLength, log);
		NSLog(@"Vtx Shader compile log:%s\n", log);
		free(log);
	}
	
    // лог компиляции
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile vtx shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// подсоединяем вершинный шейдер к обхекту программы
	glAttachShader(prgName, vertexShader);
	
	// удаляем шейдер, тк он уже присоединен к программе
	glDeleteShader(vertexShader);
	
	////////////////////////
	// фрагментный шейдер //
	////////////////////////
	
	// выделяем память под версию
	sourceString = malloc(fragmentSource->byteSize + versionStringSize);
	
	// добавляем версию в текст
	sprintf(sourceString, "#version %d\n%s", version, fragmentSource->string);
	
    // фрагментный шейдер
	GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);	
	glShaderSource(fragShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(fragShader);
	glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0) {
		GLchar *log = (GLchar*)malloc(logLength);
		glGetShaderInfoLog(fragShader, logLength, &logLength, log);
		NSLog(@"Frag Shader compile log:\n%s\n", log);
		free(log);
	}
	
	glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile frag shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// присоединяем фрагментный к программе
	glAttachShader(prgName, fragShader);
	
	// удаляем, тк присоединен
	glDeleteShader(fragShader);
	
	//////////////////////
	// сборка программы //
	//////////////////////
	
	glLinkProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0){
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program link log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_LINK_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to link program");
		return 0;
	}
	
    // проверка на валидность
	glValidateProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0)
	{
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program validate log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_VALIDATE_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to validate program");
		return 0;
	}
	
	// включаем данную программу
	glUseProgram(prgName);
	
	///////////////////////////////////////
	// устанавливаем текстуру по умолчанию - 0 //
	///////////////////////////////////////
	
	GLint samplerLoc = glGetUniformLocation(prgName, "diffuseTexture");
	
	// Indicate that the diffuse texture will be bound to texture unit 0
	GLint unit = 0;
	glUniform1i(samplerLoc, unit);
	
	GetGLError();
	
	return prgName;
	
}

- (id) init {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
		
		_viewWidth = 640;
		_viewHeight = 480;
		
        _lightX = 300;
        _lightY = 300;
        _lightZ = -100;
		
		_characterAngle = 0;
        
        _defaultFBO = 0;
		
		NSString* filePathName = nil;

		//////////////////////////////
		// модель //
		//////////////////////////////
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"demon" ofType:@"model"];
		_characterModel = mdlLoadModel([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		// на основании модели создаем обхект аттрибутов вершин
		_characterVertexAttObject = [self buildVAO:_characterModel];
				
		//////////////
		// текстура //
		//////////////
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"demon" ofType:@"png"];
		demoImage *image = imgLoadImage([filePathName cStringUsingEncoding:NSASCIIStringEncoding], false);
		
		// текстурный объект
		_characterTexureObject = [self buildTexture:image];
		imgDestroyImage(image);
        
        filePathName = [[NSBundle mainBundle] pathForResource:@"demon_normals" ofType:@"png"];
        demoImage *normalsImage = imgLoadImage([filePathName cStringUsingEncoding:NSASCIIStringEncoding], false);
        
        // текстурный объект
        _characterNormalsObject = [self buildTexture:normalsImage];
        imgDestroyImage(normalsImage);
	
		
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
		
		demoSource* vtxSource = NULL;
		demoSource* frgSource = NULL;
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"vsh"];
		vtxSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"fsh"];
		frgSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		_characterShaderProgram = [self buildProgramWithVertexSource:vtxSource
											 withFragmentSource:frgSource
													 withNormal:TRUE
												   withTexcoord:TRUE];
		
		srcDestroySource(vtxSource);
		srcDestroySource(frgSource);
		
        // дергаем юниформы
		_characterMvpMatrixLocation = glGetUniformLocation(_characterShaderProgram, "modelViewProjectionMatrix");
        _characterModelViewLocation = glGetUniformLocation(_characterShaderProgram, "modelViewMatrix");
		_characterNormalMatrixLocation = glGetUniformLocation(_characterShaderProgram, "normalMatrix");
        _characterLightPosLocation = glGetUniformLocation(_characterShaderProgram, "lightPos");
        _characterTextureLocation = glGetUniformLocation(_characterShaderProgram, "diffuseTexture");
        _characterNormalsTextureLocation = glGetUniformLocation(_characterShaderProgram, "normalsTexture");
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
		// включаем тест глубины
		glEnable(GL_DEPTH_TEST);
	
		// отрисовываем только передние части
		glEnable(GL_CULL_FACE);
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		
		// Reset the m_characterAngle which is incremented in render
		_characterAngle = 0;
		
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}


- (void) dealloc {
	// Cleanup all OpenGL objects and 
	glDeleteTextures(1, &_characterTexureObject);
	
	[self destroyVAO:_characterVertexAttObject];

	glDeleteProgram(_characterShaderProgram);

	mdlDestroyModel(_characterModel);
    
	[super dealloc];	
}

@end
