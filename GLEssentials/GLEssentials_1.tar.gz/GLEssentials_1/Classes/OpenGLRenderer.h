#include "glUtil.h"
#import <Foundation/Foundation.h>

@interface OpenGLRenderer : NSObject {

}

- (id) init;
- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void) render;
- (void) dealloc;

@end
