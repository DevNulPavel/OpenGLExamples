//
//  ObjModel.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 10.04.15.
//
//

#import <Foundation/Foundation.h>
#import "glUtil.h"
#import "glm.hpp"
#import "ext.hpp"
#import <vector>

using namespace std;

struct Buffer{
    uint bufferId;
    size_t bufferSize;
    Buffer(){
        bufferId = -1;
        bufferSize = 0;
    }
    Buffer(uint buffId, size_t size){
        bufferId = buffId;
        bufferSize = size;
    }
};

GLuint buildObjVAO(NSString* filename, int *elementsCount);
GLuint buildObjVAO(NSString* filename, int *elementsCount, vector<Buffer>& buffers, BOOL withCache);
