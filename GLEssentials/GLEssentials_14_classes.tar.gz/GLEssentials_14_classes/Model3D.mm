//
//  Model3D.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "Model3D.h"
#import "GlobalValues.h"
#import "ObjModelVAO.h"
#import "VAOCreate.h"
#import "TextureCreate.h"
#import "ShaderCreate.h"
#import "GlobalValues.h"

@implementation Model3D

-(id)initWithObjFilename:(NSString *)filename{
    if ((self = [super init])) {
        _modelVAO = buildObjVAO(filename, &_modelPointsCount);
        _modelTexture = buildTexture(filename);
        _normalsTexture = buildTexture([NSString stringWithFormat:@"%@_normals", filename]);

        [self generateShader];
    }
    return self;
}

-(id)initWithFilename:(NSString *)filename{
    if ((self = [super init])) {
        _modelVAO = buildModelVAO(&_modelElementsCount, &_modelElementsType);
        _modelTexture = buildTexture(filename);
        _normalsTexture = buildTexture([NSString stringWithFormat:@"%@_normals", filename]);
        
        [self generateShader];
    }
    return self;
}

-(void)generateShader{
    // модель
    _shaderProgram = buildProgramFunc();
    _mvpMatrixLocation = glGetUniformLocation(_shaderProgram, "u_mvpMatrix");
    _mvMatrixLocation = glGetUniformLocation(_shaderProgram, "u_mvMatrix");
    _projMatrixLocation = glGetUniformLocation(_shaderProgram, "u_projectionMatrix");
    _viewMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_viewMatrix");
    _modelMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_modelMatrix");
    _inShadowMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_toShadowMapMatrix");
    _lightPosLocation = glGetUniformLocation(_shaderProgram, "u_cameraSpaceLightPos");
    _modelTextureLocation = glGetUniformLocation(_shaderProgram, "u_texture");
    _shadowMapTextureLocation = glGetUniformLocation(_shaderProgram, "u_shadowMapTexture");
    _normalsTextureLocation = glGetUniformLocation(_shaderProgram, "u_normalsTexture");
}

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 modelMat = [self modelTransformMatrix];
    
    // вид из точки света
    mat4 shadowCamera = lookAt(light.lightPos, light.lightTargetPos, vec3(0.0, 1.0, 0.0));
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [cameraObj cameraMatrix];
    }else{
        camera = shadowCamera;
    }
    
    // проекция
    mat4 projection = [self projectionMatrix];
    
    mat4 mv = camera * modelMat;
    mat4 mvp = projection * mv;
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 shadowMvp = projection * shadowCamera * modelMat;
    
    // вектор света
    mat4 lightTranslate;
    lightTranslate = translate(lightTranslate, light.lightPos);
    vec4 cameraSpaceLightPos = [cameraObj cameraMatrix] * vec4(light.lightPos, 1.0);
    
    // включаем шейдер для отрисовки
    glUseProgram(_shaderProgram);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_mvpMatrixLocation, 1, GL_FALSE, value_ptr(mvp));
    glUniformMatrix4fv(_mvMatrixLocation, 1, GL_FALSE, value_ptr(mv));
    glUniformMatrix4fv(_modelMatrixLocation, 1, GL_FALSE, value_ptr(modelMat));
    glUniformMatrix4fv(_viewMatrixLocation, 1, GL_FALSE, value_ptr(camera));
    glUniformMatrix4fv(_projMatrixLocation, 1, GL_FALSE, value_ptr(projection));
    glUniformMatrix4fv(_inShadowMatrixLocation, 1, GL_FALSE, value_ptr(shadowMvp));
    glUniform3f(_lightPosLocation, cameraSpaceLightPos.x, cameraSpaceLightPos.y, cameraSpaceLightPos.z);
    
    if (toShadowMap == FALSE) {
        // текстура модели
        glUniform1i(_modelTextureLocation, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, _modelTexture);
        
        // текстура тени
        glUniform1i(_shadowMapTextureLocation, 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, GlobI.shadowMapTexture);
        
        // текстура тени
        glUniform1i(_normalsTextureLocation, 2);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 0);
        glUniform1i(_normalsTextureLocation, 0);
    }
    
    // включаем объект аттрибутов вершин
    glBindVertexArray(_modelVAO);
    if (_modelElementsCount > 0) {
        glDrawElements(GL_TRIANGLES, _modelElementsCount, _modelElementsType, 0);
    }else{
        glDrawArrays(GL_TRIANGLES, 0, _modelPointsCount);
    }
    glBindVertexArray(0);
}

-(void)dealloc{
    destroyVAO(_modelVAO);
    glDeleteProgram(_shaderProgram);
    // TODO: удаление текстур
    [super dealloc];
}

@end