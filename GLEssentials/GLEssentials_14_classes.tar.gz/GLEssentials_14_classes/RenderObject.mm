//
//  RenderObject.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import <Foundation/Foundation.h>
#import "RenderObject.h"
#import "GlobalValues.h"

@implementation RenderObject

-(id)init{
    if ((self = [super init])) {
        [self setDefaultValues];
    }
    return self;
}

-(void)setDefaultValues{
    self.modelPos = vec3(0.0);
    self.staticRotation = mat4(1.0);
}

-(void)renderModelFromCamera:(Camera*)camera light:(LightObject*)light toShadow:(BOOL)toShadowMap{
}

-(mat4)modelTransformMatrix{
    mat4 modelMat;
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    modelMat = translate(modelMat, self.modelPos);
    modelMat = rotate(modelMat, float(self.xRotate), vec3(1.0, 0.0, 0.0));
    modelMat = rotate(modelMat, float(self.yRotate), vec3(0.0, 1.0, 0.0));
    modelMat = rotate(modelMat, float(self.zRotate), vec3(0.0, 0.0, 1.0));
    modelMat = modelMat * self.staticRotation;
    modelMat = scale(modelMat, vec3(self.scale));

    return modelMat;
}

-(mat4)projectionMatrix{
    mat4 projection = perspective(45.0f, float((float)GlobI.viewWidth / (float)GlobI.viewHeight), GlobI.zNear, GlobI.zFar);
    return projection;
}

@end