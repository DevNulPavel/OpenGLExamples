#import <Foundation/Foundation.h>
#import "glUtil.h"
#import "Camera.h"
#import "Model3D.h"
#import "LightObject.h"
#import "CubeModel.h"
#import "ParticlesModel.h"
#import "BillboardModel.h"

@interface OpenGLRenderer : NSObject {

}

@property (nonatomic, retain) Camera* camera;
@property (nonatomic, retain) LightObject* light;
@property (nonatomic, retain) NSMutableArray* models;
@property (nonatomic, retain) NSMutableArray* billboards;
@property (nonatomic, retain) CubeModel* pointingCube;


- (id) initWithWidth:(int)width height:(int)height;
- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void) render;
- (void) dealloc;

@end
