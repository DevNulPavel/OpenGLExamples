
#import <Cocoa/Cocoa.h>

@interface GLEssentialsFullscreenWindow : NSWindow

@end
