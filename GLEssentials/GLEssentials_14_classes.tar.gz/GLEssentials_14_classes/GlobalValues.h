//
//  GlobalValues.h
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "glUtil.h"
#import "glm.hpp"
#import "ext.hpp"

using namespace glm;


// random integer in [mn, mx)
int random_int(int mn, int mx);
float randomFloat(float mn, float mx);



#define GlobI [GlobalValues instance]

@interface GlobalValues: NSObject{
    double _initTime;
}

+ (GlobalValues *)instance;
-(float)timeFromStart;
-(float)angle;

@property (nonatomic, assign) vec3 cameraInitPos;
@property (nonatomic, assign) vec3 worldSize;
@property (nonatomic, assign) float zNear;
@property (nonatomic, assign) float zFar;

@property (nonatomic, assign) float viewWidth;
@property (nonatomic, assign) float viewHeight;

@property (nonatomic, assign) vec3 lookTargetPos;

// буффера и текстуры
@property (nonatomic, assign) GLuint shadowRenderFBO;
@property (nonatomic, assign) GLuint shadowMapTexture;

@end
