//
//  Model3D.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "CubeModel.h"
#import "GlobalValues.h"
#import "ObjModelVAO.h"
#import "VAOCreate.h"
#import "TextureCreate.h"
#import "ShaderCreate.h"
#import "GlobalValues.h"

@implementation CubeModel

-(id)init{
    if ((self = [super init])) {
        _cubeVAO = cubeVAO(&_cubeElementsCount);
        
        [self setDefaultValues];
        [self generateShader];
    }
    return self;
}

-(void)setDefaultValues{
    self.modelPos = vec3(0.0);
    self.staticRotation = mat4(1.0);
}

-(void)generateShader{
    // куб
    _cubeShader = buildCubeProgram();
    _cubeMVPLocation = glGetUniformLocation(_cubeShader, "u_mvp");
}

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)    
    mat4 model = [self modelTransformMatrix];
    
    mat4 camera = [cameraObj cameraMatrix];
    
    // вычислим матрицу проекции в массив projection
    mat4 projection = [self projectionMatrix];
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 mvp = projection * camera * model;
    
    glUseProgram(_cubeShader);
    
    glUniformMatrix4fv(_cubeMVPLocation, 1, GL_FALSE, value_ptr(mvp));
    
    glBindVertexArray(_cubeVAO);
    glDrawElements(GL_TRIANGLES, _cubeElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

-(void)dealloc{
    destroyVAO(_cubeVAO);
    glDeleteProgram(_cubeShader);
    // TODO: удаление текстур
    [super dealloc];
}

@end