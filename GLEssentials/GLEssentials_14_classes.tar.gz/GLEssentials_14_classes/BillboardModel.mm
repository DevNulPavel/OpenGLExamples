//
//  Model3D.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "BillboardModel.h"
#import "GlobalValues.h"
#import "ObjModelVAO.h"
#import "VAOCreate.h"
#import "TextureCreate.h"
#import "ShaderCreate.h"
#import "GlobalValues.h"

@implementation BillboardModel

-(id)initWithPositions:(std::vector<vec3>) positions{
    if ((self = [super init])) {
        _billboardPointVAO = billboardVAO(positions);    // создается толкьо одна точка, но можно сколько угодно для частиц
        _billboardPointCount = positions.size();
        _billboardTexture = buildTexture(@"monster_hellknight");
        
        [self generateShader];
    }
    return self;
}

-(id)initOne{
    if ((self = [super init])) {
        std::vector<vec3> vector;
        vector.push_back(vec3(0.0));
        _billboardPointVAO = billboardVAO(vector);    // создается толкьо одна точка, но можно сколько угодно для частиц
        _billboardPointCount = 1;
        _billboardTexture = buildTexture(@"monster_hellknight");
        
        [self generateShader];
    }
    return self;
}

-(void)generateShader{
    // билборд
    _billboardShaderProgram = buildBillboardProgram();
    _billboardModelLocation = glGetUniformLocation(_billboardShaderProgram, "u_model");
    _billboardViewlLocation = glGetUniformLocation(_billboardShaderProgram, "u_view");
    _billboardProjLocation = glGetUniformLocation(_billboardShaderProgram, "u_proj");
    _billboardTextureLocation = glGetUniformLocation(_billboardShaderProgram, "u_texture");
    _billboardCameraPosLocation = glGetUniformLocation(_billboardShaderProgram, "u_cameraPosWorld");
}

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap{
    if (toShadowMap) {
        return;
    }
    
    mat4 model = [self modelTransformMatrix];
    mat4 camera = [cameraObj cameraMatrix];
    mat4 projection = [self projectionMatrix];
    
    glUseProgram(_billboardShaderProgram);
    
    // матрица
    glUniformMatrix4fv(_billboardModelLocation, 1, GL_FALSE, value_ptr(model));
    glUniformMatrix4fv(_billboardViewlLocation, 1, GL_FALSE, value_ptr(camera));
    glUniformMatrix4fv(_billboardProjLocation, 1, GL_FALSE, value_ptr(projection));
    glUniform3f(_billboardCameraPosLocation, cameraObj.cameraPos.x, cameraObj.cameraPos.y, cameraObj.cameraPos.z);
    
    // текстура
    glUniform1i(_billboardTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _billboardTexture);
    
    glBindVertexArray(_billboardPointVAO);
    glDrawArrays(GL_POINTS, 0, _billboardPointCount);
    glBindVertexArray(0);
}

-(void)dealloc{
    destroyVAO(_billboardPointVAO);
    glDeleteProgram(_billboardShaderProgram);
    // TODO: удаление текстур
    [super dealloc];
}

@end