//
//  Model3D.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "SkyModel3D.h"
#import "GlobalValues.h"
#import "ObjModelVAO.h"
#import "VAOCreate.h"
#import "TextureCreate.h"
#import "ShaderCreate.h"
#import "GlobalValues.h"

@implementation SkyModel3D

-(id)initWithObjFilename:(NSString *)filename{
    if ((self = [super init])) {
        _modelVAO = buildObjVAO(filename, &_modelPointsCount);
        _modelTexture = buildTexture(filename);
        _normalsTexture = buildTexture([NSString stringWithFormat:@"%@_normals", filename]);

        [self setDefaultValues];
        [self generateShader];
    }
    return self;
}

-(id)initWithFilename:(NSString *)filename{
    if ((self = [super init])) {
        _modelVAO = buildModelVAO(&_modelElementsCount, &_modelElementsType);
        _modelTexture = buildTexture(filename);
        _normalsTexture = buildTexture([NSString stringWithFormat:@"%@_normals", filename]);
        
        [self setDefaultValues];
        [self generateShader];
    }
    return self;
}

-(void)setDefaultValues{
    self.modelPos = vec3(0.0);
    self.staticRotation = mat4(1.0);
}

-(void)generateShader{
    _shaderProgram = buildSkyCharacter();
    _modelMatrixLocation = glGetUniformLocation(_shaderProgram, "u_modelMatrix");
    _viewMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_viewMatrix");
    _projMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_projectionMatrix");
    _modelTextureLocation = glGetUniformLocation(_shaderProgram, "u_texture");
    _normalsTextureLocation = glGetUniformLocation(_shaderProgram, "u_normalsTexture");
    _modelCubemapTextureLocation = glGetUniformLocation(_shaderProgram, "_modelSkyboxTextureLocation");
    _cameraPosLocation = glGetUniformLocation(_shaderProgram, "u_glSpaceCameraPos");
}

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap{
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 modelMat = [self modelTransformMatrix];

    // вид из точки света
    mat4 shadowCamera = lookAt(light.lightPos, light.lightTargetPos, vec3(0.0, 1.0, 0.0));
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [cameraObj cameraMatrix];
    }else{
        camera = shadowCamera;
    }

    // проекция
    mat4 projection = [self projectionMatrix];

    vec3 glSpaceCameraPos = [cameraObj cameraPos] / GlobI.worldSize;

    // включаем шейдер для отрисовки
    glUseProgram(_shaderProgram);

    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_modelMatrixLocation, 1, GL_FALSE, value_ptr(modelMat));
    glUniformMatrix4fv(_viewMatrixLocation, 1, GL_FALSE, value_ptr(camera));
    glUniformMatrix4fv(_projMatrixLocation, 1, GL_FALSE, value_ptr(projection));
    glUniform3f(_cameraPosLocation, glSpaceCameraPos.x, glSpaceCameraPos.y, glSpaceCameraPos.z);


    if (toShadowMap == FALSE) {
        // текстура
        glUniform1i(_modelTextureLocation, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, _modelTexture);
        
        // текстура нормалей
        glUniform1i(_normalsTextureLocation, 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
        
        // текстура куба
        glUniform1i(_modelCubemapTextureLocation, 2);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_CUBE_MAP, self.boxTexture);

    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_normalsTextureLocation, 0);
        glUniform1i(_modelCubemapTextureLocation, 0);
    }


    // включаем объект аттрибутов вершин
    glBindVertexArray(_modelVAO);
    if (_modelElementsCount > 0) {
        glDrawElements(GL_TRIANGLES, _modelElementsCount, _modelElementsType, 0);
    }else{
        glDrawArrays(GL_TRIANGLES, 0, _modelPointsCount);
    }
    glBindVertexArray(0);
}

-(void)dealloc{
    destroyVAO(_modelVAO);
    glDeleteProgram(_shaderProgram);
    // TODO: удаление текстур
    [super dealloc];
}

@end