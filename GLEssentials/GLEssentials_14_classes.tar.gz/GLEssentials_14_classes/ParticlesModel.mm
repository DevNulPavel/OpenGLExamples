//
//  Model3D.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "ParticlesModel.h"
#import "GlobalValues.h"
#import "ObjModelVAO.h"
#import "VAOCreate.h"
#import "TextureCreate.h"
#import "ShaderCreate.h"
#import "GlobalValues.h"

@implementation ParticlesModel

-(id)init{
    if ((self = [super init])) {
        _particlesVAO = particlesVAO(&_particlesPointsCount);
        
        [self generateShader];
    }
    return self;
}

-(void)setDefaultValues{
    self.modelPos = vec3(0.0);
    self.staticRotation = mat4(1.0);
}

-(void)generateShader{
    // частицы
    _particlesShader = buildParticlesProgram();
    _particlesTimeLocation = glGetUniformLocation(_particlesShader, "u_time");
    _particlesMVPLocation = glGetUniformLocation(_particlesShader, "u_mvp");
}

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 model = [self modelTransformMatrix];
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [cameraObj cameraMatrix];
    }else{
        camera = lookAt(light.lightPos, light.lightTargetPos, vec3(0.0, 1.0, 0.0));
    }
    
    // вычислим матрицу проекции в массив projection
    mat4 projection = perspective(45.0f, (float)GlobI.viewWidth/(float)GlobI.viewHeight, GlobI.zNear, GlobI.zFar);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 mvp = projection * camera * model;
    
    glUseProgram(_particlesShader);
    
    float time = [GlobI timeFromStart];
    glUniform1f(_particlesTimeLocation, time);
    
    glUniformMatrix4fv(_particlesMVPLocation, 1, GL_FALSE, value_ptr(mvp));
    
    glEnable(GL_POINT_SIZE);
    glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);
    
    glBindVertexArray(_particlesVAO);
    glDrawArrays(GL_POINTS, 0, _particlesPointsCount);
    glBindVertexArray(0);
    
    glDisable(GL_POINT_SIZE);
}

-(void)dealloc{
    destroyVAO(_particlesVAO);
    glDeleteProgram(_particlesShader);
    // TODO: удаление текстур
    [super dealloc];
}

@end