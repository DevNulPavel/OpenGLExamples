//
//  GlobalValues.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "GlobalValues.h"



// random integer in [mn, mx)
int random_int(int mn, int mx) {
    int diff = mx - mn;
    if (diff != 0) {
        return mn + rand() % diff;
    }
    return mn;
}

float randomFloat(float mn, float mx) {
    float rnd = (float)rand() / RAND_MAX;
    rnd *= mx - mn;
    rnd += mn;
    return rnd;
}



static GlobalValues *instance = nil;

@implementation GlobalValues

+ (GlobalValues *)instance {
    @synchronized(self) {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

-(id)init{
    if ((self = [super init])) {
        self.cameraInitPos = vec3(0.0, 0.0, 50.0);
        self.worldSize = vec3(1000.0);
        self.zNear = 1.0f;
        self.zFar = 10000.0f;
        
        self.lookTargetPos = vec3(0.0);
        
        _initTime = [[NSDate date] timeIntervalSince1970];
    }
    return self;
}

-(float)timeFromStart{
    return [[NSDate date] timeIntervalSince1970] - _initTime;
}

-(float)angle{
    // полный оборот в 10 сек
    float time = 10.0;
    float angle = fmod([self timeFromStart] * M_PI * 2 / time, M_PI*2);;
    return angle;
}

@end