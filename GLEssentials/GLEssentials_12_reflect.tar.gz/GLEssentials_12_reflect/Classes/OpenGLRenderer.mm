#import "OpenGLRenderer.h"
#import "glm.hpp"
#import "ext.hpp"
#import "matrixUtil.h"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"
#import "VAOCreate.h"
#import "ShaderCreate.h"
#import "TextureCreate.h"
#import "FrameBufferCreate.h"

#ifndef NULL
#define NULL 0
#endif

using namespace glm;

@implementation OpenGLRenderer

const vec3 _cameraPos(0.0, 0.0, 0.0);
const vec3 _worldSize(1000.0);
const float _zNear = 1.0f;
const float _zFar = 100000.0f;

double _initTime;
GLfloat _angle = 0.0;
float _viewWidth;
float _viewHeight;
vec3 _lightTargetPos(0.0, 0.0, 0.0);
vec3 _lightPos(50.0, 20.0, 50.0);
vec3 _modelPos(-30.0, 0.0, -20.0);
vec3 _skyModelPos(0.0, 0.0, -20.0);
vec3 _modelScale(0.1);
vec3 _lookTargetPos(0.0);
vec3 _particlesPos(40.0, 10.0, 0.0);

// буффера и текстуры
GLuint _shadowRenderFBO;
GLuint _shadowMapTexture;

// скайбокс
GLint _skyboxShader;
GLint _skyboxTextureLocation;
GLuint _skyboxModelViewLocation;
GLuint _skyboxTexture;
GLuint _skyboxVAO;
GLint _skyboxElementsCount;

// модель
GLint _shaderProgram;
GLint _modelVAO;
GLint _elementsCount;
GLint _elementsType;
GLint _modelTexture;
GLint _normalsTexture;
GLint _projMatrixLocation;
GLint _viewMatrixLocation;
GLint _modelMatrixLocation;
GLint _inShadowMatrixLocation;
GLint _lightPosLocation;
GLint _modelTextureLocation;
GLint _shadowMapTextureLocation;
GLint _normalsTextureLocation;

// спрайт
GLint _spriteShaderProgram;
GLint _spriteTextureLocation;
GLint _spriteVAO;
GLint _spriteElementsCount;


// биллборд
GLint _billboardShaderProgram;
GLint _billboardTextureLocation;
GLint _billboardMVPLocation;
GLint _billboardTexture;
GLint _billboardPointsVAO;
GLint _billboardPointsElementsCount;


// частицы
GLint _particlesShader;
GLint _particlesVAO;
GLint _particlesPointsCount;
GLint _particlesTimeLocation;
GLint _particlesMVPLocation;


// куб в точке
GLint _cubeShader;
GLint _cubeVAO;
GLint _cubeElementsCount;
GLint _cubeMVPLocation;


// скайбокс
GLint _skyCharacterProgram;
GLint _skyCharViewMatrixLocation;
GLint _skyCharModelMatrixLocation;
GLint _skyCharProjMatrixLocation;
GLint _skyCharModelTextureLocation;
GLint _skyCharNormalsTextureLocation;
GLint _skyCharModelSkyboxTextureLocation;
GLint _skyCharCameraPosLocation;


-(void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);
    
	_viewWidth = width;
	_viewHeight = height;
    
    buildShadowFBO(_viewWidth, _viewHeight, &_shadowRenderFBO, &_shadowMapTexture);
}

-(void)renderFigures:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 modelMat;
    modelMat = translate(modelMat, _modelPos);
    modelMat = rotate(modelMat, float(_angle), vec3(0.0, 1.0, 0.0));
    modelMat = rotate(modelMat, float(-M_PI/2.0), vec3(1.0, 0.0, 0.0));
    modelMat = scale(modelMat, _modelScale);

    // вид из точки света
    mat4 shadowCamera = lookAt(_lightPos, _lightTargetPos, vec3(0.0, 1.0, 0.0));
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [self.camera cameraMatrix];
    }else{
        camera = shadowCamera;
    }
    
    // проекция
    mat4 projection = perspective(45.0f, float((float)_viewWidth / (float)_viewHeight), _zNear, _zFar);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 shadowMvp = projection * shadowCamera * modelMat;
    
    // вектор света
    mat4 lightTranslate;
    lightTranslate = translate(lightTranslate, _lightPos);
    vec4 glSpaceLightPos = [self.camera cameraMatrix] * vec4(_lightPos, 1.0);
    
    
    // включаем шейдер для отрисовки
    glUseProgram(_shaderProgram);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_modelMatrixLocation, 1, GL_FALSE, value_ptr(modelMat));
    glUniformMatrix4fv(_viewMatrixLocation, 1, GL_FALSE, value_ptr(camera));
    glUniformMatrix4fv(_projMatrixLocation, 1, GL_FALSE, value_ptr(projection));
    glUniformMatrix4fv(_inShadowMatrixLocation, 1, GL_FALSE, value_ptr(shadowMvp));
    glUniform3f(_lightPosLocation, glSpaceLightPos.x, glSpaceLightPos.y, glSpaceLightPos.z);
    
    if (toShadowMap == FALSE) {
        // текстура модели
        glUniform1i(_modelTextureLocation, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, _modelTexture);
        
        // текстура тени
        glUniform1i(_shadowMapTextureLocation, 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
        
        // текстура тени
        glUniform1i(_normalsTextureLocation, 2);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 0);
        glUniform1i(_normalsTexture, 0);
    }
    
    // включаем объект аттрибутов вершин
    glBindVertexArray(_modelVAO);
    glDrawElements(GL_TRIANGLES, _elementsCount, _elementsType, 0);
    glBindVertexArray(0);
}

-(void)renderSkyFigures:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 modelMat;
    modelMat = translate(modelMat, _skyModelPos);
    modelMat = rotate(modelMat, float(-_angle*2), vec3(0.0, 1.0, 0.0));
    modelMat = rotate(modelMat, float(-M_PI/2.0), vec3(1.0, 0.0, 0.0));
    modelMat = scale(modelMat, _modelScale);
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [self.camera cameraMatrix];
    }else{
        camera = lookAt(_lightPos, _lightTargetPos, vec3(0.0, 1.0, 0.0));
    }
    
    // проекция
    mat4 projection = perspective(45.0f, float((float)_viewWidth / (float)_viewHeight), _zNear, _zFar);
    
    vec3 glSpaceCameraPos = [self.camera cameraPos] / _worldSize;
    
    // включаем шейдер для отрисовки
    glUseProgram(_skyCharacterProgram);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_skyCharModelMatrixLocation, 1, GL_FALSE, value_ptr(modelMat));
    glUniformMatrix4fv(_skyCharViewMatrixLocation, 1, GL_FALSE, value_ptr(camera));
    glUniformMatrix4fv(_skyCharProjMatrixLocation, 1, GL_FALSE, value_ptr(projection));
    glUniform3f(_skyCharCameraPosLocation, glSpaceCameraPos.x, glSpaceCameraPos.y, glSpaceCameraPos.z);

    
    if (toShadowMap == FALSE) {
        // текстура модели
        glUniform1i(_skyCharModelSkyboxTextureLocation, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexture);
        
        // текстура модели
        glUniform1i(_skyCharNormalsTextureLocation, 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 0);
        glUniform1i(_normalsTexture, 0);
    }
    
    
    // включаем объект аттрибутов вершин
    glBindVertexArray(_modelVAO);
    glDrawElements(GL_TRIANGLES, _elementsCount, _elementsType, 0);
    glBindVertexArray(0);
}

-(void)renderSprite{
    glUseProgram(_spriteShaderProgram);
    glUniform1i(_spriteTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
    
    glDisable(GL_DEPTH_TEST);
    glBindVertexArray(_spriteVAO);
    glDrawElements(GL_TRIANGLES, _spriteElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

-(void)renderCube{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    vec3 offset = normalize(self.camera.cameraPos - _lookTargetPos) * vec3(1.0); // вычисляем вектор от найденной точки к позиции камеры
    mat4 model;
    model = translate(model, _lookTargetPos + offset);  // смещаем
    model = rotate(model, float(_angle * 20.0), vec3(1.0));
    model = scale(model, vec3(0.5));
    
    mat4 camera = [self.camera cameraMatrix];
    
    // вычислим матрицу проекции в массив projection
    mat4 projection = perspective(45.0f, (float)_viewWidth/(float)_viewHeight, _zNear, _zFar);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 mvp = projection * camera * model;
    
    glUseProgram(_cubeShader);
    
    glUniformMatrix4fv(_cubeMVPLocation, 1, GL_FALSE, value_ptr(mvp));
    
    glBindVertexArray(_cubeVAO);
    glDrawElements(GL_TRIANGLES, _cubeElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

-(void)renderParticles:(BOOL)toShadowMap{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 model;
    model = translate(model, _particlesPos);  // смещаем
    model = scale(model, vec3(15.0));
    model = rotate(model, _angle * 2.0f, vec3(1.0));
    
    // камера вида
    mat4 camera;
    if (toShadowMap == FALSE) {
        camera = [self.camera cameraMatrix];
    }else{
        camera = lookAt(_lightPos, _lightTargetPos, vec3(0.0, 1.0, 0.0));
    }
    
    // вычислим матрицу проекции в массив projection
    mat4 projection = perspective(45.0f, (float)_viewWidth/(float)_viewHeight, _zNear, _zFar);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 mvp = projection * camera * model;
    
    glUseProgram(_particlesShader);
    
    float time = [[NSDate date] timeIntervalSince1970] - _initTime;
    glUniform1f(_particlesTimeLocation, time);
    
    glUniformMatrix4fv(_particlesMVPLocation, 1, GL_FALSE, value_ptr(mvp));
    
    glEnable(GL_POINT_SIZE);
    glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);
        
    glBindVertexArray(_particlesVAO);
    glDrawArrays(GL_POINTS, 0, _particlesPointsCount);
    glBindVertexArray(0);
    
    glDisable(GL_POINT_SIZE);
}

-(void)renderSkybox{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 model;
    model = scale(model, _worldSize/vec3(2.0));
    
    mat4 camera = [self.camera cameraMatrix];
    
    // вычислим матрицу проекции в массив projection
    float aspect = (float)_viewWidth/(float)_viewHeight;
    mat4 projection = perspective(45.0f, aspect, _zNear, _zFar);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mat4 mvp = projection * camera * model;

    // шейдер
    glUseProgram(_skyboxShader);
    
    glUniform1i(_skyboxTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexture);
    
    glUniformMatrix4fv(_skyboxModelViewLocation, 1, GL_FALSE, value_ptr(mvp));
    
    // старые режимы
    GLint oldCullFaceMode;
    glGetIntegerv(GL_CULL_FACE_MODE, &oldCullFaceMode);
    GLint oldDepthTestMode;
    glGetIntegerv(GL_DEPTH_FUNC, &oldDepthTestMode);
    
    glCullFace(GL_FRONT);
    glDepthFunc(GL_LEQUAL);
    
    glBindVertexArray(_skyboxVAO);
    glDrawElements(GL_TRIANGLES, _skyboxElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
    
    glCullFace(oldCullFaceMode);
    glDepthFunc(oldDepthTestMode);
}

-(void)renderBillboards{
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 modelView;
    modelView = translate(modelView, vec3(0, 0, -2.0));
    modelView = scale(modelView, vec3(0.2, 0.2, 0.2));
    
    // вычислим матрицу проекции в массив projection
    float aspect = (float)_viewWidth/(float)_viewHeight;
    mat4 projection = perspective(45.0f, aspect, 1.0f, 3.0f);
    
    mat4 mvp = projection * modelView;
    
    // шейдер
    glUseProgram(_billboardShaderProgram);
    
    glUniform1i(_billboardTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _billboardTexture);
    
    glUniformMatrix4fv(_billboardMVPLocation, 1, GL_FALSE, value_ptr(mvp));
    
    // точки
    glBindVertexArray(_billboardPointsVAO);
    glDrawElements(GL_POINTS, _billboardPointsElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

-(void)calcLookTarget{
    GLint viewport[4];
    glGetIntegerv( GL_VIEWPORT, viewport );
    
    GLfloat winX = _viewWidth/2;
    GLfloat winY = _viewHeight/2;
    GLfloat winZ = 0;
    glReadPixels(int(winX), int(winY), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ);
    
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 model;
    mat4 camera = [self.camera cameraMatrix];
    mat4 modelView = camera * model;
    
    // проекция
    mat4 projection = perspective(45.0f, float((float)_viewWidth / (float)_viewHeight), 1.0f, 10000.0f);
    
    // вьюпорт
    vec4 viewportVec = vec4(viewport[0], viewport[1], viewport[2], viewport[3]);
    
    _lookTargetPos = unProject(vec3(winX, winY, winZ), modelView, projection, viewportVec) /*/ (_zFar - _zNear)*/;
}

-(void)render {
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, _shadowRenderFBO);
    glClear(GL_DEPTH_BUFFER_BIT);
    [self renderFigures:TRUE];
    [self renderSkyFigures:TRUE];
    [self renderParticles:TRUE];
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    
    // очистим буфферы для отображения
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    [self renderFigures:FALSE];
    [self renderSkyFigures:FALSE];
    [self renderBillboards];
    
    [self renderSkybox];

    [self calcLookTarget];
    [self renderCube];
    
    [self renderParticles:FALSE];
    
    // спрайт для дебуга
    [self renderSprite];
    
	// увеличиваем угол поворота персонажа
	_angle += 0.005;
    if (_angle > M_PI*2.0) {
        _angle = 0.0;
    }
}

- (id) initWithWidth:(int)width height:(int)height {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
        GLint texture_units;
        glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &texture_units);
        
		
        _initTime = [[NSDate date] timeIntervalSince1970];
        
        self.camera = [[Camera alloc] initWithCameraPos:_cameraPos];
        
        {
            vec3 front(0.0, 0.0, 0.1);
            vec3 right(1.0, 0.0, 0.0);
            vec3 mulValue = normalize(front * right);  // произведение векторов
            mulValue = mulValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(1.0, 0.0, 0.0);
            vec3 sumValue = normalize(front + right);  // сумма векторов
            sumValue = sumValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(0.0, 0.0, 0.5);
            vec3 subValue = normalize(front - right);  // разница векторов (как из второй точки, попасть в первую)
            subValue = subValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(0.5, 0.0, 0.5);
            float cosCoeff = dot(normalize(front), normalize(right)); // насколько сильно эти вектора сонаправлены друг с другом (косинус угла между ними)
            cosCoeff = cosCoeff;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(1.0, 0.0, 0.0);
            vec3 vectMul = cross(front, right); // векторное произведение по правилу левой руки (указательный вперед 1, средний направо 2 = большой смотрит вверх)
            vectMul = vectMul;
        }
        
		_viewWidth = width;
		_viewHeight = height;
		
		_angle = 0;
        
		//////////////////////////////
		// модель //
		//////////////////////////////
		
		// на основании модели создаем обхект аттрибутов вершин
		_modelVAO = buildModelVAO(&_elementsCount, &_elementsType);
        _spriteVAO = spriteVAO(&_spriteElementsCount);
        _skyboxVAO = skyboxVAO(&_skyboxElementsCount);
        _billboardPointsVAO = billboardVAO(&_billboardPointsElementsCount);
        _particlesVAO = particlesVAO(&_particlesPointsCount);
        _cubeVAO = cubeVAO(&_cubeElementsCount);
		
        ////////////////////////////////////////////////
        // загрузка текстуры
        ////////////////////////////////////////////////
        
        _modelTexture = buildTexture(@"demon");
        _normalsTexture = buildTexture(@"demon_normals");
        _skyboxTexture = buildSkyboxTexture();
        _billboardTexture = buildTexture(@"monster_hellknight");
        
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
		
        // модель
		_shaderProgram = buildProgramFunc();
		_projMatrixLocation = glGetUniformLocation(_shaderProgram, "u_projectionMatrix");
        _viewMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_viewMatrix");
        _modelMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_modelMatrix");
        _inShadowMatrixLocation =  glGetUniformLocation(_shaderProgram, "u_toShadowMapMatrix");
        _lightPosLocation = glGetUniformLocation(_shaderProgram, "u_cameraSpaceLightPos");
        _modelTextureLocation = glGetUniformLocation(_shaderProgram, "u_texture");
        _shadowMapTextureLocation = glGetUniformLocation(_shaderProgram, "u_shadowMapTexture");
        _normalsTextureLocation = glGetUniformLocation(_shaderProgram, "u_normalsTexture");
        
        // спрайт
        _spriteShaderProgram = buildSpriteProgram();
        _spriteTextureLocation = glGetUniformLocation(_spriteShaderProgram, "u_texture");
        
        // скайбокс
        _skyboxShader = buildSkyboxProgram();
        _skyboxTextureLocation = glGetUniformLocation(_skyboxShader, "u_cubemapTexture");
        _skyboxModelViewLocation = glGetUniformLocation(_skyboxShader, "u_modelViewProj");
        
        // билборд
        _billboardShaderProgram = buildBillboardProgram();
        _billboardMVPLocation = glGetUniformLocation(_billboardShaderProgram, "u_modelViewProj");
        _billboardTextureLocation = glGetUniformLocation(_billboardShaderProgram, "u_texture");
        
        // частицы
        _particlesShader = buildParticlesProgram();
        _particlesTimeLocation = glGetUniformLocation(_particlesShader, "u_time");
        _particlesMVPLocation = glGetUniformLocation(_particlesShader, "u_mvp");
        
        // куб
        _cubeShader = buildCubeProgram();
        _cubeMVPLocation = glGetUniformLocation(_cubeShader, "u_mvp");
        
        // модель с отражениями
        _skyCharacterProgram = buildSkyCharacter();
        _skyCharModelMatrixLocation = glGetUniformLocation(_skyCharacterProgram, "u_modelMatrix");
        _skyCharViewMatrixLocation =  glGetUniformLocation(_skyCharacterProgram, "u_viewMatrix");
        _skyCharProjMatrixLocation =  glGetUniformLocation(_skyCharacterProgram, "u_projectionMatrix");
        _skyCharModelTextureLocation = glGetUniformLocation(_skyCharacterProgram, "u_texture");
        _skyCharNormalsTextureLocation = glGetUniformLocation(_skyCharacterProgram, "u_normalsTexture");
        _skyCharModelSkyboxTextureLocation = glGetUniformLocation(_skyCharacterProgram, "_modelSkyboxTextureLocation");
        _skyCharCameraPosLocation = glGetUniformLocation(_skyCharacterProgram, "u_glSpaceCameraPos");
        
        ////////////////////////////////////////////////
        // буфер рендеринга
        ////////////////////////////////////////////////
        
        buildShadowFBO(_viewWidth, _viewHeight, &_shadowRenderFBO, &_shadowMapTexture);
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
        glEnable(GL_CULL_FACE);     // не рисует заднюю часть
        glFrontFace(GL_CCW);        // передняя часть при обходе против часовой стрелки
		glEnable(GL_DEPTH_TEST);    // тест глубины
        glEnable(GL_TEXTURE_CUBE_MAP);
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		
		// Reset the m_characterAngle which is incremented in render
		_angle = 0;
        
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}

- (void) dealloc {
    self.camera = nil;
    
	destroyVAO(_modelVAO);
    destroyVAO(_skyboxVAO);
    destroyVAO(_spriteVAO);
	glDeleteProgram(_shaderProgram);
    glDeleteProgram(_skyboxShader);
    glDeleteProgram(_spriteShaderProgram);
    
	[super dealloc];
}

@end
