#import "OpenGLRenderer.h"
#import "matrixUtil.h"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"


#define GetGLError(){                                   \
	GLenum err = glGetError();							\
	while (err != GL_NO_ERROR) {						\
		NSLog(@"GLError %s set in File:%s Line:%d\n",	\
				GetGLErrorString(err),					\
				__FILE__,								\
				__LINE__);								\
		err = glGetError();								\
	}													\
}

enum {
	POS_ATTRIB_IDX = 0,
	COLOR_ATTRIB_IDX = 1
};

#ifndef NULL
#define NULL 0
#endif

#define BUFFER_OFFSET(i) ((char *)NULL + (i))


@implementation OpenGLRenderer

GLfloat _angle;
GLint _lightX;
GLint _lightY;
GLint _lightZ;
GLuint _viewWidth;
GLuint _viewHeight;

GLuint _shaderProgram;
GLuint _vertexAttObject;
GLuint _xyzAttObject;

GLuint _elementsCount;
GLuint _xyzElementsCount;

GLint _mvpMatrixLocation;
GLint _modelViewLocation;
GLint _normalMatrixLocation;
GLint _lightPosLocation;


- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);

	_viewWidth = width;
	_viewHeight = height;
}

- (void) render {
    GLfloat modelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    float aspectRatio = (float)_viewWidth / (float)_viewHeight;
    
    // очистим буфферы для отображения
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// включаем шейдер для отрисовки
	glUseProgram(_shaderProgram);
		
	// обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxTranslateApply(modelView, 0, 0, -7.0);  // матрица с помещением модели в нужное место
    mtxRotateApply(modelView, _angle, 1, 1, 1);   // крутим модель по таймеру
    mtxScaleApply(modelView, 0.2, 0.2, 0.2);
	
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadOrthographic(projection, -aspectRatio, aspectRatio, -1.0, 1.0, 1.0, 100.0);
//    mtxLoadPerspective(projection, 90, aspectRatio, 1.0, 100.0);
    
	// умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);
    
	// помещаем матрицу модельвидпроекция в шейдер (указываем)
	glUniformMatrix4fv(_mvpMatrixLocation, 1, GL_FALSE, mvp);
    
	// включаем объект аттрибутов вершин
	glBindVertexArray(_vertexAttObject);
    glDrawElements(GL_TRIANGLES, _elementsCount, GL_UNSIGNED_INT, 0);
    
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxTranslateApply(modelView, -0.9, -0.9, -10.0);  // матрица с помещением модели в нужное место
    mtxRotateApply(modelView, _angle, 1, 1, 1);   // крутим модель по таймеру
    mtxScaleApply(modelView, 0.2, 0.2, 0.2);
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadOrthographic(projection, -aspectRatio, aspectRatio, -1.0, 1.0, 1.0, 100.0);
//    mtxLoadPerspective(projection, 90, aspectRatio, 1.0, 100.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_mvpMatrixLocation, 1, GL_FALSE, mvp);
    
    glBindVertexArray(_xyzAttObject);
    glDrawElements(GL_LINES, _xyzElementsCount, GL_UNSIGNED_INT, 0);
	
    
	// увеличиваем угол поворота персонажа
	_angle++;
}

static GLfloat func(double x, double y){
    return sinf(y * sin(x) * 4);
}

- (GLuint) xyzVAO {
    
    // всего 3 индекса
    _xyzElementsCount = 6;
    
    GLfloat points[] = {0.0, 0.0, 0.0,
                        1.0, 0.0, 0.0,
                        0.0, 1.0, 0.0,
                        0.0, 0.0, 1.0,};
    GLfloat colors[] = {1.0, 1.0, 1.0,
                        1.0, 0.0, 0.0,
                        0.0, 1.0, 0.0,
                        0.0, 0.0, 1.0,};
    GLuint indexes[] = {0, 1,
                        0, 2,
                        0, 3};
    
    // создание 1го объекта
    GLuint vaoName;
    glGenVertexArrays(1, &vaoName);
    glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points), points, GL_STATIC_DRAW);
    glEnableVertexAttribArray(POS_ATTRIB_IDX);
    glVertexAttribPointer(POS_ATTRIB_IDX,		// индекс аттрибута в шейдере
                          3,	// из скольки элементов состоит (вершина из 3х значений)
                          GL_FLOAT,	// тип данных
                          GL_FALSE,				// данные не являются нормализованными
                          3 * sizeof(GL_FLOAT), // шаг между отдельными элементами в байтах 3*sizeof(float)
                          BUFFER_OFFSET(0));	// данные с нулевым оффсетом
    
    
    // создаем буффер объект для нормалей
    GLuint colorBufferName;
    glGenBuffers(1, &colorBufferName);
    glBindBuffer(GL_ARRAY_BUFFER, colorBufferName);
    glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);
    glEnableVertexAttribArray(COLOR_ATTRIB_IDX);
    glVertexAttribPointer(COLOR_ATTRIB_IDX,
                          3,
                          GL_FLOAT,
                          GL_FALSE,
                          3 * sizeof(GL_FLOAT),
                          BUFFER_OFFSET(0));
    
    // создание буффера индексов
    GLuint elementBufferName;
    glGenBuffers(1, &elementBufferName);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferName);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexes), indexes, GL_STATIC_DRAW);
    
    GetGLError();
    
    return vaoName;
}

// создание объекта аттрибутов вершин
- (GLuint) buildVAO {
	GLuint vaoName = 0;
	
    int xSize = 100;
    int ySize = 10;
    double startX = -M_PI;
    double startY = -M_PI;
    double endX = M_PI;
    double endY = M_PI;
    double stepX = (endX - startX) / (float)xSize;
    double stepY = (endY - startY) / (float)ySize;
    
    // всего 3 индекса
    _elementsCount = xSize * ySize * 6;
    
    size_t pointsSize = sizeof(GLfloat) * 3 * xSize * ySize;
    GLfloat* points = malloc(pointsSize);
    memset(points, 0, pointsSize);
    size_t colorsSize = sizeof(GLfloat) * 3 * xSize * ySize;
    GLfloat* colors = malloc(colorsSize);
    memset(colors, 0, colorsSize);
    size_t indexesSize = sizeof(GLuint) * _elementsCount;
    GLuint* indexes = malloc(indexesSize);
    memset(indexes, 0, indexesSize);

    int i = 0;
    int j = 0;
    for (int x = 0; x < xSize; x += 1) {
        for (int y = 0; y < ySize; y += 1) {
            float curX = startX + stepX * x;
            float curY = startY + stepY * y;
            
            points[i++] = curX;
            points[i++] = curY;
            points[i++] = func(curX, curY);
            
            colors[j++] = fmax(func(curX, curY), 0.0);
            colors[j++] = 0.3;
            colors[j++] = fmax(-func(curX, curY), 0.0);
            
//            printf("%f %f %f\n", curX, curY, func(curX, curY));
        }
    }
    
    int index = 0;
    for (int x = 0; x < xSize-1; x++) {
        for (int y = 0; y < ySize-1; y++) {
            //tri 1
            indexes[index++] = xSize*y + x;
            indexes[index++] = xSize*(y+1) + (x+1);
            indexes[index++] = xSize*(y+1) + x;
            
            //tri 2
            indexes[index++] = xSize*y + x;
            indexes[index++] = xSize*y + (x+1);
            indexes[index++] = xSize*(y+1) + (x+1);
            
//            printf("%d %d %d\n", xSize*y + x, xSize*(y+1) + (x+1), xSize*(y+1) + x);
//            printf("%d %d %d\n", xSize*y + x, xSize*y + (x+1), xSize*(y+1) + (x+1));
        }
    }
    
    printf("Triangles count = %d", _elementsCount / 3);
    
    
	// создание 1го объекта
	glGenVertexArrays(1, &vaoName);
    // включаем работу с этим объектом
	glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    
    // подгружаем данные, которые будут использоваться для вершин
    glBufferData(GL_ARRAY_BUFFER, pointsSize, points, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(POS_ATTRIB_IDX);
    // теперь указываем формат в данных
    glVertexAttribPointer(POS_ATTRIB_IDX,		// индекс аттрибута в шейдере
                          3,	// из скольки элементов состоит (вершина из 3х значений)
                          GL_FLOAT,	// тип данных
                          GL_FALSE,				// данные не являются нормализованными
                          3 * sizeof(GL_FLOAT), // шаг между отдельными элементами в байтах 3*sizeof(float)
                          BUFFER_OFFSET(0));	// данные с нулевым оффсетом
    
    
    // создаем буффер объект для нормалей
    GLuint colorBufferName;
    glGenBuffers(1, &colorBufferName);
    glBindBuffer(GL_ARRAY_BUFFER, colorBufferName);
    
    
    // выделяем память и подгружаем данные цветов
    glBufferData(GL_ARRAY_BUFFER, colorsSize, colors, GL_STATIC_DRAW);
    
    // включаем работу с нормалями каждой вершины
    glEnableVertexAttribArray(COLOR_ATTRIB_IDX);
    glVertexAttribPointer(COLOR_ATTRIB_IDX,
                          3,
                          GL_FLOAT,
                          GL_FALSE,
                          3 * sizeof(GL_FLOAT),
                          BUFFER_OFFSET(0));
    
    // создание буффера индексов
    GLuint elementBufferName;
    glGenBuffers(1, &elementBufferName);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferName);
    
    // выделяем и подгружаем
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexesSize, indexes, GL_STATIC_DRAW);
	
    // удаляем
    free(points);
    free(colors);
    free(indexes);
    
	GetGLError();
	
	return vaoName;
}

-(void)destroyVAO:(GLuint) vaoName{
	GLuint index;
	GLuint bufName;
	
	// включаем работу с объектом буффера вершин
	glBindVertexArray(vaoName);
	
	// удаляем все доступные подбуфферы
	for(index = 0; index < 16; index++) {
		glGetVertexAttribiv(index , GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
		
		if(bufName) {
			glDeleteBuffers(1, &bufName);
		}
	}
	
	// дергаем буффер индексов
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
	
    // уничтожаем, если есть
	if(bufName){
		glDeleteBuffers(1, &bufName);
	}
	
    // удаляем сам буффер аттрибутов
	glDeleteVertexArrays(1, &vaoName);
	
	GetGLError();
}

// создание шейдерной программы
-(GLuint) buildProgramWithVertexSource:(demoSource*)vertexSource
					withFragmentSource:(demoSource*)fragmentSource
{
	GLuint prgName;
	
	GLint logLength, status;
	
	// строка
	GLchar* sourceString = NULL;  
	
    // определяем версию языка, которая доступна
	float  glLanguageVersion;
	
	sscanf((char *)glGetString(GL_SHADING_LANGUAGE_VERSION), "%f", &glLanguageVersion);
	
	GLuint version = 100 * glLanguageVersion;
	
	// Get the size of the version preprocessor string info so we know 
	//  how much memory to allocate for our sourceString
	const GLsizei versionStringSize = sizeof("#version 123\n");
	
	// создание объекта программы
	prgName = glCreateProgram();
	
    // задаем соответствие названия в шейдере и аттрибутов вершин
	glBindAttribLocation(prgName, POS_ATTRIB_IDX, "inPosition");
    glBindAttribLocation(prgName, COLOR_ATTRIB_IDX, "inColor");
	
	/////////////////////////////////
	// создание вершинного шейдера //
	/////////////////////////////////
	
	// выделяем память под строку версии шейдера
	sourceString = malloc(vertexSource->byteSize + versionStringSize);
	
	// добавляем версию к шейдеру
	sprintf(sourceString, "#version %d\n%s", version, vertexSource->string);
	
    // создаем вершинный шейдер
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);	
	glShaderSource(vertexShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(vertexShader);
	glGetShaderiv(vertexShader, GL_INFO_LOG_LENGTH, &logLength);
	
    // инфа
	if (logLength > 0) {
		GLchar *log = (GLchar*) malloc(logLength);
		glGetShaderInfoLog(vertexShader, logLength, &logLength, log);
		NSLog(@"Vtx Shader compile log:%s\n", log);
		free(log);
	}
	
    // лог компиляции
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile vtx shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// подсоединяем вершинный шейдер к обхекту программы
	glAttachShader(prgName, vertexShader);
	
	// удаляем шейдер, тк он уже присоединен к программе
	glDeleteShader(vertexShader);
	
	////////////////////////
	// фрагментный шейдер //
	////////////////////////
	
	// выделяем память под версию
	sourceString = malloc(fragmentSource->byteSize + versionStringSize);
	
	// добавляем версию в текст
	sprintf(sourceString, "#version %d\n%s", version, fragmentSource->string);
	
    // фрагментный шейдер
	GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);	
	glShaderSource(fragShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(fragShader);
	glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0) {
		GLchar *log = (GLchar*)malloc(logLength);
		glGetShaderInfoLog(fragShader, logLength, &logLength, log);
		NSLog(@"Frag Shader compile log:\n%s\n", log);
		free(log);
	}
	
	glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile frag shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// присоединяем фрагментный к программе
	glAttachShader(prgName, fragShader);
	
	// удаляем, тк присоединен
	glDeleteShader(fragShader);
	
	//////////////////////
	// сборка программы //
	//////////////////////
	
	glLinkProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0){
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program link log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_LINK_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to link program");
		return 0;
	}
	
    // проверка на валидность
	glValidateProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0)
	{
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program validate log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_VALIDATE_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to validate program");
		return 0;
	}
	
	// включаем данную программу
	glUseProgram(prgName);
	
	///////////////////////////////////////
	// устанавливаем текстуру по умолчанию - 0 //
	///////////////////////////////////////
	
	GLint samplerLoc = glGetUniformLocation(prgName, "diffuseTexture");
	
	// Indicate that the diffuse texture will be bound to texture unit 0
	GLint unit = 0;
	glUniform1i(samplerLoc, unit);
	
	GetGLError();
	
	return prgName;
	
}

- (id) init {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
		
		_viewWidth = 640;
		_viewHeight = 480;
		
        _lightX = 300;
        _lightY = 300;
        _lightZ = -100;
		
		_angle = 0;
		
		NSString* filePathName = nil;

		//////////////////////////////
		// модель //
		//////////////////////////////
		
		// на основании модели создаем обхект аттрибутов вершин
		_vertexAttObject = [self buildVAO];
        _xyzAttObject = [self xyzVAO];
	
		
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
		
		demoSource* vtxSource = NULL;
		demoSource* frgSource = NULL;
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"vsh"];
		vtxSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"fsh"];
		frgSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		_shaderProgram = [self buildProgramWithVertexSource:vtxSource
                                         withFragmentSource:frgSource];
		
		srcDestroySource(vtxSource);
		srcDestroySource(frgSource);
		
        // дергаем юниформы
		_mvpMatrixLocation = glGetUniformLocation(_shaderProgram, "modelViewProjectionMatrix");
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
		// включаем тест глубины
		glEnable(GL_DEPTH_TEST);
	
		// отрисовываем только передние части
//		glEnable(GL_CULL_FACE);
//         порядок отрисовки
//        glCullFace(GL_BACK);
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		
		// Reset the m_characterAngle which is incremented in render
		_angle = 0;
		
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}


- (void) dealloc {
	[self destroyVAO:_vertexAttObject];

	glDeleteProgram(_shaderProgram);

	[super dealloc];
}

@end
