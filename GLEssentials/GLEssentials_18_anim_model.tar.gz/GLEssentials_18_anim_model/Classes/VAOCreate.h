//
//  VAOCreate.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 05.04.15.
//
//

#import <Foundation/Foundation.h>
#import "glUtil.h"
#import "modelUtil.h"
#import "GlobalValues.h"
#import <vector>

GLuint particlesVAO(int* pointsCount);
GLuint cubeVAO(int* elementsCount);
GLuint spriteVAO(int* elementsCounter);
GLuint skyboxVAO(int* elementsCounter);
GLuint buildModelVAO(int* elementsCounter, int* elementsType);
GLuint billboardVAO(std::vector<vec3> positions);

void destroyVAO(GLuint vaoName);