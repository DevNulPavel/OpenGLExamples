#import <Cocoa/Cocoa.h>
#import <QuartzCore/CVDisplayLink.h>

#import "modelUtil.h"
#import "imageUtil.h"

@interface GLEssentialsGLView : NSOpenGLView {
	CVDisplayLinkRef displayLink;
    double _lastDrawTime;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseMoved:(NSEvent *)theEvent;

@end
