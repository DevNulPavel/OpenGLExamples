#import "glm.hpp"
#import "ext.hpp"
#import "Camera.h"
#import "LightObject.h"

using namespace glm;

@interface RenderObject: NSObject{
}

@property(nonatomic, assign) vec3 modelPos;
@property(nonatomic, assign) float xRotate;
@property(nonatomic, assign) float yRotate;
@property(nonatomic, assign) float zRotate;
@property(nonatomic, assign) float scale;

-(void)renderModelFromCamera:(Camera*)camera light:(LightObject*)light toShadow:(BOOL)toShadowMap;
-(mat4)modelTransformMatrix;
-(mat4)projectionMatrix;

@end

