#import "OpenGLRenderer.h"
#import "glm.hpp"
#import "ext.hpp"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"
#import "VAOCreate.h"
#import "ShaderCreate.h"
#import "TextureCreate.h"
#import "FrameBufferCreate.h"
#import "GlobalValues.h"
#import "RenderObject.h"
#import "SkyModel3D.h"
#import "btBulletCollisionCommon.h"
#import "btBulletDynamicsCommon.h"
#import "AnimatedModel3D.h"

using namespace glm;

@implementation OpenGLRenderer

// спрайт
GLint _spriteShaderProgram;
GLint _spriteTextureLocation;
GLint _spriteVAO;
GLint _spriteElementsCount;


-(void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);
    
	GlobI.viewWidth = width;
	GlobI.viewHeight = height;
    
    GLuint textId;
    GlobI.shadowRenderFBO = buildShadowFBO(GlobI.viewWidth * GlobI.shadowMapScale, GlobI.viewHeight * GlobI.shadowMapScale, &(textId));
    GlobI.shadowMapTexture = textId;
}

-(void)renderSprite{
    glUseProgram(_spriteShaderProgram);
    glUniform1i(_spriteTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, GlobI.shadowMapTexture);
    
    glDisable(GL_DEPTH_TEST);
    glBindVertexArray(_spriteVAO);
    glDrawElements(GL_TRIANGLES, _spriteElementsCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

-(void)renderCube{
    vec3 offset = normalize(self.camera.cameraPos - GlobI.lookTargetPos) * vec3(2.0); // вычисляем вектор от найденной точки к позиции камеры
    vec3 position = GlobI.lookTargetPos + offset;
    self.pointingCube.modelPos = position;
    self.pointingCube.scale = 0.4 + length(position)/200.0;
    [self.pointingCube renderModelFromCamera:self.camera light:self.light toShadow:FALSE];
}

-(void)calcLookTarget{
    GLint viewport[4];
    glGetIntegerv( GL_VIEWPORT, viewport );
    
    GLfloat winX = GlobI.viewWidth/2;
    GLfloat winY = GlobI.viewHeight/2;
    GLfloat winZ = 0;
    glReadPixels(int(winX), int(winY), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ);
    
    if (winZ < 0.94) {
        GlobI.lookTargetPos = vec3(1000.0);
        return;
    }
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mat4 model;
    mat4 camera = [self.camera cameraMatrix];
    mat4 modelView = camera * model;
    
    // проекция
    mat4 projection = perspective(45.0f, float((float)GlobI.viewWidth / (float)GlobI.viewHeight), 1.0f, 10000.0f);
    
    // вьюпорт
    vec4 viewportVec = vec4(viewport[0], viewport[1], viewport[2], viewport[3]);
    
    GlobI.lookTargetPos = unProject(vec3(winX, winY, winZ), modelView, projection, viewportVec);
}

-(void)renderToShadowMap{
    // увеличиваем угол поворота персонажа
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, GlobI.shadowRenderFBO);
    glClear(GL_DEPTH_BUFFER_BIT);
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
    glViewport(0, 0, GlobI.viewWidth * GlobI.shadowMapScale, GlobI.viewHeight * GlobI.shadowMapScale);
    for (RenderObject* model in self.models) {
        [model renderModelFromCamera:self.camera light:self.light toShadow:TRUE];
    }
    self.isRenderBullets = TRUE;
    for (RenderObject* bullet in self.bullets) {
        [bullet renderModelFromCamera:self.camera light:self.light toShadow:TRUE];
    }
    self.isRenderBullets = FALSE;
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glViewport(0, 0, GlobI.viewWidth, GlobI.viewHeight);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
}

-(void)render {
    // стрельба
    float delta = GlobI.deltaTime;
    [GlobI rendered];
    
    PhysI.world->stepSimulation(delta);
    
    [self renderToShadowMap];
    
    // очистим буфферы для отображения
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    for (RenderObject* model in self.models) {
        [model renderModelFromCamera:self.camera light:self.light toShadow:FALSE];
    }
    for (RenderObject* billboard in self.billboards) {
        [billboard renderModelFromCamera:self.camera light:self.light toShadow:FALSE];
    }
    self.isRenderBullets = TRUE;
    for (RenderObject* bullet in self.bullets) {
        [bullet renderModelFromCamera:self.camera light:self.light toShadow:FALSE];
    }
    self.isRenderBullets = FALSE;
    
    [self.skybox renderModelFromCamera:self.camera light:self.light toShadow:FALSE];
    
    [self calcLookTarget];
    [self renderCube];
    
    // спрайт для дебуга
    [self renderSprite];
}

-(void)shootCube{
    if (self.isRenderBullets) {
        return;
    }
    if (self.lastHitTime + 0.1 > [NSDate timeIntervalSinceReferenceDate]) {
        return;
    }
    self.lastHitTime = [NSDate timeIntervalSinceReferenceDate];
    
    Model3D* head = [[[Model3D alloc] initWithObjFilename:@"sphere" withBody:TRUE] autorelease];
    head.modelPos = self.camera.cameraPos + self.camera.cameraTargetVec * vec3(4.0);
    head.scale = 1.0;
    [head setMass:30];
    
    head.yRotate = self.camera.horisontalAngle - M_PI_2;
    head.xRotate = -self.camera.verticalAngle;
    
    // в цель
    vec3 toVec = self.camera.cameraTargetVec * vec3(300.0);
    [head setVelocity:toVec];
    
    [head addToPhysicsWorld];
    
    if (self.isRenderBullets) {
        return;
    }
    [self.bullets addObject:head];
}

- (void)keyButtonHandle:(unichar)symbol{
    [self.camera keyButtonHandle:symbol];
    
    switch (symbol) {
        case 'r':{
            [self shootCube];
        }break;
    }
}

- (id) initWithWidth:(int)width height:(int)height {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
        GLint texture_units;
        glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &texture_units);
        

        {
            vec3 front(0.0, 0.0, 0.1);
            vec3 right(1.0, 0.0, 0.0);
            vec3 mulValue = normalize(front * right);  // произведение векторов
            mulValue = mulValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(1.0, 0.0, 0.0);
            vec3 sumValue = normalize(front + right);  // сумма векторов
            sumValue = sumValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(0.0, 0.0, 0.5);
            vec3 subValue = normalize(front - right);  // разница векторов (как из второй точки, попасть в первую)
            subValue = subValue;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(0.5, 0.0, 0.5);
            float cosCoeff = dot(normalize(front), normalize(right)); // насколько сильно эти вектора сонаправлены друг с другом (косинус угла между ними)
            cosCoeff = cosCoeff;
        }
        {
            vec3 front(0.0, 0.0, 1.0);
            vec3 right(1.0, 0.0, 0.0);
            vec3 vectMul = cross(front, right); // векторное произведение по правилу левой руки (указательный вперед 1, средний направо 2 = большой смотрит вверх)
            vectMul = vectMul;
        }
        
        self.camera = [[[Camera alloc] initWithCameraPos:GlobI.cameraInitPos] autorelease];
        self.light = [[[LightObject alloc] init] autorelease];
        PhysI;
        
		GlobI.viewWidth = width;
		GlobI.viewHeight = height;
        
		//////////////////////////////
		// модель //
		//////////////////////////////
		
        self.models = [NSMutableArray array];
        self.billboards = [NSMutableArray array];
        self.bullets = [NSMutableArray array];
        
        {
            // скабокс
            self.skybox = [[[Skybox alloc] init] autorelease];
            
            // модель
            Model3D* modelOld = [[[Model3D alloc] initWithFilename:@"demon"] autorelease];
            modelOld.modelPos = vec3(-40.0, 0.0, -40.0);
            modelOld.scale = 0.1;
            modelOld.xRotate = float(-M_PI/2.0);
            [self.models addObject:modelOld];
            
            // модель голов
            for(int i = 0; i < 8; i++){
                Model3D* head = [[[Model3D alloc] initWithObjFilename:@"african_head" withBody:TRUE] autorelease];
                head.modelPos = vec3(randomFloat(-40.0, 40.0), randomFloat(-40.0, 40.0), randomFloat(-40.0, 40.0));
                head.scale = 8.0;
                
                // в центр
                vec3 toCenterVec = normalize(-head.modelPos) * vec3(50.0);
                [head setVelocity:toCenterVec];
                [head setMass:100.0];
                [head addToPhysicsWorld];
                [self.models addObject:head];
            }
            
            // скай модель
            SkyModel3D* skyModel = [[[SkyModel3D alloc] initWithFilename:@"demon"] autorelease];
            skyModel.modelPos = vec3(40.0, 0.0, -20.0);
            skyModel.scale = 0.1;
            skyModel.xRotate = -M_PI/2.0;
            skyModel.boxTexture = self.skybox.texture;
            [self.models addObject:skyModel];
            
            // частицы
            ParticlesModel* particles = [[[ParticlesModel alloc] init] autorelease];
            particles.modelPos = vec3(40.0, 10.0, 0.0);
            particles.scale = 9;
            [self.models addObject:particles];
        }
        {
            // биллборд, например, дерево
            for(int i = 0; i < 15; i++){
                BillboardModel* billboard = [[[BillboardModel alloc] initOne] autorelease];
                billboard.modelPos = vec3(randomFloat(-100.0, 100.0), randomFloat(-100.0, 100.0), randomFloat(-100.0, 100.0));
                billboard.scale = 5.0;
                [self.billboards addObject:billboard];
            }
            // биллборд в духе частиц
            std::vector<vec3> positions;
            for(int i = 0; i < 15; i++){
                vec3 pos(randomFloat(-5, 5), randomFloat(-5, 5), randomFloat(-5, 5));
                positions.push_back(pos);
            }
            BillboardModel* billboard = [[[BillboardModel alloc] initWithPositions:positions] autorelease];
            billboard.modelPos = vec3(-40, -40, -20);
            billboard.scale = 20.0;
            [self.billboards addObject:billboard];
        }
        
        AnimatedModel3D* animatedModel = [[[AnimatedModel3D alloc] initWithFilename:@"boblampclean.md5mesh" animIndex:0 withBody:TRUE] autorelease];
        animatedModel.scale = 0.5;
        animatedModel.modelPos = vec3(0.0, -20.0, 10.0);
        animatedModel.xRotate = -M_PI/2.0;
        [animatedModel setMass:400.0];
        [animatedModel addToPhysicsWorld];
        [self.models addObject:animatedModel];
        
        
        // тестовый выстрел
        [self shootCube];
        
        // куб указатель
        self.pointingCube = [[[CubeModel alloc] init] autorelease];
        self.pointingCube.scale = 0.5;
        
        
		// на основании модели создаем обхект аттрибутов вершин
        _spriteVAO = spriteVAO(&_spriteElementsCount);
		
        
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
        
        // спрайт
        _spriteShaderProgram = buildSpriteProgram();
        _spriteTextureLocation = glGetUniformLocation(_spriteShaderProgram, "u_texture");

        
        ////////////////////////////////////////////////
        // буфер рендеринга
        ////////////////////////////////////////////////
        
        GLuint texture;
        GlobI.shadowRenderFBO = buildShadowFBO(GlobI.viewWidth, GlobI.viewHeight, &texture);
        GlobI.shadowMapTexture = texture;
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
//        glEnable(GL_CULL_FACE);     // не рисует заднюю часть
//        glFrontFace(GL_CCW);        // передняя часть при обходе против часовой стрелки
		glEnable(GL_DEPTH_TEST);    // тест глубины
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		        
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}

- (void) dealloc {
    self.camera = nil;
    self.models = nil;
    self.billboards = nil;
    self.light = nil;
    self.pointingCube = nil;
    self.bullets = nil;
    self.skybox = nil;
    
    destroyVAO(_spriteVAO);
    glDeleteProgram(_spriteShaderProgram);
    
	[super dealloc];
}

@end
