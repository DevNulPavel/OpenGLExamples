#import <Foundation/Foundation.h>
#import "glUtil.h"

#define FPS_UPDATE_PERION 0.1f

@interface OpenGLRenderer : NSObject {

}

@property (nonatomic, assign) double lastFPSUpdateTime;
@property (nonatomic, assign) double lastRenderTime;
@property (nonatomic, assign) BOOL isUpdate;
@property (nonatomic, assign) BOOL isRender;
@property (nonatomic, assign) BOOL isDraw;
@property (nonatomic, assign) BOOL wasMoved;

- (id) initWithWidth:(int)width height:(int)height;
- (void)resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void)keyButtonUp:(NSString*)chars;
- (void)keyButtonDown:(NSString*)chars;
- (void)mouseMoved:(float)deltaX deltaY:(float)deltaY posX:(float)posX posY:(float)posY;
- (void)mousePressed:(float)posX posY:(float)posY;
- (void)mouseUp:(float)posX posY:(float)posY;
- (void)render;
- (void)dealloc;

@end
