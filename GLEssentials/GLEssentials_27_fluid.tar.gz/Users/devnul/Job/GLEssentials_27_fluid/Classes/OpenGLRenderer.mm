#import "OpenGLRenderer.h"
#import <glm.hpp>
#import <ext.hpp>
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"
#import "VAOCreate.h"
#import "ShaderCreate.h"
#import "TextureCreate.h"
#import "FrameBufferCreate.h"
#import "GlobalValues.h"
#import "GLStatesCache.h"
#import "ShadersCache.h"
#import <map>

using namespace glm;


typedef struct FBOSurface_ {
    GLuint fboId;
    GLuint textureId;
    int numComponents;
    int width;
    int height;
} FBOSurface;


typedef struct Slab_ {
    FBOSurface ping;
    FBOSurface pong;
} Slab;


@implementation OpenGLRenderer

GLuint quadVao;
Slab velocity;
Slab density;
Slab pressure;
Slab temperature;
FBOSurface divergence;
FBOSurface obstacles;
FBOSurface hiResObstacles;

// visualizeShader
GLint fillColorLocation;
GLint scaleLocation;
GLint visualVelocityLocation;
// advectShader
GLint inverseSizeLocation;
GLint timeStepLocation;
GLint dissLocLocation;
GLint sourceTextureLocation;
GLint obstaclesTextureLocation;
// jacobi
GLint alphaLocation;
GLint inverseBetaLocation;
GLint dSamplerLocation;
GLint oSamplerLocation;
// gradient
GLint gradientScaleLocation;
GLint halfCellLocation;
GLint pressureTextureLocation;
GLint pressObstaclesTextureLocation;
// divergence
GLint divergenceHalfCellLocation;
GLint divergenceObstaclesLocation;
// impulse
GLint impulsePointLocation;
GLint impulseRadiusLocation;
GLint impulseFillColorLocation;
// buoyancy
GLint buoyancyTempSamplerLocation;
GLint buoyancyInkSamplerLocation;
GLint buoyancyAmbTempLocation;
GLint buoyancyTimeStepLocation;
GLint buoyancySigmaLocation;
GLint buoyancyKappaLocation;



-(void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);
    
	GlobI.viewWidth = width;
	GlobI.viewHeight = height;
}

-(GLuint)createQuad {
    float positions[] = {
        -1, -1,
         1, -1,
        -1,  1,
         1,  1,
    };
    
    // Create the VAO:
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    
    // Create the VBO:
    GLuint vbo;
    GLsizeiptr size = sizeof(positions);
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, size, positions, GL_STATIC_DRAW);
    
    // Set up the vertex layout:
    glEnableVertexAttribArray(GlobI.positionSlot);
    glVertexAttribPointer(GlobI.positionSlot, 2, GL_FLOAT, GL_FALSE, 0, 0);
    
    glBindVertexArray(0);
    
    return vao;
}


// создаем границы для столкновений
-(void)createObstacles:(FBOSurface)dest{
    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    glViewport(0, 0, dest.width, dest.height);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    [StatesI useProgramm:ShadI.simpleDrawShader];
    
    const int DrawBorder = 1;
    if (DrawBorder) {
        const float T = 0.999f;
        float positions[] = { -T, -T,
                               T, -T,
                               T,  T,
                              -T,  T,
                              -T, -T };
        glLineWidth(10);
        GLuint vbo;
        GLsizeiptr size = sizeof(positions);
        glGenBuffers(1, &vbo);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, size, positions, GL_STATIC_DRAW);
        GLsizeiptr stride = 2 * sizeof(positions[0]);   // 2 итема
        glEnableVertexAttribArray(GlobI.positionSlot);
        glVertexAttribPointer(GlobI.positionSlot, 2, GL_FLOAT, GL_FALSE, stride, 0);
        glDrawArrays(GL_LINE_STRIP, 0, 5);
        glDeleteBuffers(1, &vbo);
    }
    
    const int DrawCircle = 1;
    if (DrawCircle) {
        const int slices = 64;
        float positions[slices*2*3];
        float twopi = 8*atan(1.0f);
        float theta = 0;
        float dtheta = twopi / (float) (slices - 1);
        float* pPositions = &positions[0];
        for (int i = 0; i < slices; i++) {
            *pPositions++ = -0.2;
            *pPositions++ = -0.2;
            
            *pPositions++ = 0.25f * cos(theta) * dest.height / dest.width - 0.2;
            *pPositions++ = 0.25f * sin(theta);
            theta += dtheta;
            
            *pPositions++ = 0.25f * cos(theta) * dest.height / dest.width - 0.2;
            *pPositions++ = 0.25f * sin(theta);
        }
        GLuint vbo;
        GLsizeiptr size = sizeof(positions);
        glGenBuffers(1, &vbo);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, size, positions, GL_STATIC_DRAW);
        GLsizeiptr stride = 2 * sizeof(positions[0]);
        glEnableVertexAttribArray(GlobI.positionSlot);
        glVertexAttribPointer(GlobI.positionSlot, 2, GL_FLOAT, GL_FALSE, stride, 0);
        glDrawArrays(GL_TRIANGLES, 0, slices * 3);
        glDeleteBuffers(1, &vbo);
    }
    // Cleanup
    glDeleteVertexArrays(1, &vao);
}

-(Slab)createSlabWidth:(GLsizei)width height:(GLsizei)height numChanels:(int)numComponents {
    Slab slab;
    slab.ping = [self createSurfaceWidth:width height:height numChanels:numComponents];
    slab.pong = [self createSurfaceWidth:width height:height numChanels:numComponents];
    return slab;
}

-(void)swapSlabs:(Slab&)slab{
   FBOSurface temp = slab.ping;
    slab.ping = slab.pong;
    slab.pong = temp;
}

-(void)clearSurface:(FBOSurface)s colorVal:(float) v {
    glBindFramebuffer(GL_FRAMEBUFFER, s.fboId);
    glClearColor(v, v, v, v);
    glClear(GL_COLOR_BUFFER_BIT);
}

// создается фреймбуффер с текстурой определенного количества каналов
-(FBOSurface)createSurfaceWidth:(GLsizei)width height:(GLsizei)height numChanels:(int)numComponents {
    
    // создается текстура
    GLuint textureHandle;
    glGenTextures(1, &textureHandle);
    glBindTexture(GL_TEXTURE_2D, textureHandle);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    // для текстуры выставляем нужный формат
    switch (numComponents) {
        case 1: glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, width, height, 0, GL_RED, GL_FLOAT, 0); break;
        case 2: glTexImage2D(GL_TEXTURE_2D, 0, GL_RG32F, width, height, 0, GL_RG, GL_FLOAT, 0); break;
        case 3: glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F, width, height, 0, GL_RGB, GL_FLOAT, 0); break;
        case 4: glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, width, height, 0, GL_RGBA, GL_FLOAT, 0); break;
        default: glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, width, height, 0, GL_RGBA, GL_FLOAT, 0); break;
    }
    
    NSAssert(GL_NO_ERROR == glGetError(), @"Unable to create normals texture");
    
    // фреймбуффер
    GLuint fboId;
    glGenFramebuffers(1, &fboId);
    glBindFramebuffer(GL_FRAMEBUFFER, fboId);
    
    // подключаем к фреймбуфферу текстуру которую мы создали
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, textureHandle, 0);
    NSAssert(GL_NO_ERROR == glGetError(), @"Unable to attach color buffer");
    
    // проверим фреймбуффер
    NSAssert(GL_FRAMEBUFFER_COMPLETE == glCheckFramebufferStatus(GL_FRAMEBUFFER), @"Unable to create FBO.");
    
    FBOSurface surface = { fboId, textureHandle, numComponents, width, height };
    
    // почистим данный буффер
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    
    return surface;
}

-(void)calcFPS{
    double now = [NSDate timeIntervalSinceReferenceDate];
    if((self.lastFPSUpdateTime + FPS_UPDATE_PERION) < now){
//        float frameDelta = now - self.lastRenderTime;
//        float curFps = 1.0 / frameDelta;
//        [self.fpsLabel setText:[NSString stringWithFormat:@"%.1ffps", curFps]];
//        self.lastFPSUpdateTime = now;
    }
    self.lastRenderTime = now;
}


-(void)render {
    if (self.isDraw) {
        return;
    }
    
    self.isRender = TRUE;
    
    [self update];
    
    // Set render target to the backbuffer:
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, GlobI.viewWidth, GlobI.viewHeight);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    
    // Bind visualization shader and set up blend state:
    [StatesI useProgramm:ShadI.visualizeShader];
    glEnable(GL_BLEND);
    
    // Draw ink:
    [StatesI setUniformVec3:fillColorLocation val:vec3(1.0, 0.7, 1.0)];
    [StatesI setUniformVec2:scaleLocation val:vec2(1.0/GlobI.viewWidth, 1.0/GlobI.viewHeight)];
    [StatesI setUniformInt:visualVelocityLocation val:1];
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:density.ping.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:velocity.ping.textureId];
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    // Draw obstacles:
    [StatesI setUniformVec3:fillColorLocation val:vec3(0.125f, 0.4f, 0.75f)];
    [StatesI setUniformVec2:scaleLocation val:vec2(1.0/GlobI.viewWidth, 1.0/GlobI.viewHeight)];
    [StatesI setUniformInt:visualVelocityLocation val:1];
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:hiResObstacles.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:velocity.ping.textureId];
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    // Disable blending:
    glDisable(GL_BLEND);
    self.isRender = FALSE;
}

-(void)advect:(FBOSurface)velocity src:(FBOSurface)source obst:(FBOSurface)obstacles dest:(FBOSurface)dest dis:(float) dissipation {
    [StatesI useProgramm:ShadI.advectShader];
    
    [StatesI setUniformVec2:inverseSizeLocation val:vec2(1.0f/GlobI.gridWidth, 1.0f/GlobI.gridHeight)];
    [StatesI setUniformFloat:timeStepLocation val:[GlobI deltaTime]*GlobI.timeStep];
    [StatesI setUniformFloat:dissLocLocation val:dissipation];
    [StatesI setUniformInt:sourceTextureLocation val:1];
    [StatesI setUniformInt:obstaclesTextureLocation val:2];
    
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:velocity.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:source.textureId];
    [StatesI activateTexture:GL_TEXTURE2 type:GL_TEXTURE_2D texId:obstacles.textureId];

    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)jacobi:(FBOSurface)pressure diver:(FBOSurface)divergence  obst:(FBOSurface)obstacles dest:(FBOSurface)dest {
    [StatesI useProgramm:ShadI.jacobiShader];

    [StatesI setUniformFloat:alphaLocation val:-GlobI.cellSize * GlobI.cellSize];
    [StatesI setUniformFloat:inverseBetaLocation val:0.25f];
    [StatesI setUniformInt:dSamplerLocation val:1];
    [StatesI setUniformInt:oSamplerLocation val:2];
    
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:pressure.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:divergence.textureId];
    [StatesI activateTexture:GL_TEXTURE2 type:GL_TEXTURE_2D texId:obstacles.textureId];

    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)subtractGradient:(FBOSurface)velocity pres:(FBOSurface)pressure obst:(FBOSurface)obstacles dest:(FBOSurface)dest {
    [StatesI useProgramm:ShadI.substractGradientShader];
    
    [StatesI setUniformFloat:gradientScaleLocation val:GlobI.gradientScale];
    [StatesI setUniformFloat:halfCellLocation val:0.5 / GlobI.cellSize];
    [StatesI setUniformInt:pressureTextureLocation val:1];
    [StatesI setUniformInt:pressObstaclesTextureLocation val:2];
    
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:velocity.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:pressure.textureId];
    [StatesI activateTexture:GL_TEXTURE2 type:GL_TEXTURE_2D texId:obstacles.textureId];
    
    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)computeDivergence:(FBOSurface)velocity obst:(FBOSurface)obstacles dest:(FBOSurface)dest {
    [StatesI useProgramm:ShadI.computeDivergenceShader];
    
    [StatesI setUniformFloat:divergenceHalfCellLocation val:0.5 / GlobI.cellSize];
    [StatesI setUniformInt:divergenceObstaclesLocation val:1];
    
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:velocity.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:obstacles.textureId];
    
    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)applyImpulse:(FBOSurface)dest pos:(vec2)position val:(float)value {
    [StatesI useProgramm:ShadI.splatShader];
    
    [StatesI setUniformVec2:impulsePointLocation val:position];
    [StatesI setUniformFloat:impulseRadiusLocation val:GlobI.splatRadius];
    [StatesI setUniformVec3:impulseFillColorLocation val:vec3(value)];
    
    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    glEnable(GL_BLEND);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)applyBuoyancy:(FBOSurface)velocity temp:(FBOSurface)temperature dens:(FBOSurface)density dest:(FBOSurface)dest{
    
    [StatesI useProgramm:ShadI.buoyancyShader];
    
    [StatesI setUniformInt:buoyancyTempSamplerLocation val:1];
    [StatesI setUniformInt:buoyancyInkSamplerLocation val:2];
    [StatesI setUniformFloat:buoyancyAmbTempLocation val:GlobI.ambientTemperature];
    [StatesI setUniformFloat:buoyancyTimeStepLocation val:[GlobI deltaTime]*GlobI.timeStep];
    [StatesI setUniformFloat:buoyancySigmaLocation val:GlobI.smokeBuoyancy];
    [StatesI setUniformFloat:buoyancyKappaLocation val:GlobI.smokeWeight];
    
    [StatesI activateTexture:GL_TEXTURE0 type:GL_TEXTURE_2D texId:velocity.textureId];
    [StatesI activateTexture:GL_TEXTURE1 type:GL_TEXTURE_2D texId:temperature.textureId];
    [StatesI activateTexture:GL_TEXTURE2 type:GL_TEXTURE_2D texId:density.textureId];
    
    glBindFramebuffer(GL_FRAMEBUFFER, dest.fboId);
    glEnable(GL_BLEND);
    [StatesI bindVAO:quadVao];
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

-(void)update{
    self.isUpdate = TRUE;
    glViewport(0, 0, GlobI.gridWidth, GlobI.gridHeight);
    
    [self advect:velocity.ping src:velocity.ping obst:obstacles dest:velocity.pong dis:GlobI.velocityDissipation];
    [self swapSlabs:velocity];
    
    [self advect:velocity.ping src:temperature.ping obst:obstacles dest:temperature.pong dis:GlobI.temperatureDissipation];
    [self swapSlabs:temperature];
    
    [self advect:velocity.ping src:density.ping obst:obstacles dest:density.pong dis:GlobI.densityDissipation];
    [self swapSlabs:density];
    
    [self applyBuoyancy:velocity.ping temp:temperature.ping dens:density.ping dest:velocity.pong];
    [self swapSlabs:velocity];

    [self applyImpulse:temperature.ping pos:GlobI.impulsePosition val:GlobI.impulseTemperature / fmax(GlobI.timeFromStart, 1.0)];
    [self applyImpulse:density.ping pos:GlobI.impulsePosition val:GlobI.impulseDensity];
    
    [self computeDivergence:velocity.ping obst:obstacles dest:divergence];
    [self clearSurface:pressure.ping colorVal:0];
    
    for (int i = 0; i < GlobI.numJacobiIterations; ++i) {
        [self jacobi:pressure.ping diver:divergence obst:obstacles dest:pressure.pong];
        [self swapSlabs:pressure];
    }
    
    [self subtractGradient:velocity.ping pres:pressure.ping obst:obstacles dest:velocity.pong];
    [self swapSlabs:velocity];

    self.isUpdate = FALSE;
}

-(void)keyButtonUp:(NSString*)chars{
}

-(void)keyButtonDown:(NSString*)chars{
}

-(void)mouseMoved:(float)deltaX deltaY:(float)deltaY posX:(float)posX posY:(float)posY{
    if (self.isRender || self.isUpdate) {
        return;
    }

    self.isDraw = TRUE;
    
    self.wasMoved = TRUE;
    GlobI.mouseMoveLastPos = vec2(posX, posY);


    float x = GlobI.mouseMoveLastPos.x / GlobI.viewWidth;
    float y = GlobI.mouseMoveLastPos.y / GlobI.viewHeight;
    
    int oldframeBuffer = 0;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &oldframeBuffer);
    
    GLuint vao;
    glGenVertexArrays(1, &vao);
    [StatesI bindVAO:vao];
    [StatesI useProgramm:ShadI.simpleDrawShader];
    
    const int DrawCircle = 1;
    if (DrawCircle) {
        const int slices = 64;
        float positions[slices*2*3];
        float twopi = 8*atan(1.0f);
        float theta = 0;
        float dtheta = twopi / (float) (slices - 1);
        float* pPositions = &positions[0];
        for (int i = 0; i < slices; i++) {
            *pPositions++ = (x) * 2.0 - 1;
            *pPositions++ = (y) * 2.0 - 1;
            
            *pPositions++ = (0.01f * cos(theta) + x) * 2.0 - 1;
            *pPositions++ = (0.01f * sin(theta) + y) * 2.0 - 1;
            theta += dtheta;
            
            *pPositions++ = (0.01f * cos(theta) + x) * 2.0 - 1;
            *pPositions++ = (0.01f * sin(theta) + y) * 2.0 - 1;
        }
        GLuint vbo;
        GLsizeiptr size = sizeof(positions);
        glGenBuffers(1, &vbo);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, size, positions, GL_STATIC_DRAW);
        GLsizeiptr stride = 2 * sizeof(positions[0]);
        glEnableVertexAttribArray(GlobI.positionSlot);
        glVertexAttribPointer(GlobI.positionSlot, 2, GL_FLOAT, GL_FALSE, stride, 0);
        
        vector<FBOSurface> obstaclesList;
        obstaclesList.push_back(obstacles);
        obstaclesList.push_back(hiResObstacles);
        
        for(int i = 0; i < obstaclesList.size(); i++){
            glBindFramebuffer(GL_FRAMEBUFFER, obstaclesList[i].fboId);
            glViewport(0, 0, obstaclesList[i].width, obstaclesList[i].height);
            glDrawArrays(GL_TRIANGLES, 0, slices * 3);
        }
        
        glDeleteBuffers(1, &vbo);
    }
    // Cleanup
    glDeleteVertexArrays(1, &vao);
    [StatesI bindVAO:0];
    [StatesI useProgramm:ShadI.visualizeShader];
    glBindFramebuffer(GL_FRAMEBUFFER, oldframeBuffer);
    glViewport(0, 0, GlobI.viewWidth, GlobI.viewHeight);
    
    self.isDraw = FALSE;
}

- (void)mousePressed:(float)posX posY:(float)posY{
    self.wasMoved = FALSE;
    GlobI.mouseBeginPos = vec2(posX, posY);
    GlobI.mouseMoveLastPos = GlobI.mouseBeginPos;
}

- (void)mouseUp:(float)posX posY:(float)posY{
    if (self.wasMoved == FALSE) {
        GlobI.impulsePosition = vec2(GlobI.mouseBeginPos.x / GlobI.viewWidth * GlobI.gridWidth,
                                     GlobI.mouseBeginPos.y / GlobI.viewHeight * GlobI.gridHeight);
    }
    GlobI.mouseBeginPos = vec2(0, 0);
    GlobI.mouseMoveLastPos = vec2(0, 0);
    self.wasMoved = FALSE;
}

- (id) initWithWidth:(int)width height:(int)height {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
        GLint texture_units;
        glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &texture_units);
        
        GlobI.viewWidth = width;
        GlobI.viewHeight = height;
        
        // создаем пинг-понг структуры
        velocity = [self createSlabWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:2];
        density = [self createSlabWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:1];
        pressure = [self createSlabWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:1];
        temperature = [self createSlabWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:1];
        
        // создаем fbo
        divergence = [self createSurfaceWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:3];
        obstacles = [self createSurfaceWidth:GlobI.gridWidth height:GlobI.gridHeight numChanels:3];
        hiResObstacles = [self createSurfaceWidth:GlobI.gridWidth*2 height:GlobI.gridHeight*2 numChanels:3];
        
        // заполняем областями для столкновений
        [self createObstacles:obstacles];
        [self createObstacles:hiResObstacles];
        
        // создаем vao для отрисовки
        quadVao = [self createQuad];
        
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        [self clearSurface:temperature.ping colorVal:GlobI.ambientTemperature];

        // дергаем расположение юниформов
        // visualize
        fillColorLocation = glGetUniformLocation(ShadI.visualizeShader, "uFillColor");
        visualVelocityLocation = glGetUniformLocation(ShadI.visualizeShader, "uVelocity");
        scaleLocation = glGetUniformLocation(ShadI.visualizeShader, "uScale");
        // advect
        inverseSizeLocation = glGetUniformLocation(ShadI.advectShader, "uInverseSize");
        timeStepLocation = glGetUniformLocation(ShadI.advectShader, "uTimeStep");
        dissLocLocation = glGetUniformLocation(ShadI.advectShader, "uDissipation");
        sourceTextureLocation = glGetUniformLocation(ShadI.advectShader, "uSourceTexture");
        obstaclesTextureLocation = glGetUniformLocation(ShadI.advectShader, "uObstacles");
        // jacobi
        alphaLocation = glGetUniformLocation(ShadI.jacobiShader, "uAlpha");
        inverseBetaLocation = glGetUniformLocation(ShadI.jacobiShader, "uInverseBeta");
        dSamplerLocation = glGetUniformLocation(ShadI.jacobiShader, "uDivergence");
        oSamplerLocation = glGetUniformLocation(ShadI.jacobiShader, "uObstacles");
        // gradient
        gradientScaleLocation = glGetUniformLocation(ShadI.substractGradientShader, "uGradientScale");
        halfCellLocation = glGetUniformLocation(ShadI.substractGradientShader, "uHalfInverseCellSize");
        pressureTextureLocation = glGetUniformLocation(ShadI.substractGradientShader, "uPressure");
        pressObstaclesTextureLocation = glGetUniformLocation(ShadI.substractGradientShader, "uObstacles");
        // divergence
        divergenceHalfCellLocation = glGetUniformLocation(ShadI.computeDivergenceShader, "uHalfInverseCellSize");
        divergenceObstaclesLocation = glGetUniformLocation(ShadI.computeDivergenceShader, "uObstacles");
        // impulse
        impulsePointLocation = glGetUniformLocation(ShadI.splatShader, "uPoint");
        impulseRadiusLocation = glGetUniformLocation(ShadI.splatShader, "uRadius");
        impulseFillColorLocation = glGetUniformLocation(ShadI.splatShader, "uFillColor");
        // buoyancy
        buoyancyTempSamplerLocation = glGetUniformLocation(ShadI.buoyancyShader, "uTemperature");
        buoyancyInkSamplerLocation = glGetUniformLocation(ShadI.buoyancyShader, "uDensity");
        buoyancyAmbTempLocation = glGetUniformLocation(ShadI.buoyancyShader, "uAmbientTemperature");
        buoyancyTimeStepLocation = glGetUniformLocation(ShadI.buoyancyShader, "uTimeStep");
        buoyancySigmaLocation = glGetUniformLocation(ShadI.buoyancyShader, "uSigma");
        buoyancyKappaLocation = glGetUniformLocation(ShadI.buoyancyShader, "uKappa");
        
        [self render];
        
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}

- (void) dealloc {
    destroyVAO(quadVao);
    
	[super dealloc];
}

@end
