//
//  ShadersCache.m
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 11.04.15.
//
//

#import "ShadersCache.h"
#import "ShaderCreate.h"

static ShadersCache *shadersInstance = nil;

@implementation ShadersCache

+ (ShadersCache *)instance {
    @synchronized(self) {
        if (shadersInstance == nil) {
            shadersInstance = [[self alloc] init];
        }
    }
    return shadersInstance;
}

-(id)init{
    if ((self = [super init])) {
    
        self.simpleDrawShader = buildSimpleDraw();
        self.advectShader = buildAdvect();
        self.jacobiShader = buildJacobi();
        self.substractGradientShader = buildSubstractGradient();
        self.computeDivergenceShader = buildComputeDivergence();
        self.splatShader = buildSplat();
        self.buoyancyShader = buildBuoyancy();
        self.visualizeShader = buildVisualize();
    }
    return self;
}

-(void)dealloc{
    glDeleteProgram(self.simpleDrawShader);
    glDeleteProgram(self.advectShader);
    glDeleteProgram(self.jacobiShader);
    glDeleteProgram(self.substractGradientShader);
    glDeleteProgram(self.computeDivergenceShader);
    glDeleteProgram(self.splatShader);
    glDeleteProgram(self.buoyancyShader);
    glDeleteProgram(self.visualizeShader);
    
    [super dealloc];
}

@end
