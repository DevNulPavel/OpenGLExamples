//
//  GlobalValues.m
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "GlobalValues.h"



// random integer in [mn, mx)
int random_int(int mn, int mx) {
    int diff = mx - mn;
    if (diff != 0) {
        return mn + rand() % diff;
    }
    return mn;
}

float randomFloat(float mn, float mx) {
    float rnd = (float)rand() / RAND_MAX;
    rnd *= mx - mn;
    rnd += mn;
    return rnd;
}



static GlobalValues *instance = nil;

@implementation GlobalValues

+ (GlobalValues *)instance {
    @synchronized(self) {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

-(id)init{
    if ((self = [super init])) {
        self.cameraInitPos = vec3(0.0, 0.0, 50.0);
        self.worldSize = vec3(100.0);
        self.zNear = 1.0f;
        self.zFar = 1000.0f;
        self.viewHeight = 1;
        self.viewWidth = 1;
        
        self.cellSize = 1.05;
        self.gridWidth = 256;
        self.gridHeight = 256;
        self.splatRadius = self.gridWidth/24.0;
        
        self.ambientTemperature = 0.0f;
        self.impulseTemperature = 0.9f;
        self.impulseDensity = 0.9f;
        self.numJacobiIterations = 20;
        self.timeStep = 0.1f;
        self.smokeBuoyancy = 1.0;
        self.smokeWeight = 0.05f;
        self.gradientScale = 1.025f / self.cellSize;
        self.temperatureDissipation = 0.89f;
        self.velocityDissipation = 0.999999f;
        self.densityDissipation = 0.99999f;
        self.positionSlot = 0;
        self.impulsePosition = vec2(self.gridWidth/2.0, -self.splatRadius/2.0);
        
        _initTime = [[NSDate date] timeIntervalSince1970];
        _lastRenderTime = _initTime;
    }
    return self;
}

-(void)updateProjection{
    self.projectionMatrix = perspective(float(60.0/180.0*M_PI), float((float)self.viewWidth / (float)self.viewHeight), self.zNear, self.zFar);
}

-(void)setViewHeight:(float)viewHeight{
    _viewHeight = viewHeight;
    [self updateProjection];
}

-(void)setViewWidth:(float)viewWidth{
    _viewWidth = viewWidth;
    [self updateProjection];
}

-(float)timeFromStart{
    return [[NSDate date] timeIntervalSince1970] - _initTime;
}

-(float)angle{
    // полный оборот в 10 сек
    float time = 10.0;
    float angle = fmod([self timeFromStart] * M_PI * 2 / time, M_PI*2);;
    return angle;
}

-(float)deltaTime{
    return [[NSDate date] timeIntervalSince1970] - _lastRenderTime;
}

-(void)rendered{
    _lastRenderTime = [[NSDate date] timeIntervalSince1970];
}

@end