//
//  ShaderCreate.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 05.04.15.
//
//

#import <Foundation/Foundation.h>
#import "glUtil.h"

GLuint makeShader(NSString* shaderName, NSDictionary* attributeIndexes, NSDictionary* outLayers);

GLuint buildSimpleDraw();
GLuint buildAdvect();
GLuint buildJacobi();
GLuint buildSubstractGradient();
GLuint buildComputeDivergence();
GLuint buildSplat();
GLuint buildBuoyancy();
GLuint buildVisualize();