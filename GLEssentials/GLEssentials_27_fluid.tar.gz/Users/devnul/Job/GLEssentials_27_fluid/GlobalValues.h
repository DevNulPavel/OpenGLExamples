//
//  GlobalValues.h
//  OSXGLEssentials
//
//  Created by DevNul on 10.04.15.
//
//

#import "glUtil.h"
#import "glm.hpp"
#import "ext.hpp"
#import <map>
#import <vector>
#import "FrameBufferCreate.h"

using namespace glm;
using namespace std;

// random integer in [mn, mx)
int random_int(int mn, int mx);
float randomFloat(float mn, float mx);

#define GlobI [GlobalValues instance]

@interface GlobalValues: NSObject{
    double _initTime;
    double _lastRenderTime;
}

+ (GlobalValues *)instance;
-(float)timeFromStart;
-(float)angle;
-(float)deltaTime;
-(void)rendered;

@property (nonatomic, assign) vec3 cameraInitPos;
@property (nonatomic, assign) vec3 worldSize;
@property (nonatomic, assign) mat4 projectionMatrix;
@property (nonatomic, assign) float zNear;
@property (nonatomic, assign) float zFar;

@property (nonatomic, assign) float viewWidth;
@property (nonatomic, assign) float viewHeight;

@property (nonatomic, assign) float gridWidth;
@property (nonatomic, assign) float gridHeight;
@property (nonatomic, assign) float splatRadius;

@property (nonatomic, assign) float cellSize;

@property (nonatomic, assign) float ambientTemperature;
@property (nonatomic, assign) float impulseTemperature;
@property (nonatomic, assign) float impulseDensity;
@property (nonatomic, assign) int numJacobiIterations;
@property (nonatomic, assign) float timeStep;
@property (nonatomic, assign) float smokeBuoyancy;
@property (nonatomic, assign) float smokeWeight;
@property (nonatomic, assign) float gradientScale;
@property (nonatomic, assign) float temperatureDissipation;
@property (nonatomic, assign) float velocityDissipation;
@property (nonatomic, assign) float densityDissipation;
@property (nonatomic, assign) vec2 impulsePosition;
@property (nonatomic, assign) int positionSlot;

@property (nonatomic, assign) vec2 mouseBeginPos;
@property (nonatomic, assign) vec2 mouseMoveLastPos;

@end
