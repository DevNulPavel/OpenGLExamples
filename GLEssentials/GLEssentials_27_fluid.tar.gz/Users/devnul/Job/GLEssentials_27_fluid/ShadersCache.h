//
//  ShadersCache.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 11.04.15.
//
//

#import <Foundation/Foundation.h>

#define ShadI [ShadersCache instance]

@interface ShadersCache : NSObject

@property(nonatomic, assign) GLint simpleDrawShader;
@property(nonatomic, assign) GLint advectShader;
@property(nonatomic, assign) GLint jacobiShader;
@property(nonatomic, assign) GLint substractGradientShader;
@property(nonatomic, assign) GLint computeDivergenceShader;
@property(nonatomic, assign) GLint splatShader;
@property(nonatomic, assign) GLint buoyancyShader;
@property(nonatomic, assign) GLint visualizeShader;

+ (ShadersCache *)instance;

@end
