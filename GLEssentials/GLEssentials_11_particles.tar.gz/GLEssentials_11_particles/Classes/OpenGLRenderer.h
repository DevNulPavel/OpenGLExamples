#import <Foundation/Foundation.h>
#import "glUtil.h"
#import "Camera.h"

@interface OpenGLRenderer : NSObject {

}

@property (nonatomic, retain) Camera* camera;


- (id) initWithWidth:(int)width height:(int)height;
- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void) render;
- (void) dealloc;

@end
