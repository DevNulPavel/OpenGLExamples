//
//  Camera.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 06.04.15.
//
//

#import <Foundation/Foundation.h>
#import "glm.hpp"
#import "ext.hpp"

using namespace glm;

@interface Camera : NSObject{
    vec3 _cameraPos;
    vec3 _cameraTarget;
    vec3 _cameraUp;
    float _horisontalAngle;
    float _verticalAngle;
}

-(id)initWithCameraPos:(vec3)cameraPos;
-(void)mouseMoved:(float)deltaX deltaY:(float)deltaY;
-(void)keyButtonHandle:(unichar)symbol;

-(vec3)cameraPos;
-(mat4)cameraMatrix;

@end
