//
//  ObjModel.m
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 10.04.15.
//
//

#import "ObjModel.h"
#import "glm.hpp"
#import "ext.hpp"
#import <vector>
#import <iostream>
#import <string>
#import <fstream>
#import <sstream>
#import <vector>
#import "vectorUtil.h"

using namespace glm;

class Model {
private:
    std::vector<vec4> verts_;
    std::vector<vec2> uvCoord_;
    std::vector<vec3> normales_;
    std::vector<std::vector<int> > vertexIndexes_;
    std::vector<std::vector<int> > textureIndexes_;
    std::vector<std::vector<int> > normalIndexes_;
public:
    Model(const char *filename);
    ~Model();
    
    // вершины - колво
    int vertsCount();
    int uvCoordsCount();
    int normalesCount();
    // индексы - кол-во
    int trianglesCount();
    
    // векторы индексов
    std::vector<int> vertexIndexes(int idx);
    std::vector<int> textureIndexes(int idx);
    std::vector<int> normalIndexes(int idx);
    // вершины
    vec4 vert(int i);
    vec2 uvCoord(int i);
    vec3 normal(int i);
};

Model::Model(const char *filename) : verts_(), uvCoord_(), normales_() {
    std::ifstream in;   // поток ввода данных
    in.open (filename, std::ifstream::in);  // откроем файл
    
    if (in.fail()) return;  // если не могли открыть - вырубаем
    
    std::string line;       // строка
    
    while (!in.eof()) {     // пока не кончится файл
        std::getline(in, line);     // читаем по одной линии
        std::istringstream iss(line.c_str());   // символьный поток, разделения по пробелам
        char trash = 0;
        
        // вершины
        if (!line.compare(0, 2, "v ")) {
            iss >> trash;       // закинем символ v в никуда
            vec4 v;
            v.w = 1.0;
            for (int i = 0; i < 3; i++) iss >> v[i];
            verts_.push_back(v);
        }
        // текстурные координаты (UV)
        else if (!line.compare(0, 3, "vt ")) {
            vec2 uvCoord;    // вектор в который будем пихать координаты текстуры (текстура двухмерная)
            iss >> trash;     // v в никуда
            iss >> trash;     // t в никуда
            for (int i = 0; i < 2; i++){
                iss >> uvCoord[i];
            }
            uvCoord_.push_back(uvCoord);
        }
        // нормали к вершинам
        else if (!line.compare(0, 3, "vn ")) {
            vec3 normal;    // вектор в который будем пихать координаты текстуры (текстура двухмерная)
            iss >> trash;    // v в никуда
            iss >> trash;    // n в никуда
            for (int i = 0; i < 3; i++){
                iss >> normal[i];
            }
            normales_.push_back(normal);
        }
        // треугольники (индексы), индексы текстуры, индексы нормалей
        else if (!line.compare(0, 2, "f ")) {
            
            std::vector<int> vertexIndexesItem;     // индексы треугольника
            std::vector<int> textureIndexesItem;    // индексы для текстуры
            std::vector<int> normalIndexesItem;    // индексы для текстуры
            
            int textureCoordIndex = 0;    // переменные для потокового парсинга
            int vertexIndex = 0;          // индекс
            int normalIndex = 0;          // индекс
            
            iss >> trash;           // символ f
            
            // парсим строчку на индексы
            // !!!!! АФРИКАНЕЦ !!!
            while (iss >> vertexIndex >> trash >> textureCoordIndex >> trash >> normalIndex) {
// !!!!! ГОЛОВА !!!!!
//            while (iss >> vertexIndex >> trash >> trash >> normalIndex) {
                vertexIndex--;              // в obj формате индекс начинается с 1цы
                vertexIndexesItem.push_back(vertexIndex);
                
                textureCoordIndex--;
                textureIndexesItem.push_back(textureCoordIndex);
                
                normalIndex--;
                normalIndexesItem.push_back(normalIndex);
            }
            
            vertexIndexes_.push_back(vertexIndexesItem);
            textureIndexes_.push_back(textureIndexesItem);
            normalIndexes_.push_back(normalIndexesItem);
        }
    }
    //    std::cerr << "# v# " << verts_.size() << " f# "  << vertexIndexes_.size() << std::endl;
}

Model::~Model() {
}

// вершины
int Model::vertsCount() {
    return (int)verts_.size();
}

int Model::uvCoordsCount() {
    return (int)uvCoord_.size();
}

int Model::normalesCount() {
    return (int)normales_.size();
}

// индексы
int Model::trianglesCount() {
    return (int)vertexIndexes_.size();
}

// геттеры
std::vector<int> Model::vertexIndexes(int idx) {
    return vertexIndexes_[idx];
}

std::vector<int> Model::textureIndexes(int idx) {
    return textureIndexes_[idx];
}

std::vector<int> Model::normalIndexes(int idx) {
    return normalIndexes_[idx];
}

vec4 Model::vert(int i) {
    return verts_[i];
}

vec2 Model::uvCoord(int i){
    return uvCoord_[i];
}

vec3 Model::normal(int i){
    return normales_[i];
}





GLuint buildObjVAO(NSString* filename, int *pointsCount){
    NSString* filePathName = [[NSBundle mainBundle] pathForResource:filename ofType:@"obj"];
    Model model([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
 
    *pointsCount = model.trianglesCount() * 3;
    
    // буффер вершин
    uint verticesArraySize = 4 * 3 * model.trianglesCount();
    GLfloat vertices[verticesArraySize];
    
    // буффер вершин
    uint normalsArraySize = 3 * 3 * model.trianglesCount();
    GLfloat normals[normalsArraySize];
    
    // буффер текстурных координат
    uint uvArraySize = 2 * 3 * model.trianglesCount();
    GLfloat uvs[uvArraySize];
    
    // буффер тангенсов координат
    uint tangentArraySize = 3 * 3 * model.trianglesCount();
    GLfloat tangents[tangentArraySize];
    
    for (int i = 0; i < model.trianglesCount(); i++) {
        std::vector<int> vertIndexes = model.vertexIndexes(i);
        std::vector<int> normalIndexes = model.normalIndexes(i);
        std::vector<int> uvIndexes = model.textureIndexes(i);
        
        for (int j = 0; j < vertIndexes.size(); j++) {
            int index = vertIndexes[j];
            vec4 vertex = model.vert(index);
            memcpy(&vertices[i*4*3 + j*4], &vertex, sizeof(GLfloat)*4);
        }
        for (int j = 0; j < normalIndexes.size(); j++) {
            int index = normalIndexes[j];
            vec3 normal = model.normal(index);
            memcpy(&normals[i*3*3 + j*3], &normal, sizeof(GLfloat)*3);
        }
        for (int j = 0; j < uvIndexes.size(); j++) {
            int index = uvIndexes[j];
            vec2 uv = model.uvCoord(index);
            memcpy(&uvs[i*2*3 + j*2], &uv, sizeof(GLfloat)*2);
        }
    }
    
    // тангенс
    for (int i = 0; i < model.trianglesCount() * 3; i += 3) {
        vec3 v0;
        memcpy(&v0, &(vertices[i*4+0*4]), 3*sizeof(GLfloat));
        vec3 v1;
        memcpy(&v1, &(vertices[i*4+1*4]), 3*sizeof(GLfloat));
        vec3 v2;
        memcpy(&v2, &(vertices[i*4+2*4]), 3*sizeof(GLfloat));
        
        vec2 uv0;
        memcpy(&uv0, &(uvs[i*2+0*2]), 2*sizeof(GLfloat));
        vec2 uv1;
        memcpy(&uv1, &(uvs[i*2+1*2]), 2*sizeof(GLfloat));
        vec2 uv2;
        memcpy(&uv2, &(uvs[i*2+2*2]), 2*sizeof(GLfloat));
        
        vec3 delta0 = v1 - v0;
        vec3 delta1 = v2 - v0;
        
        vec2 deltaUV0 = uv1 - uv0;
        vec2 deltaUV1 = uv2 - uv0;
        
        float divValue = (deltaUV0.x * deltaUV1.y - deltaUV0.y * deltaUV1.x);
        float r = 1.0f / divValue;
        
        vec3 tangent;
        tangent.x = (delta0.x * deltaUV1.y - delta1.x * deltaUV0.y) * r;
        tangent.y = (delta0.y * deltaUV1.y - delta1.y * deltaUV0.y) * r;
        tangent.z = (delta0.z * deltaUV1.y - delta1.z * deltaUV0.y) * r;
        
        memcpy(&tangents[i*3 + 0*3], &tangent, sizeof(tangent));
        memcpy(&tangents[i*3 + 1*3], &tangent, sizeof(tangent));
        memcpy(&tangents[i*3 + 2*3], &tangent, sizeof(tangent));
    }
    
    
    // создание 1го объекта
    GLuint vaoName;
    glGenVertexArrays(1, &vaoName);
    glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, 0);
    
    // создаем буффер объект для нормалей
    GLuint normalBufferObj;
    glGenBuffers(1, &normalBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, normalBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(normals), normals, GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
    
    // создаем буффер объект для координат текстур
    GLuint texCoordBufferObj;
    glGenBuffers(1, &texCoordBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(uvs), uvs, GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, 0);
    
    // создаем буффер объект тангенса
    GLuint tangentBufferObj;
    glGenBuffers(1, &tangentBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, tangentBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tangents), tangents, GL_STATIC_DRAW);
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 0, 0);
    
    return vaoName;
}



