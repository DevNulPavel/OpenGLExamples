//
//  TextureCreate.h
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 05.04.15.
//
//

#import <Foundation/Foundation.h>
#import "glUtil.h"

GLuint buildSkyboxTexture();
GLuint buildTexture(NSString* name);
GLuint buildEmptyCubeTexture(GLuint format);
