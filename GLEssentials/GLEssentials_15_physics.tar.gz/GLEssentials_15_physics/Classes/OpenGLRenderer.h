#import <Foundation/Foundation.h>
#import "glUtil.h"
#import "Camera.h"
#import "Model3D.h"
#import "LightObject.h"
#import "CubeModel.h"
#import "ParticlesModel.h"
#import "BillboardModel.h"
#import "PhysicsLogic.h"

@interface OpenGLRenderer : NSObject {

}


@property (atomic, assign) BOOL isRenderBullets;
@property (atomic, assign) double lastHitTime;
@property (nonatomic, retain) Camera* camera;
@property (nonatomic, retain) LightObject* light;
@property (atomic, retain) NSMutableArray* models;
@property (atomic, retain) NSMutableArray* billboards;
@property (atomic, retain) NSMutableArray* bullets;
@property (nonatomic, retain) CubeModel* pointingCube;


- (id) initWithWidth:(int)width height:(int)height;
- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void)keyButtonHandle:(unichar)symbol;
- (void) render;
- (void) dealloc;

@end
