//
//  ObjModel.m
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 10.04.15.
//
//

#import "ObjModelPhysShape.h"
#import "glm.hpp"
#import "ext.hpp"
#import <map>
#import <vector>
#import <string>
#import "ObjFileClass.h"

using namespace glm;

std::map<std::string, btConvexHullShape*> objShapeCache;

btConvexHullShape* buildObjShape(NSString* filename){
    const char* cstrName = [filename cStringUsingEncoding:NSASCIIStringEncoding];
    std::string key(cstrName);
    if (objShapeCache[key] != nil) {
        return objShapeCache[key];
    }
    
    NSString* filePathName = [[NSBundle mainBundle] pathForResource:filename ofType:@"obj"];
    Model model([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);

 
//    btTriangleMesh* mesh = new btTriangleMesh();
//    
//    for (int i = 0; i < model.trianglesCount(); i++) {
//        std::vector<int> vertIndexes = model.vertexIndexes(i);
//        
//        int index1 = vertIndexes[0];
//        vec4 vertex1 = model.vert(index1);
//
//        int index2 = vertIndexes[1];
//        vec4 vertex2 = model.vert(index2);
//        
//        int index3 = vertIndexes[2];
//        vec4 vertex3 = model.vert(index3);
//        
//        btVector3 bv1 = btVector3(vertex1.x, vertex1.y, vertex1.z);
//        btVector3 bv2 = btVector3(vertex2.x, vertex2.y, vertex2.z);
//        btVector3 bv3 = btVector3(vertex3.x, vertex3.y, vertex3.z);
//        
//        mesh->addTriangle(bv1, bv2, bv3);
//    }
//    btBvhTriangleMeshShape* shape = new btBvhTriangleMeshShape(mesh, TRUE);
    
    btConvexHullShape* shape = new btConvexHullShape();
    for (int i = 0; i < model.vertsCount(); i++) {
        vec4 vertex = model.vert(i);
        btVector3 bv = btVector3(vertex.x, vertex.y, vertex.z);
        shape->addPoint(bv);
    }
    
    objShapeCache[key] = shape;
    
    return shape;
}


