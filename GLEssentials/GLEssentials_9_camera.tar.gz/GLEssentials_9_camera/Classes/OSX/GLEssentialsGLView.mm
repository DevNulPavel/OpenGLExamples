
#import "GLEssentialsGLView.h"
#import "OpenGLRenderer.h"

@interface GLEssentialsGLView (PrivateMethods)
- (void) initGL;
@end


@implementation GLEssentialsGLView

OpenGLRenderer* m_renderer;

- (CVReturn) getFrameForTime:(const CVTimeStamp*)outputTime {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	[self drawView];
	
	[pool release];
	return kCVReturnSuccess;
}

static CVReturn MyDisplayLinkCallback(CVDisplayLinkRef displayLink,
									  const CVTimeStamp* now,
									  const CVTimeStamp* outputTime,
									  CVOptionFlags flagsIn,
									  CVOptionFlags* flagsOut, 
									  void* displayLinkContext) {
    CVReturn result = [(GLEssentialsGLView*)displayLinkContext getFrameForTime:outputTime];
    return result;
}

- (void) awakeFromNib {
    NSOpenGLPixelFormatAttribute attrs[] = {
		NSOpenGLPFADoubleBuffer,
		NSOpenGLPFADepthSize, 24,
		NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,    // используем опенгл 4.1
		0
	};
	
	NSOpenGLPixelFormat* pf = [[[NSOpenGLPixelFormat alloc] initWithAttributes:attrs] autorelease];
	if (!pf) {
		NSLog(@"No OpenGL pixel format");
	}
	   
    NSOpenGLContext* context = [[[NSOpenGLContext alloc] initWithFormat:pf shareContext:nil] autorelease];
	CGLEnable([context CGLContextObj], kCGLCECrashOnRemovedFunctions);
	
    [self setPixelFormat:pf];
    [self setOpenGLContext:context];
}

- (void) prepareOpenGL {
	[super prepareOpenGL];
	
	[self initGL];
	
	// Create a display link capable of being used with all active displays
	CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
	
	// Set the renderer output callback function
	CVDisplayLinkSetOutputCallback(displayLink, &MyDisplayLinkCallback, self);
	
	// Set the display link for the current renderer
	CGLContextObj cglContext = [[self openGLContext] CGLContextObj];
	CGLPixelFormatObj cglPixelFormat = [[self pixelFormat] CGLPixelFormatObj];
	CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);
	
	// Activate the display link
	CVDisplayLinkStart(displayLink);
	
	// Register to be notified when the window closes so we can stop the displaylink
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(windowWillClose:)
												 name:NSWindowWillCloseNotification
											   object:[self window]];
}

- (void) windowWillClose:(NSNotification*)notification {
	// Stop the display link when the window is closing because default
	// OpenGL render buffers will be destroyed.  If display link continues to
	// fire without renderbuffers, OpenGL draw calls will set errors.
	
	CVDisplayLinkStop(displayLink);
}

- (void) initGL {
	[[self openGLContext] makeCurrentContext];
	
	// Synchronize buffer swaps with vertical refresh rate
	GLint swapInt = 1;
	[[self openGLContext] setValues:&swapInt forParameter:NSOpenGLCPSwapInterval];
	
	// Init our renderer.  Use 0 for the defaultFBO which is appropriate for
	// OSX (but not iOS since iOS apps must create their own FBO)
    // Get the view size in Points
    NSRect viewRectPoints = [self bounds];
	m_renderer = [[OpenGLRenderer alloc] initWithWidth:viewRectPoints.size.width height:viewRectPoints.size.height];
}

- (void) reshape {
	[super reshape];
	CGLLockContext([[self openGLContext] CGLContextObj]);

	// Get the view size in Points
	NSRect viewRectPoints = [self bounds];
    
	// Set the new dimensions in our renderer
	[m_renderer resizeWithWidth:viewRectPoints.size.width
                      AndHeight:viewRectPoints.size.height];
	
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
}


- (void)renewGState {
	[[self window] disableScreenUpdatesUntilFlush];

	[super renewGState];
}

- (void) drawRect: (NSRect) theRect {
	[self drawView];
}

- (void) drawView {
	[[self openGLContext] makeCurrentContext];

	CGLLockContext([[self openGLContext] CGLContextObj]);

	[m_renderer render];

	CGLFlushDrawable([[self openGLContext] CGLContextObj]);
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
}

- (void) keyDown:(NSEvent *)event{
    unichar c = [[event charactersIgnoringModifiers] characterAtIndex:0];
    [m_renderer.camera keyButtonHandle:c];
}

-(void)mouseMoved:(NSEvent *)theEvent{
    float deltaX = theEvent.deltaX;
    float deltaY = theEvent.deltaY;
    
    [m_renderer.camera mouseMoved:deltaX deltaY:deltaY];
}

- (void) dealloc {
	CVDisplayLinkStop(displayLink);
	CVDisplayLinkRelease(displayLink);
	[m_renderer release];
	
	[super dealloc];
}
@end
