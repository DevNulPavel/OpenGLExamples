//
//  Camera.m
//  OSXGLEssentials
//
//  Created by Pavel Ershov on 06.04.15.
//
//

#import "Camera.h"

#define X_MOUSE_STEP 0.002f
#define Y_MOUSE_STEP 0.002f
#define KEY_STEP 5.0f


@implementation Camera

-(id)initWithCameraPos:(vec3)cameraPos{
    if ((self = [super init])) {
        _cameraPos = cameraPos;
        _horisontalAngle = 0.0/*M_PI/2*/;
        _verticalAngle = 0.0;
        
        [self update];
    }
    
    return self;
}

-(void)mouseMoved:(float)deltaX deltaY:(float)deltaY{
    _horisontalAngle += deltaX * X_MOUSE_STEP;
    _verticalAngle -= deltaY * Y_MOUSE_STEP;
    
    if (_verticalAngle > M_PI/2.0 - 0.001) {
        _verticalAngle = M_PI/2.0 - 0.001;
    }
    if (_verticalAngle < -M_PI/2.0 + 0.001) {
        _verticalAngle = -M_PI/2.0 + 0.001;
    }
}

-(void)keyButtonHandle:(unichar)symbol{
    [self update];
    
    switch (symbol) {
        case 'a':{
            // по правилу левой руки (указательный вверх 1, средний к цели 2 = большой направо)
            vec3 rightDir = normalize(cross(_cameraUp, _cameraTarget));
            _cameraPos += rightDir * KEY_STEP;
        }break;
        case 'd':{
            // по правилу левой руки (указательный к цели 1, средний вверх 2 = большой налево)
            vec3 leftDir = normalize(cross(_cameraTarget, _cameraUp));
            _cameraPos += leftDir * KEY_STEP;
        }break;
        case 'w':{
            _cameraPos += _cameraTarget * KEY_STEP;
        }break;
        case 's':{
            _cameraPos -= _cameraTarget * KEY_STEP;
        }break;
        case 'e':{
            _cameraPos += vec3(0.0, 1.0, 0.0)* KEY_STEP;
        }break;
        case 'q':{
            _cameraPos -= vec3(0.0, 1.0, 0.0)* KEY_STEP;
        }break;
    }
}

-(void)update{
    vec3 target(1.0f, 0.0f, 0.0f);
    
    // поворачиваем вектор, который направлен направо по оси y
    vec3 verticalAxis(0.0f, 1.0f, 0.0f);
    
    // поворачиваем по оси y
    target = normalize(rotate(target, _horisontalAngle, verticalAxis));
    
    //  вычисляем вычисляем горизонтальное направление после поворота
    vec3 horisontalAxis = normalize(cross(verticalAxis, target));
    
    // смотрим вверх-вниз
    _cameraTarget = rotate(target, _verticalAngle, horisontalAxis);
    
    // вычисляем направление "вверх"
    _cameraUp = normalize(cross(target, horisontalAxis));
}

-(vec3)cameraPos{
    return _cameraPos;
}

-(mat4)cameraMatrix{
    [self update];
    mat4 camera = lookAt(_cameraPos, _cameraPos + _cameraTarget, _cameraUp);
    return camera;
}

@end
