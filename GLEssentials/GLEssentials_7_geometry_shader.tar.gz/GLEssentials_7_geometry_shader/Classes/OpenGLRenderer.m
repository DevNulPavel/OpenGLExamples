#import "OpenGLRenderer.h"
#import "matrixUtil.h"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"
#import "VAOCreate.h"
#import "ShaderCreate.h"
#import "TextureCreate.h"
#import "FrameBufferCreate.h"

#ifndef NULL
#define NULL 0
#endif


@implementation OpenGLRenderer

GLfloat _angle = 0.0;
GLuint _viewWidth;
GLuint _viewHeight;


// буффера и текстуры
GLuint _shadowRenderFBO;
GLuint _shadowMapTexture;

// скайбокс
GLint _skyboxShader;
GLint _skyboxTextureLocation;
GLuint _skyboxModelViewLocation;
GLuint _skyboxTexture;
GLuint _skyboxVAO;
GLint _skyboxElementsCount;

// модель
GLint _shaderProgram;
GLint _modelVAO;
GLint _elementsCount;
GLint _elementsType;
GLint _modelTexture;
GLint _normalsTexture;
GLint _mvpMatrixLocation;
GLint _mvMatrixLocation;
GLint _inShadowMatrixLocation;
GLint _lightPosLocation;
GLint _modelTextureLocation;
GLint _shadowMapTextureLocation;
GLint _normalsTextureLocation;

// спрайт
GLint _spriteShaderProgram;
GLint _spriteTextureLocation;
GLint _spriteVAO;
GLint _spriteElementsCount;


// биллборд
GLint _billboardShaderProgram;
GLint _billboardTextureLocation;
GLint _billboardMVPLocation;
GLint _billboardTexture;
GLint _billboardPointsVAO;
GLint _billboardPointsElementsCount;


-(void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);
    
	_viewWidth = width;
	_viewHeight = height;
    
    buildShadowFBO(_viewWidth, _viewHeight, &_shadowRenderFBO, &_shadowMapTexture);
}

-(void)renderFigures:(BOOL)toShadowMap{
    GLfloat modelView[16];
    GLfloat shadowModelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    GLfloat shadowMvp[16];
    float aspectRatio = (float)_viewWidth / (float)_viewHeight;
    
    // включаем шейдер для отрисовки
    glUseProgram(_shaderProgram);
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxTranslateApply(modelView, 0, 0, -2.0);  // матрица с помещением модели в нужное место
    if (toShadowMap) {
        mtxRotateApply(modelView, _angle + 25.0, 0, 1, 0);   // крутим модель по таймеру
    }else{
        mtxRotateApply(modelView, _angle, 0, 1, 0);   // крутим модель по таймеру
    }
    mtxRotateApply(modelView, -90.0, 1, 0, 0);
    mtxScaleApply(modelView, 0.005, 0.005, 0.005);
    
    // в пространстве тени
    mtxLoadIdentity(shadowModelView);
    mtxTranslateApply(shadowModelView, 0, 0, -2.0);  // матрица с помещением модели в нужное место
    mtxRotateApply(shadowModelView, _angle + 25.0, 0, 1, 0);   // крутим модель по таймеру
    mtxRotateApply(shadowModelView, -90.0, 1, 0, 0);
    mtxScaleApply(shadowModelView, 0.005, 0.005, 0.005);
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadPerspective(projection, 60, aspectRatio, 1.0, 3.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(shadowMvp, projection, shadowModelView);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_mvpMatrixLocation, 1, GL_FALSE, mvp);
    glUniformMatrix4fv(_mvMatrixLocation, 1, GL_FALSE, modelView);
    glUniformMatrix4fv(_inShadowMatrixLocation, 1, GL_FALSE, shadowMvp);
    glUniform3f(_lightPosLocation, 1.0, 0.0, 1.0);
    
    if (toShadowMap == FALSE) {
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 1);
        glUniform1i(_normalsTextureLocation, 2);
        
        // текстура модели
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, _modelTexture);
        
        // текстура тени
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
        
        // текстура тени
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 0);
        glUniform1i(_normalsTexture, 0);
    }
    
    
    // включаем объект аттрибутов вершин
    glBindVertexArray(_modelVAO);
    glDrawElements(GL_TRIANGLES, _elementsCount, _elementsType, 0);
    glBindVertexArray(0);
}

-(void)renderSprite{
    glUseProgram(_spriteShaderProgram);
    glUniform1i(_spriteTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
    
    glDisable(GL_DEPTH_TEST);
    
    glBindVertexArray(_spriteVAO);
    glDrawElements(GL_TRIANGLES, _spriteElementsCount, GL_UNSIGNED_INT, 0);
    
    glEnable(GL_DEPTH_TEST);
}

-(void)renderSkybox{
    GLfloat modelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxRotateApply(modelView, _angle, 0, 1, 0);   // крутим модель по таймеру
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadPerspective(projection, 60, (float)_viewWidth / (float)_viewHeight, 1.0, 3.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);

    // шейдер
    glUseProgram(_skyboxShader);
    
    glUniform1i(_skyboxTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexture);
    
    glUniformMatrix4fv(_skyboxModelViewLocation, 1, GL_FALSE, mvp);
    
    // старые режимы
    GLint oldCullFaceMode;
    glGetIntegerv(GL_CULL_FACE_MODE, &oldCullFaceMode);
    GLint oldDepthTestMode;
    glGetIntegerv(GL_DEPTH_FUNC, &oldDepthTestMode);
    
    glCullFace(GL_FRONT);
    glDepthFunc(GL_LEQUAL);
    
    glBindVertexArray(_skyboxVAO);
    glDrawElements(GL_TRIANGLES, _skyboxElementsCount, GL_UNSIGNED_INT, 0);
    
    glCullFace(oldCullFaceMode);
    glDepthFunc(oldDepthTestMode);
}

-(void)renderBillboards{
    GLfloat modelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxTranslateApply(modelView, 0, 0, -2.0);
    mtxScaleApply(modelView, 0.2, 0.2, 0.2);
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadPerspective(projection, 60, (float)_viewWidth / (float)_viewHeight, 1.0, 3.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);
    
    // шейдер
    glUseProgram(_billboardShaderProgram);
    
    glUniform1i(_billboardTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _billboardTexture);
    
    glUniformMatrix4fv(_billboardMVPLocation, 1, GL_FALSE, mvp);
    
    // точки
    glBindVertexArray(_billboardPointsVAO);
    glDrawElements(GL_POINTS, _billboardPointsElementsCount, GL_UNSIGNED_INT, 0);
}


- (void)render {
    
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, _shadowRenderFBO);
    glClear(GL_DEPTH_BUFFER_BIT);
    [self renderFigures:TRUE];
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    
    // очистим буфферы для отображения
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    [self renderFigures:FALSE];
    [self renderBillboards];
    [self renderSkybox];
    
    // спрайт для дебуга
    [self renderSprite];
    
	// увеличиваем угол поворота персонажа
	_angle++;
}

- (id) initWithWidth:(int)width height:(int)height {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
		
		_viewWidth = width;
		_viewHeight = height;
		
		_angle = 0;

        buildShadowFBO(_viewWidth, _viewHeight, &_shadowRenderFBO, &_shadowMapTexture);
        
		//////////////////////////////
		// модель //
		//////////////////////////////
		
		// на основании модели создаем обхект аттрибутов вершин
		_modelVAO = buildModelVAO(&_elementsCount, &_elementsType);
        _spriteVAO = spriteVAO(&_spriteElementsCount);
        _skyboxVAO = skyboxVAO(&_skyboxElementsCount);
        _billboardPointsVAO = billboardVAO(&_billboardPointsElementsCount);
		
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
		
        // модель
		_shaderProgram = buildProgramFunc();
		_mvpMatrixLocation = glGetUniformLocation(_shaderProgram, "modelViewProjectionMatrix");
        _mvMatrixLocation =  glGetUniformLocation(_shaderProgram, "modelViewMatrix");
        _inShadowMatrixLocation =  glGetUniformLocation(_shaderProgram, "toShadowMapMatrix");
        _lightPosLocation =  glGetUniformLocation(_shaderProgram, "lightPos");
        _modelTextureLocation = glGetUniformLocation(_shaderProgram, "textureIm");
        _shadowMapTextureLocation = glGetUniformLocation(_shaderProgram, "u_shadowMapTexture");
        _normalsTextureLocation = glGetUniformLocation(_shaderProgram, "u_normalsTexture");
        
        // спрайт
        _spriteShaderProgram = buildSpriteProgram();
        _spriteTextureLocation = glGetUniformLocation(_spriteShaderProgram, "u_texture");
        
        // скайбокс
        _skyboxShader = buildSkyboxProgram();
        _skyboxTextureLocation = glGetUniformLocation(_skyboxShader, "u_cubemapTexture");
        _skyboxModelViewLocation = glGetUniformLocation(_skyboxShader, "u_modelViewProj");
        
        // билборд
        _billboardShaderProgram = buildBillboardProgram();
        _billboardMVPLocation = glGetUniformLocation(_billboardShaderProgram, "u_modelViewProj");
        _billboardTextureLocation = glGetUniformLocation(_billboardShaderProgram, "u_texture");
        
        
        ////////////////////////////////////////////////
        // загрузка текстуры
        ////////////////////////////////////////////////
        
        _modelTexture = buildTexture(@"demon");
        _normalsTexture = buildTexture(@"demon_normals");
        _skyboxTexture = buildSkyboxTexture();
        _billboardTexture = buildTexture(@"monster_hellknight");
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
		// включаем тест глубины
        glEnable(GL_CULL_FACE);     // не рисует заднюю часть
        glFrontFace(GL_CCW);        // передняя часть при обходе против часовой стрелки
		glEnable(GL_DEPTH_TEST);    // тест глубины
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		
		// Reset the m_characterAngle which is incremented in render
		_angle = 0;
		
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}

- (void) dealloc {
	destroyVAO(_modelVAO);
    destroyVAO(_skyboxVAO);
    destroyVAO(_spriteVAO);
	glDeleteProgram(_shaderProgram);
    glDeleteProgram(_skyboxShader);
    glDeleteProgram(_spriteShaderProgram);
    
	[super dealloc];
}

@end
