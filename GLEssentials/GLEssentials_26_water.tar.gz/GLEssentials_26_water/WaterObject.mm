//
//  WaterObject.m
//  OSXGLEssentials
//
//  Created by DevNul on 14.05.15.
//
//

#import "WaterObject.h"
#import "TextureCreate.h"

@implementation WaterObject

-(id)init{
    if ((self = [super init])) {
        [self generateShader];
    }
    return self;
}

-(id)initWithFilename:(NSString *)filename{
    if ((self = [super init])) {
        [self generateShader];
    }
    return self;
}

#pragma mark - Model

-(void)createTextures{
    self.textureA = buildEmpty2DTexture(GL_R32F, GL_RED, 256, 256);
    self.textureB = buildEmpty2DTexture(GL_R32F, GL_RED, 256, 256);
}

-(void)generateShader{
}

-(void)renderModelToLight:(LightObject*)light faceIndex:(int)faceIndex{
}

-(void)renderToGBuffer:(Camera *)cameraObj{
}

-(void)dealloc{    
    // TODO: удаление текстур
    [super dealloc];
}

@end
