#import "OpenGLRenderer.h"
#import "matrixUtil.h"
#import "imageUtil.h"
#import "modelUtil.h"
#import "sourceUtil.h"


#define GetGLError(){                                   \
	GLenum err = glGetError();							\
	while (err != GL_NO_ERROR) {						\
		NSLog(@"GLError %s set in File:%s Line:%d\n",	\
				GetGLErrorString(err),					\
				__FILE__,								\
				__LINE__);								\
		err = glGetError();								\
	}													\
}

#ifndef NULL
#define NULL 0
#endif

#define BUFFER_OFFSET(i) ((char *)NULL + (i))


@implementation OpenGLRenderer

GLfloat _angle = 0.0;
GLuint _viewWidth;
GLuint _viewHeight;


// буффера и текстуры
GLuint _shadowRenderFBO;
GLuint _shadowMapTexture;

// скайбокс
GLint _skyboxShader;
GLint _skyboxTextureLocation;
GLuint _skyboxModelViewLocation;
GLuint _skyboxTexture;
GLuint _skyboxVAO;
GLuint _skyboxElementsCount;

// модель
GLint _shaderProgram;
GLint _vertexAttObject;
GLint _elementsCount;
GLint _elementsType;
GLint _modelTexture;
GLint _normalsTexture;
GLint _mvpMatrixLocation;
GLint _mvMatrixLocation;
GLint _inShadowMatrixLocation;
GLint _lightPosLocation;
GLint _modelTextureLocation;
GLint _shadowMapTextureLocation;
GLint _normalsTextureLocation;

// спрайт
GLint _spriteShaderProgram;
GLint _spriteTextureLocation;
GLint _spriteAttObject;
GLint _spriteElementsCount;


- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height {
	glViewport(0, 0, width, height);
    
	_viewWidth = width;
	_viewHeight = height;
    
    [self buildShadowFBO];
}

-(void)renderFigures:(BOOL)toShadowMap{
    GLfloat modelView[16];
    GLfloat shadowModelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    GLfloat shadowMvp[16];
    float aspectRatio = (float)_viewWidth / (float)_viewHeight;
    
    // включаем шейдер для отрисовки
    glUseProgram(_shaderProgram);
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxTranslateApply(modelView, 0, 0, -2.0);  // матрица с помещением модели в нужное место
    if (toShadowMap) {
        mtxRotateApply(modelView, _angle + 25.0, 0, 1, 0);   // крутим модель по таймеру
    }else{
        mtxRotateApply(modelView, _angle, 0, 1, 0);   // крутим модель по таймеру
    }
    mtxRotateApply(modelView, -90.0, 1, 0, 0);
    mtxScaleApply(modelView, 0.005, 0.005, 0.005);
    
    // в пространстве тени
    mtxLoadIdentity(shadowModelView);
    mtxTranslateApply(shadowModelView, 0, 0, -2.0);  // матрица с помещением модели в нужное место
    mtxRotateApply(shadowModelView, _angle + 25.0, 0, 1, 0);   // крутим модель по таймеру
    mtxRotateApply(shadowModelView, -90.0, 1, 0, 0);
    mtxScaleApply(shadowModelView, 0.005, 0.005, 0.005);
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadPerspective(projection, 60, aspectRatio, 1.0, 3.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(shadowMvp, projection, shadowModelView);
    
    // помещаем матрицу модельвидпроекция в шейдер (указываем)
    glUniformMatrix4fv(_mvpMatrixLocation, 1, GL_FALSE, mvp);
    glUniformMatrix4fv(_mvMatrixLocation, 1, GL_FALSE, modelView);
    glUniformMatrix4fv(_inShadowMatrixLocation, 1, GL_FALSE, shadowMvp);
    glUniform3f(_lightPosLocation, 1.0, 0.0, 1.0);
    
    if (toShadowMap == FALSE) {
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 1);
        glUniform1i(_normalsTextureLocation, 2);
        
        // текстура модели
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, _modelTexture);
        
        // текстура тени
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
        
        // текстура тени
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, _normalsTexture);
    } else {
        glActiveTexture(GL_TEXTURE0);
        glUniform1i(_modelTextureLocation, 0);
        glUniform1i(_shadowMapTextureLocation, 0);
        glUniform1i(_normalsTexture, 0);
    }
    
    
    // включаем объект аттрибутов вершин
    glBindVertexArray(_vertexAttObject);
    glDrawElements(GL_TRIANGLES, _elementsCount, _elementsType, 0);
    glBindVertexArray(0);
}

-(void)renderSprite{
    glUseProgram(_spriteShaderProgram);
    glUniform1i(_spriteTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
    
    glDisable(GL_DEPTH_TEST);
    
    glBindVertexArray(_spriteAttObject);
    glDrawElements(GL_TRIANGLES, _spriteElementsCount, GL_UNSIGNED_INT, 0);
    
    glEnable(GL_DEPTH_TEST);
}

-(void)renderSkybox{
    GLfloat modelView[16];
    GLfloat projection[16];
    GLfloat mvp[16];
    
    // обновляем матрицу модели (ОБРАТНЫЙ ПОРЯДОК)
    mtxLoadIdentity(modelView);
    mtxRotateApply(modelView, _angle, 0, 1, 0);   // крутим модель по таймеру
    
    // вычислим матрицу проекции в массив projection
    mtxLoadIdentity(projection);
    mtxLoadPerspective(projection, 60, (float)_viewWidth / (float)_viewHeight, 1.0, 3.0);
    
    // умножаем матрицу проекции на вью на матрицу модели и получаем матрицу для домножения на точку
    mtxMultiply(mvp, projection, modelView);

    // шейдер
    glUseProgram(_skyboxShader);
    
    glUniform1i(_skyboxTextureLocation, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexture);
    
    glUniformMatrix4fv(_skyboxModelViewLocation, 1, GL_FALSE, mvp);
    
    // старые режимы
    GLint oldCullFaceMode;
    glGetIntegerv(GL_CULL_FACE_MODE, &oldCullFaceMode);
    GLint oldDepthTestMode;
    glGetIntegerv(GL_DEPTH_FUNC, &oldDepthTestMode);
    
    glCullFace(GL_FRONT);
    glDepthFunc(GL_LEQUAL);
    
    glBindVertexArray(_skyboxVAO);
    glDrawElements(GL_TRIANGLES, _skyboxElementsCount, GL_UNSIGNED_INT, 0);
    
    glCullFace(oldCullFaceMode);
    glDepthFunc(oldDepthTestMode);
}

- (void) render {
    
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, _shadowRenderFBO);
    glClear(GL_DEPTH_BUFFER_BIT);
    [self renderFigures:TRUE];
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    
    // очистим буфферы для отображения
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    [self renderFigures:FALSE];
    [self renderSkybox];
    
    // спрайт для дебуга
    [self renderSprite];
    
	// увеличиваем угол поворота персонажа
	_angle++;
}

- (GLuint) spriteVAO {
    _spriteElementsCount = 6;
    
    GLfloat points[] = {0.2, -1.0, -1.0,
                        0.2, -0.2, -1.0,
                        1.0, -0.2, -1.0,
                        1.0, -1.0, -1.0};
    GLfloat texCoords[] = { 0.0, 0.0,
                            0.0, 1.0,
                            1.0, 1.0,
                            1.0, 0.0};
    GLuint indexes[] = {0, 3, 1,
                        3, 2, 1};
    
    // создание 1го объекта
    GLuint vaoName;
    glGenVertexArrays(1, &vaoName);
    glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points), points, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,		// индекс аттрибута в шейдере
                          3,	// из скольки элементов состоит (вершина из 3х значений)
                          GL_FLOAT,	// тип данных
                          GL_FALSE,				// данные не являются нормализованными
                          3 * sizeof(GL_FLOAT), // шаг между отдельными элементами в байтах 3*sizeof(float)
                          BUFFER_OFFSET(0));	// данные с нулевым оффсетом
    
    
    // создаем буффер объект для нормалей
    GLuint texCoordName;
    glGenBuffers(1, &texCoordName);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordName);
    glBufferData(GL_ARRAY_BUFFER, sizeof(texCoords), texCoords, GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,
                          2,
                          GL_FLOAT,
                          GL_FALSE,
                          2 * sizeof(GL_FLOAT),
                          BUFFER_OFFSET(0));
    
    // создание буффера индексов
    GLuint elementBufferName;
    glGenBuffers(1, &elementBufferName);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferName);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexes), indexes, GL_STATIC_DRAW);
    
    GetGLError();
    
    glBindVertexArray(0);
    
    return vaoName;
}

- (GLuint) skyboxVAO {
    _skyboxElementsCount = 36;
    
    GLfloat points[] = {        // vert
                        // front
                        -1.0, -1.0,  1.0,
                        1.0, -1.0,  1.0,
                        1.0,  1.0,  1.0,
                        -1.0,  1.0,  1.0,
                        // top
                        -1.0,  1.0,  1.0,
                        1.0,  1.0,  1.0,
                        1.0,  1.0, -1.0,
                        -1.0,  1.0, -1.0,
                        // back
                        1.0, -1.0, -1.0,
                        -1.0, -1.0, -1.0,
                        -1.0,  1.0, -1.0,
                        1.0,  1.0, -1.0,
                        // bottom
                        -1.0, -1.0, -1.0,
                        1.0, -1.0, -1.0,
                        1.0, -1.0,  1.0,
                        -1.0, -1.0,  1.0,
                        // left
                        -1.0, -1.0, -1.0,
                        -1.0, -1.0,  1.0,
                        -1.0,  1.0,  1.0,
                        -1.0,  1.0, -1.0,
                        // right
                        1.0, -1.0,  1.0,
                        1.0, -1.0, -1.0,
                        1.0,  1.0, -1.0,
                        1.0,  1.0,  1.0,};
    GLuint indexes[] = {// front
        // front
        0,  1,  2,
        2,  3,  0,
        // top
        4,  5,  6,
        6,  7,  4,
        // back
        8,  9, 10,
        10, 11,  8,
        // bottom
        12, 13, 14,
        14, 15, 12,
        // left
        16, 17, 18,
        18, 19, 16,
        // right
        20, 21, 22,
        22, 23, 20,};
    
    // создание 1го объекта
    GLuint vaoName;
    glGenVertexArrays(1, &vaoName);
    glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points), points, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,		// индекс аттрибута в шейдере
                          3,	// из скольки элементов состоит (вершина из 3х значений)
                          GL_FLOAT,	// тип данных
                          GL_FALSE,				// данные не являются нормализованными
                          0, // шаг между отдельными элементами в байтах 3*sizeof(float)
                          BUFFER_OFFSET(0));	// данные с нулевым оффсетом
    
    // создание буффера индексов
    GLuint elementBufferName;
    glGenBuffers(1, &elementBufferName);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferName);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexes), indexes, GL_STATIC_DRAW);
    
    GetGLError();
    
    glBindVertexArray(0);
    
    return vaoName;
}

// создание объекта аттрибутов вершин
- (GLuint) buildModelVAO {
    NSString* filePathName = [[NSBundle mainBundle] pathForResource:@"demon" ofType:@"model"];
    demoModel* model = mdlLoadModel([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    _elementsCount = model->elementArraySize;
    _elementsType = model->elementType;

    GLuint vaoName;
	glGenVertexArrays(1, &vaoName);
	glBindVertexArray(vaoName);
    
    // создаем буффер вершин
    GLuint posBufferObj;
    glGenBuffers(1, &posBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, posBufferObj);
    glBufferData(GL_ARRAY_BUFFER, model->positionArraySize, model->positions, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, model->positionSize, model->positionType, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    
    // создаем буффер объект для нормалей
    GLuint normalBufferObj;
    glGenBuffers(1, &normalBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, normalBufferObj);
    glBufferData(GL_ARRAY_BUFFER, model->normalArraySize, model->normals, GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, model->normalSize, model->normalType, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    
    // создаем буффер объект для координат текстур
    GLuint texCoordBufferObj;
    glGenBuffers(1, &texCoordBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordBufferObj);
    glBufferData(GL_ARRAY_BUFFER, model->texcoordArraySize, model->texcoords, GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, model->texcoordSize, model->texcoordType, GL_FALSE, 0, BUFFER_OFFSET(0));

    
    // создаем буффер объект тангенса
    GLuint tangentBufferObj;
    glGenBuffers(1, &tangentBufferObj);
    glBindBuffer(GL_ARRAY_BUFFER, tangentBufferObj);
    glBufferData(GL_ARRAY_BUFFER, model->tangentArraySize, model->tangent, GL_STATIC_DRAW);
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, model->tangentSize, model->tangentType, GL_FALSE, 0, BUFFER_OFFSET(0));
    
    
    // создание буффера индексов
    GLuint elementBufferObj;
    glGenBuffers(1, &elementBufferObj);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBufferObj);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, model->elementArraySize, model->elements, GL_STATIC_DRAW);
	
    // удаляем
    mdlDestroyModel(model);
    
    glBindVertexArray(0);
    
	GetGLError();
	
	return vaoName;
}

// создание объекта текстуры
-(GLuint)buildModelTexture:(NSString*)name {
    
    NSString* filePathName = [[NSBundle mainBundle] pathForResource:name ofType:@"png"];
    demoImage *image = imgLoadImage([filePathName cStringUsingEncoding:NSASCIIStringEncoding], false);
    
    GLuint texName;
    glGenTextures(1, &texName);
    glBindTexture(GL_TEXTURE_2D, texName);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    
    // Indicate that pixel rows are tightly packed
    //  (defaults to stride of 4 which is kind of only good for
    //  RGBA or FLOAT data types)
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    
    glTexImage2D(GL_TEXTURE_2D, 0, image->format, image->width, image->height, 0, image->format, image->type, image->data);
    
    glGenerateMipmap(GL_TEXTURE_2D);
    
    GetGLError();
    
    imgDestroyImage(image);
    
    return texName;
}

-(GLuint)buildSkyboxTexture{
    glGenTextures(1, &_skyboxTexture);
    glBindTexture(GL_TEXTURE_CUBE_MAP, _skyboxTexture);  // кубическая текстура
    
    NSArray* names = @[@"sp3back",
                       @"sp3front",
                       @"sp3bot",
                       @"sp3top",
                       @"sp3left",
                       @"sp3right",];
    NSArray* types = @[@(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z),
                       @(GL_TEXTURE_CUBE_MAP_POSITIVE_Z),
                       @(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y),
                       @(GL_TEXTURE_CUBE_MAP_POSITIVE_Y),
                       @(GL_TEXTURE_CUBE_MAP_NEGATIVE_X),
                       @(GL_TEXTURE_CUBE_MAP_POSITIVE_X),];
    for (int i = 0; i < names.count; i++) {
        NSString* name = names[i];
        NSString* filePathName = [[NSBundle mainBundle] pathForResource:name ofType:@"png"];
        demoImage *image = imgLoadImage([filePathName cStringUsingEncoding:NSASCIIStringEncoding], false);
        
        glTexImage2D([types[i] intValue], 0, image->format, image->width, image->height, 0, image->format, image->type, image->data);
        
        imgDestroyImage(image);
    }
    
    glTexParameterf(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    
//    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    
    return _skyboxTexture;
}

-(void)destroyVAO:(GLuint) vaoName{
	GLuint index;
	GLuint bufName;
	
	// включаем работу с объектом буффера вершин
	glBindVertexArray(vaoName);
	
	// удаляем все доступные подбуфферы
	for(index = 0; index < 16; index++) {
		glGetVertexAttribiv(index , GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
		
		if(bufName) {
			glDeleteBuffers(1, &bufName);
		}
	}
	
	// дергаем буффер индексов
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, (GLint*)&bufName);
	
    // уничтожаем, если есть
	if(bufName){
		glDeleteBuffers(1, &bufName);
	}
	
    // удаляем сам буффер аттрибутов
	glDeleteVertexArrays(1, &vaoName);
	
	GetGLError();
}

// создание шейдерной программы
-(GLuint) buildProgramFunc{
    NSString* filePathName = nil;
    
    demoSource* vertexSource = NULL;
    demoSource* fragmentSource = NULL;
    
    filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"vsh"];
    vertexSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    
    filePathName = [[NSBundle mainBundle] pathForResource:@"character" ofType:@"fsh"];
    fragmentSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    
	GLuint prgName;
	
	GLint logLength, status;
	
	// строка
	GLchar* sourceString = NULL;  
	
    // определяем версию языка, которая доступна
	float  glLanguageVersion;
	
	sscanf((char *)glGetString(GL_SHADING_LANGUAGE_VERSION), "%f", &glLanguageVersion);
	
	GLuint version = 100 * glLanguageVersion;
	
	// Get the size of the version preprocessor string info so we know 
	//  how much memory to allocate for our sourceString
	const GLsizei versionStringSize = sizeof("#version 123\n");
	
	// создание объекта программы
	prgName = glCreateProgram();
	
    // задаем соответствие названия в шейдере и аттрибутов вершин
	glBindAttribLocation(prgName, 0, "inPosition");
    glBindAttribLocation(prgName, 1, "inNormal");
    glBindAttribLocation(prgName, 2, "inTexcoord");
    glBindAttribLocation(prgName, 3, "inTangent");
	
	/////////////////////////////////
	// создание вершинного шейдера //
	/////////////////////////////////
	
	// выделяем память под строку версии шейдера
	sourceString = malloc(vertexSource->byteSize + versionStringSize);
	
	// добавляем версию к шейдеру
	sprintf(sourceString, "#version %d\n%s", version, vertexSource->string);
	
    // создаем вершинный шейдер
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);	
	glShaderSource(vertexShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(vertexShader);
	glGetShaderiv(vertexShader, GL_INFO_LOG_LENGTH, &logLength);
	
    // инфа
	if (logLength > 0) {
		GLchar *log = (GLchar*) malloc(logLength);
		glGetShaderInfoLog(vertexShader, logLength, &logLength, log);
		NSLog(@"Vtx Shader compile log:%s\n", log);
		free(log);
	}
	
    // лог компиляции
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile vtx shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// подсоединяем вершинный шейдер к обхекту программы
	glAttachShader(prgName, vertexShader);
	
	// удаляем шейдер, тк он уже присоединен к программе
	glDeleteShader(vertexShader);
	
	////////////////////////
	// фрагментный шейдер //
	////////////////////////
	
	// выделяем память под версию
	sourceString = malloc(fragmentSource->byteSize + versionStringSize);
	
	// добавляем версию в текст
	sprintf(sourceString, "#version %d\n%s", version, fragmentSource->string);
	
    // фрагментный шейдер
	GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);	
	glShaderSource(fragShader, 1, (const GLchar **)&(sourceString), NULL);
	glCompileShader(fragShader);
	glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0) {
		GLchar *log = (GLchar*)malloc(logLength);
		glGetShaderInfoLog(fragShader, logLength, &logLength, log);
		NSLog(@"Frag Shader compile log:\n%s\n", log);
		free(log);
	}
	
	glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
	if (status == 0) {
		NSLog(@"Failed to compile frag shader:\n%s\n", sourceString);
		return 0;
	}
	
	free(sourceString);
	sourceString = NULL;
	
	// присоединяем фрагментный к программе
	glAttachShader(prgName, fragShader);
	
	// удаляем, тк присоединен
	glDeleteShader(fragShader);
	
	//////////////////////
	// сборка программы //
	//////////////////////
	
	glLinkProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0){
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program link log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_LINK_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to link program");
		return 0;
	}
	
    // проверка на валидность
	glValidateProgram(prgName);
	glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
	if (logLength > 0)
	{
		GLchar *log = (GLchar*)malloc(logLength);
		glGetProgramInfoLog(prgName, logLength, &logLength, log);
		NSLog(@"Program validate log:\n%s\n", log);
		free(log);
	}
	
	glGetProgramiv(prgName, GL_VALIDATE_STATUS, &status);
	if (status == 0){
		NSLog(@"Failed to validate program");
		return 0;
	}
	
	// включаем данную программу
	glUseProgram(prgName);
	
	GetGLError();
	
    srcDestroySource(vertexSource);
    srcDestroySource(fragmentSource);
    
    GLint samplerLoc = glGetUniformLocation(prgName, "u_texture");
    glUniform1i(samplerLoc, 0);
    samplerLoc = glGetUniformLocation(prgName, "u_shadowMapTexture");
    glUniform1i(samplerLoc, 1);
    samplerLoc = glGetUniformLocation(prgName, "u_normalsTexture");
    glUniform1i(samplerLoc, 2);
    
	return prgName;
}

// создание шейдерной программы
-(GLuint) buildSpriteProgram{
    NSString* filePathName = nil;
    
    demoSource* vertexSource = NULL;
    demoSource* fragmentSource = NULL;
    
    filePathName = [[NSBundle mainBundle] pathForResource:@"sprite" ofType:@"vsh"];
    vertexSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    
    filePathName = [[NSBundle mainBundle] pathForResource:@"sprite" ofType:@"fsh"];
    fragmentSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    
    GLuint prgName;
    
    GLint logLength, status;
    
    // строка
    GLchar* sourceString = NULL;
    
    // определяем версию языка, которая доступна
    float  glLanguageVersion;
    
    sscanf((char *)glGetString(GL_SHADING_LANGUAGE_VERSION), "%f", &glLanguageVersion);
    
    GLuint version = 100 * glLanguageVersion;
    
    // Get the size of the version preprocessor string info so we know
    //  how much memory to allocate for our sourceString
    const GLsizei versionStringSize = sizeof("#version 123\n");
    
    // создание объекта программы
    prgName = glCreateProgram();
    
    // задаем соответствие названия в шейдере и аттрибутов вершин
    glBindAttribLocation(prgName, 0, "inPosition");
    glBindAttribLocation(prgName, 1, "inTexCoord");
    
    /////////////////////////////////
    // создание вершинного шейдера //
    /////////////////////////////////
    
    // выделяем память под строку версии шейдера
    sourceString = malloc(vertexSource->byteSize + versionStringSize);
    
    // добавляем версию к шейдеру
    sprintf(sourceString, "#version %d\n%s", version, vertexSource->string);
    
    // создаем вершинный шейдер
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, (const GLchar **)&(sourceString), NULL);
    glCompileShader(vertexShader);
    glGetShaderiv(vertexShader, GL_INFO_LOG_LENGTH, &logLength);
    
    // инфа
    if (logLength > 0) {
        GLchar *log = (GLchar*) malloc(logLength);
        glGetShaderInfoLog(vertexShader, logLength, &logLength, log);
        NSLog(@"Vtx Shader compile log:%s\n", log);
        free(log);
    }
    
    // лог компиляции
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
        NSLog(@"Failed to compile vtx shader:\n%s\n", sourceString);
        return 0;
    }
    
    free(sourceString);
    sourceString = NULL;
    
    // подсоединяем вершинный шейдер к обхекту программы
    glAttachShader(prgName, vertexShader);
    
    // удаляем шейдер, тк он уже присоединен к программе
    glDeleteShader(vertexShader);
    
    ////////////////////////
    // фрагментный шейдер //
    ////////////////////////
    
    // выделяем память под версию
    sourceString = malloc(fragmentSource->byteSize + versionStringSize);
    
    // добавляем версию в текст
    sprintf(sourceString, "#version %d\n%s", version, fragmentSource->string);
    
    // фрагментный шейдер
    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, (const GLchar **)&(sourceString), NULL);
    glCompileShader(fragShader);
    glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0) {
        GLchar *log = (GLchar*)malloc(logLength);
        glGetShaderInfoLog(fragShader, logLength, &logLength, log);
        NSLog(@"Frag Shader compile log:\n%s\n", log);
        free(log);
    }
    
    glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
        NSLog(@"Failed to compile frag shader:\n%s\n", sourceString);
        return 0;
    }
    
    free(sourceString);
    sourceString = NULL;
    
    // присоединяем фрагментный к программе
    glAttachShader(prgName, fragShader);
    
    // удаляем, тк присоединен
    glDeleteShader(fragShader);
    
    //////////////////////
    // сборка программы //
    //////////////////////
    
    glLinkProgram(prgName);
    glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0){
        GLchar *log = (GLchar*)malloc(logLength);
        glGetProgramInfoLog(prgName, logLength, &logLength, log);
        NSLog(@"Program link log:\n%s\n", log);
        free(log);
    }
    
    glGetProgramiv(prgName, GL_LINK_STATUS, &status);
    if (status == 0){
        NSLog(@"Failed to link program");
        return 0;
    }
    
    // проверка на валидность
    glValidateProgram(prgName);
    glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0)
    {
        GLchar *log = (GLchar*)malloc(logLength);
        glGetProgramInfoLog(prgName, logLength, &logLength, log);
        NSLog(@"Program validate log:\n%s\n", log);
        free(log);
    }
    
    glGetProgramiv(prgName, GL_VALIDATE_STATUS, &status);
    if (status == 0){
        NSLog(@"Failed to validate program");
        return 0;
    }
    
    // включаем данную программу
    glUseProgram(prgName);
    
    ///////////////////////////////////////
    // устанавливаем текстуру по умолчанию - 0 //
    ///////////////////////////////////////
    
    GLint samplerLoc = glGetUniformLocation(prgName, "u_texture");
    glUniform1i(samplerLoc, 0);
    
    GetGLError();
    
    srcDestroySource(vertexSource);
    srcDestroySource(fragmentSource);
    
    return prgName;
}

-(GLuint) buildSkyboxProgram{
    NSString* filePathName = nil;
    
    demoSource* vertexSource = NULL;
    demoSource* fragmentSource = NULL;
    
    filePathName = [[NSBundle mainBundle] pathForResource:@"skybox" ofType:@"vsh"];
    vertexSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    filePathName = [[NSBundle mainBundle] pathForResource:@"skybox" ofType:@"fsh"];
    fragmentSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
    
    GLuint prgName;
    
    GLint logLength, status;
    
    // строка
    GLchar* sourceString = NULL;
    
    // определяем версию языка, которая доступна
    float  glLanguageVersion;
    
    sscanf((char *)glGetString(GL_SHADING_LANGUAGE_VERSION), "%f", &glLanguageVersion);
    
    GLuint version = 100 * glLanguageVersion;
    
    // Get the size of the version preprocessor string info so we know
    //  how much memory to allocate for our sourceString
    const GLsizei versionStringSize = sizeof("#version 123\n");
    
    // создание объекта программы
    prgName = glCreateProgram();
    
    // задаем соответствие названия в шейдере и аттрибутов вершин
    glBindAttribLocation(prgName, 0, "inPosition");
    
    /////////////////////////////////
    // создание вершинного шейдера //
    /////////////////////////////////
    
    // выделяем память под строку версии шейдера
    sourceString = malloc(vertexSource->byteSize + versionStringSize);
    
    // добавляем версию к шейдеру
    sprintf(sourceString, "#version %d\n%s", version, vertexSource->string);
    
    // создаем вершинный шейдер
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, (const GLchar **)&(sourceString), NULL);
    glCompileShader(vertexShader);
    glGetShaderiv(vertexShader, GL_INFO_LOG_LENGTH, &logLength);
    
    // инфа
    if (logLength > 0) {
        GLchar *log = (GLchar*) malloc(logLength);
        glGetShaderInfoLog(vertexShader, logLength, &logLength, log);
        NSLog(@"Vtx Shader compile log:%s\n", log);
        free(log);
    }
    
    // лог компиляции
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
        NSLog(@"Failed to compile vtx shader:\n%s\n", sourceString);
        return 0;
    }
    
    free(sourceString);
    sourceString = NULL;
    
    // подсоединяем вершинный шейдер к обхекту программы
    glAttachShader(prgName, vertexShader);
    
    // удаляем шейдер, тк он уже присоединен к программе
    glDeleteShader(vertexShader);
    
    ////////////////////////
    // фрагментный шейдер //
    ////////////////////////
    
    // выделяем память под версию
    sourceString = malloc(fragmentSource->byteSize + versionStringSize);
    
    // добавляем версию в текст
    sprintf(sourceString, "#version %d\n%s", version, fragmentSource->string);
    
    // фрагментный шейдер
    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, (const GLchar **)&(sourceString), NULL);
    glCompileShader(fragShader);
    glGetShaderiv(fragShader, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0) {
        GLchar *log = (GLchar*)malloc(logLength);
        glGetShaderInfoLog(fragShader, logLength, &logLength, log);
        NSLog(@"Frag Shader compile log:\n%s\n", log);
        free(log);
    }
    
    glGetShaderiv(fragShader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
        NSLog(@"Failed to compile frag shader:\n%s\n", sourceString);
        return 0;
    }
    
    free(sourceString);
    sourceString = NULL;
    
    // присоединяем фрагментный к программе
    glAttachShader(prgName, fragShader);
    
    // удаляем, тк присоединен
    glDeleteShader(fragShader);
    
    //////////////////////
    // сборка программы //
    //////////////////////
    
    glLinkProgram(prgName);
    glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0){
        GLchar *log = (GLchar*)malloc(logLength);
        glGetProgramInfoLog(prgName, logLength, &logLength, log);
        NSLog(@"Program link log:\n%s\n", log);
        free(log);
    }
    
    glGetProgramiv(prgName, GL_LINK_STATUS, &status);
    if (status == 0){
        NSLog(@"Failed to link program");
        return 0;
    }
    
    // проверка на валидность
    glValidateProgram(prgName);
    glGetProgramiv(prgName, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0)
    {
        GLchar *log = (GLchar*)malloc(logLength);
        glGetProgramInfoLog(prgName, logLength, &logLength, log);
        NSLog(@"Program validate log:\n%s\n", log);
        free(log);
    }
    
    glGetProgramiv(prgName, GL_VALIDATE_STATUS, &status);
    if (status == 0){
        NSLog(@"Failed to validate program");
        return 0;
    }
    
    // включаем данную программу
    glUseProgram(prgName);
    
    ///////////////////////////////////////
    // устанавливаем текстуру по умолчанию - 0 //
    ///////////////////////////////////////
    
    GLint samplerLoc = glGetUniformLocation(prgName, "u_texture");
    glUniform1i(samplerLoc, 0);
    
    GetGLError();
    
    srcDestroySource(vertexSource);
    srcDestroySource(fragmentSource);
    
    return prgName;
}

-(void)buildShadowFBO{
    glGenFramebuffers(1, &_shadowRenderFBO);
    
    glGenTextures(1, &_shadowMapTexture);
    glBindTexture(GL_TEXTURE_2D, _shadowMapTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, _viewWidth, _viewHeight, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, _shadowRenderFBO);
    glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, _shadowMapTexture, 0);
    
    glDrawBuffer(GL_NONE);
    
    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    
    if (status != GL_FRAMEBUFFER_COMPLETE) {
        printf("FB error, status: 0x%x\n", status);
        return;
    }
}

- (id) initWithWidth:(int)width height:(int)height {
	if((self = [super init])) {
		NSLog(@"%s %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));
		
		_viewWidth = width;
		_viewHeight = height;
		
		_angle = 0;

        [self buildShadowFBO];
        
		//////////////////////////////
		// модель //
		//////////////////////////////
		
		// на основании модели создаем обхект аттрибутов вершин
		_vertexAttObject = [self buildModelVAO];
        _spriteAttObject = [self spriteVAO];
        _skyboxVAO = [self skyboxVAO];
	
		
		////////////////////////////////////////////////////
		// создание шейдера
		////////////////////////////////////////////////////
		
        glBindVertexArray(_vertexAttObject);
		_shaderProgram = [self buildProgramFunc];
		_mvpMatrixLocation = glGetUniformLocation(_shaderProgram, "modelViewProjectionMatrix");
        _mvMatrixLocation =  glGetUniformLocation(_shaderProgram, "modelViewMatrix");
        _inShadowMatrixLocation =  glGetUniformLocation(_shaderProgram, "toShadowMapMatrix");
        _lightPosLocation =  glGetUniformLocation(_shaderProgram, "lightPos");
        _modelTextureLocation = glGetUniformLocation(_shaderProgram, "textureIm");
        _shadowMapTextureLocation = glGetUniformLocation(_shaderProgram, "u_shadowMapTexture");
        _normalsTextureLocation = glGetUniformLocation(_shaderProgram, "u_normalsTexture");
        
        GetGLError();
        
        glBindVertexArray(_spriteAttObject);
        _spriteShaderProgram = [self buildSpriteProgram];
        _spriteTextureLocation = glGetUniformLocation(_spriteShaderProgram, "u_texture");
        
        GetGLError();
        
        glBindVertexArray(_skyboxVAO);
        _skyboxShader = [self buildSkyboxProgram];
        _skyboxTextureLocation = glGetUniformLocation(_skyboxShader, "u_cubemapTexture");
        _skyboxModelViewLocation = glGetUniformLocation(_skyboxShader, "u_modelViewProj");
        
        GetGLError();
        
        glBindVertexArray(0);
        
        ////////////////////////////////////////////////
        // загрузка текстуры
        ////////////////////////////////////////////////
        
        _modelTexture = [self buildModelTexture:@"demon"];
        _normalsTexture = [self buildModelTexture:@"demon_normals"];
        _skyboxTexture = [self buildSkyboxTexture];
        
		////////////////////////////////////////////////
		// настройка GL
		////////////////////////////////////////////////
		
		// включаем тест глубины
        glEnable(GL_CULL_FACE);     // не рисует заднюю часть
        glFrontFace(GL_CCW);        // передняя часть при обходе против часовой стрелки
		glEnable(GL_DEPTH_TEST);    // тест глубины
		
		// цвет фона
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		
		// вызываем отрисовку сцены
		[self render];
		
		// Reset the m_characterAngle which is incremented in render
		_angle = 0;
		
		// Check for errors to make sure all of our setup went ok
		GetGLError();
	}
	
	return self;
}

- (void) dealloc {
	[self destroyVAO:_vertexAttObject];

	glDeleteProgram(_shaderProgram);

	[super dealloc];
}

@end
