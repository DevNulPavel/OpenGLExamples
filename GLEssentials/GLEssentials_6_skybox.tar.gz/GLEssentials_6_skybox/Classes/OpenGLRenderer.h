#include "glUtil.h"
#import <Foundation/Foundation.h>

@interface OpenGLRenderer : NSObject {

}

- (id) initWithWidth:(int)width height:(int)height;
- (void) resizeWithWidth:(GLuint)width AndHeight:(GLuint)height;
- (void) render;
- (void) dealloc;

@end
