#import <glm.hpp>
#import <ext.hpp>
#import "Camera.h"
#import "LightObject.h"

using namespace glm;

@interface RenderObject: NSObject{
}

@property(nonatomic, assign) vec3 modelPos;
@property(nonatomic, assign) quat rotateQuat;
@property(nonatomic, assign) float scale;

-(void)renderModelFromCamera:(Camera*)cameraObj light:(LightObject*)light toShadow:(BOOL)toShadowMap customProj:(const mat4*)customProj;
-(mat4)modelTransformMatrix;
-(mat4)projectionMatrix;

@end

