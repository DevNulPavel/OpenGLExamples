/**
 * Created by devnul on 27.04.15.
 */
var gl = null;
var shaderProgram = null;
var mesh = null;

var africanHeadDiffuse;
var africanHeadNormals;

var modelMat = mat4.create();
var viewMat = mat4.create();
var projMat = mat4.create();

var cameraPos = vec3.fromValues(0, 0, 3);

var rotateMat = mat4.create();

var mousePressed = false;
var prevMouseX = 0.0;
var prevMouseY = 0.0;


function getShader(type, id){
    var source = document.getElementById(id).innerHTML;
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);

    if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS)){
        alert("Ошибка сборки шейдера: " + id + "\n" + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
    }
    return shader;
}

function initShaders(){
    var vertexShader = getShader(gl.VERTEX_SHADER, "vertexShader");
    var fragmentShader = getShader(gl.FRAGMENT_SHADER, "fragmentShader");

    shaderProgram = gl.createProgram();

    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);

    // позиции аттрибутов
    gl.bindAttribLocation(shaderProgram, 0, "a_pos");
    gl.bindAttribLocation(shaderProgram, 1, "a_normal");
    gl.bindAttribLocation(shaderProgram, 2, "a_texCoord");

    gl.linkProgram(shaderProgram);

    if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)){
        alert("Шейдер не создан");
    }

    // дернем расположение юниформов
    shaderProgram.mvpLocation = gl.getUniformLocation(shaderProgram, "u_mvp");
    shaderProgram.textureLocation = gl.getUniformLocation(shaderProgram, "u_texture");
    shaderProgram.modelLocation = gl.getUniformLocation(shaderProgram, "u_model");
    shaderProgram.lightPosLocation = gl.getUniformLocation(shaderProgram, "u_lightPos");
    shaderProgram.cameraPosLocation = gl.getUniformLocation(shaderProgram, "u_cameraPos");
}

function initBuffers(meshes){
    mesh = meshes["african_head.obj"];
    OBJ.initMeshBuffers(gl, mesh);
}

function draw(){
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if(mesh == null){
        return;
    }

    gl.useProgram(shaderProgram);
    ///////////////////////////
    // обновление юниформов ///
    ///////////////////////////
    // матрица трансформации
    var mvp = mat4.create();
    mat4.identity(mvp);
    mat4.multiply(mvp, mvp, projMat);
    mat4.multiply(mvp, mvp, viewMat);
    mat4.multiply(mvp, mvp, modelMat);
    gl.uniformMatrix4fv(shaderProgram.mvpLocation, false, mvp);

    // матрица модели
    gl.uniformMatrix4fv(shaderProgram.modelLocation, false, modelMat);

    // позиция света
    gl.uniform3f(shaderProgram.lightPosLocation, 15, 0, 15);

    // позиция камеры
    gl.uniform3f(shaderProgram.cameraPosLocation, cameraPos[0], cameraPos[1], cameraPos[2]);

    // текстура будет нулевая
    gl.uniform1i(shaderProgram.textureLocation, 0);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, africanHeadDiffuse);

    ///////////////////////////
    //       рисование      ///
    ///////////////////////////
    // вершины
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vertexBuffer);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, mesh.vertexBuffer.itemSize, gl.FLOAT, false, 0, 0);

    // нормали
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, mesh.normalBuffer.itemSize, gl.FLOAT, false, 0, 0);

    // текстурные координаты
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.textureBuffer);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, mesh.textureBuffer.itemSize, gl.FLOAT, false, 0, 0);

    // поиндексная отрисовка
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBuffer);
    gl.drawElements(gl.TRIANGLES, mesh.indexBuffer.numItems, gl.UNSIGNED_SHORT, 0);
}

function updateMatrices(){
    // модель (ОБРАТНЫЙ ПОРЯДОК)
    mat4.identity(modelMat);
    mat4.translate(modelMat, modelMat, vec3.fromValues(0, 0, 0));
    mat4.mul(modelMat, modelMat, rotateMat);
    mat4.scale(modelMat, modelMat, vec3.fromValues(1, 1, 1));

    // камера
    mat4.lookAt(viewMat, cameraPos, [0, 0, 0], [0, 1, 0]);

    //  проекция
    mat4.perspective(projMat, Math.PI/3.0, gl.viewportWidth / gl.viewportHeight, 1, 10000);
}

function timerTick(){
    updateMatrices();
    draw();
    window.requestAnimationFrame(timerTick);
}

function handleKeyboard(event){
    switch(event.keyCode) {
        case 39: // стрелка вправо
            break;
        case 37: // стрелка влево
            break;
        case 40: // стрелка вниз
            break;
        case 38: // стрелка вверх
            break;
    }
}

function handleMouseDown(event){
    mousePressed = true;
    prevMouseX = event.clientX;
    prevMouseY = event.clientY;
}

function handleMouseMove(event){
    if(mousePressed == false){
        return;
    }

    if(event.shiftKey){
        var zOffset = (event.clientX - prevMouseX) / 100.0;
        mat4.rotate(rotateMat, rotateMat, zOffset, vec3.fromValues(0, 0, 1));
    }else{
        // углы поворота изменяем по приращению
        var xOffset = (event.clientX - prevMouseX) / 100.0;
        var yOffset = (event.clientY - prevMouseY) / 100.0;
        var rotateXMat = mat4.create();
        var rotateYMat = mat4.create();
        var identity = mat4.create();
        mat4.identity(identity);
        mat4.rotate(rotateXMat, identity, yOffset, vec3.fromValues(1, 0, 0));
        mat4.identity(identity);
        mat4.rotate(rotateYMat, identity, xOffset, vec3.fromValues(0, 1, 0));

        mat4.multiply(rotateMat, rotateMat, rotateXMat);
        mat4.multiply(rotateMat, rotateMat, rotateYMat);
    }

    prevMouseX = event.clientX;
    prevMouseY = event.clientY;
}

function handleMouseUp(event){
    mousePressed = false;
}

function textureLoaded(image, texture){
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
}

function createTexture(){
    // голова негра
    africanHeadDiffuse = gl.createTexture();
    var image = new Image();
    image.onload = function(){
        textureLoaded(image, africanHeadDiffuse);
    }
    image.src = "african_head.png";
}

window.onload = function(){
    var canvas = document.getElementById("canvas3D");
    try{
        gl = canvas.getContext("webgl") || canvas.getContext("experimental'webgl");
    }catch (e){}

    if(!gl){
        alert("Нет поддержки GL");
    }

    if(gl){
        window.addEventListener("keydown", handleKeyboard, false);
        window.addEventListener("mousedown", handleMouseDown, false);
        window.addEventListener("mouseup", handleMouseUp, false);
        window.addEventListener("mousemove", handleMouseMove, false);

        gl.viewportWidth = canvas.width;
        gl.viewportHeight = canvas.height;

        gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
        gl.clearColor(0.5, 0.5, 0.5, 1.0);

        gl.enable(gl.DEPTH_TEST);

        createTexture();
        updateMatrices();
        initShaders();
        OBJ.downloadMeshes({"african_head.obj":"african_head.obj"}, initBuffers);

        draw();
        window.requestAnimationFrame(timerTick);
    }
}

// настройка анимации
window.requestAnimFrame = (function(){
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function(callback, element) {
            return window.setTimeout(callback, 1000/60);
        };
})();