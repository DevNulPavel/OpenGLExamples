﻿module BABYLON.Internals {
    export class MeshLODLevel {
        constructor(public distance: number, public mesh: Mesh) {
        }
    }
} 