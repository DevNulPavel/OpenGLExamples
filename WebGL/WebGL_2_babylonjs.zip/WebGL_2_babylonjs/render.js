

var canvas = document.getElementById("canvas3D");
var engine = new BABYLON.Engine(canvas, true);

var scene = createScene();


function createScene(){
    var scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color3(0, 0, 0.3);
    scene.gravity = new BABYLON.Vector3(0, -9.81, 0);
    scene.fogMode = BABYLON.Scene.FOGMODE_EXP;
    scene.fogColor = new BABYLON.Color3(0.6, 0.6, 0.7);
    scene.fogDensity = 0.01;
    scene.collisionsEnabled = true;

    var camera = new BABYLON.FreeCamera("Camera", new BABYLON.Vector3(0, 4, 5), scene);
    camera.ellipsoid = new BABYLON.Vector3(1, 1, 1);
    camera.setTarget(BABYLON.Vector3.Zero());
    camera.keysUp = [87];
    camera.keysDown = [83];
    camera.keysLeft = [65];
    camera.keysRight = [68];
    camera.speed = 0.3;
    camera.attachControl(canvas, true);
    camera.applyGravity = true;
    camera.checkCollisions = true;

    // направленный свет
    var directionalLight = new BABYLON.DirectionalLight("DirectLight", new BABYLON.Vector3(-2, -2, 0).normalize(), scene);
    directionalLight.position = new BABYLON.Vector3(5, 5, 5);
    directionalLight.diffuse = new BABYLON.Color3(0.5, 0.5, 0.5);

    var directionalLightShadowGen = new BABYLON.ShadowGenerator(256, directionalLight);


    // направленный свет
    var pointLight = new BABYLON.PointLight("pointLight", new BABYLON.Vector3(0, 3, 0), scene);
    pointLight.diffuse = new BABYLON.Color3(0.5, 0.5, 0.5);
    pointLight.specular = new BABYLON.Color3(1, 0, 0);

    // коробка
    var box = BABYLON.Mesh.CreateBox("boxMesh", 1, scene);
    box.position = new BABYLON.Vector3(0, 1, 0);
    box.showBoundingBox = true;
    box.checkCollisions = true;
    var boxMaterial = new BABYLON.StandardMaterial("standat", scene);
    boxMaterial.diffuseColor = new BABYLON.Color3(1, 0.4, 0.2);
    box.material = boxMaterial;
    directionalLightShadowGen.getShadowMap().renderList.push(box);



    // земля
    //var ground = BABYLON.Mesh.CreateGroundFromHeightMap("ground", "heightmap.png", 15, 15, 150, 0, 1, scene, false);
    var ground = BABYLON.Mesh.CreateGround("ground", 20, 20, 10, scene, false);
    ground.showBoundingBox = true;
    ground.checkCollisions = true;
    // материал с отражениями
    var groundMaterial = new BABYLON.StandardMaterial("groundMat", scene);
    groundMaterial.diffuseTexture = new BABYLON.Texture("ground.png", scene);
    groundMaterial.bumpTexture = new BABYLON.Texture("ground_normals.png", scene);
    groundMaterial.reflectionTexture = new BABYLON.MirrorTexture("mirror", 512, scene, true);
    groundMaterial.reflectionTexture.mirrorPlane = new BABYLON.Plane(0, -1.0, 0, 0.0);
    groundMaterial.reflectionTexture.renderList = [box];
    ground.material = groundMaterial;
    ground.receiveShadows = true;

    // скайбокс
    var skybox = BABYLON.Mesh.CreateBox("skybox", 100, scene);
    var skyboxMaterial = new BABYLON.StandardMaterial("skyboxMaterial", scene);
    skyboxMaterial.backFaceCulling = false;
    skyboxMaterial.reflectionTexture = new BABYLON.CubeTexture("skybox", scene);
    skyboxMaterial.reflectionTexture.coordinatesMode = BABYLON.Texture.SKYBOX_MODE;
    skyboxMaterial.diffuseColor = new BABYLON.Color3(0, 0, 0);
    skyboxMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
    skybox.material = skyboxMaterial;

    //////////////
    // Анимация //
    /////////////
    // анимация c частотой 30ть кадров
    var animation = new BABYLON.Animation("torusEasingAnimation", "position", 30,
                            BABYLON.Animation.ANIMATIONTYPE_VECTOR3,
                            BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);
    // the torus destination position
    var nextPos = box.position.add(new BABYLON.Vector3(-3, 0, 0));

    // покадровые ключи
    var keysTorus = [];
    keysTorus.push({ frame: 0, value: box.position });
    keysTorus.push({ frame: 60, value: nextPos });
    keysTorus.push({ frame: 120, value: box.position });
    animation.setKeys(keysTorus);

    // добавляем анимацию к объекту
    box.animations.push(animation);

    // запускаеем анимацию для коробки
    scene.beginAnimation(box, 0, 120, true);


    //Sun animation
    scene.registerBeforeRender(function () {
        pointLight.position.x -= 0.05;
        if (pointLight.position.x < -10)
            pointLight.position.x = 10;
    });

    ////////////
    /// Тачи ///
    ////////////
    //scene.onPointerDown = function (evt, pickResult) {
    //    // if the click hits the ground object, we change the impact position
    //    if (pickResult.hit) {
    //        alert("Pos x = " +  pickResult.pickedPoint.x);
    //    }
    //};

    return scene;
}

engine.runRenderLoop(function () {
    scene.render();
});

window.addEventListener("resize", function () {
   engine.resize();
});