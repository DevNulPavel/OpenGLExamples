var e=["http:\/\/4pda.ru\/","http:\/\/4pda.to\/","http:\/\/4pda.ws\/","http:\/\/s.4pda.to\/","https:\/\/adclick.g.doubleclick.net\/","http:\/\/ad.doubleclick.net\/"]
var i=["http:\/\/4pda.ru\/about\/our-projects\/","http:\/\/4pda.ru\/advert\/for-developers\/"]
var x,y,z;
var c=(document.documentElement?document.documentElement:document.body).getElementsByTagName("a");
for(x=0;x<c.length;++x)
{
	var a=c[x],h=a.href,t;
	if(!h||(h.indexOf("http")!=0)||(a.getAttribute('data-notrack'))){continue;}
	for(y=0;y<e.length;++y){if(h.indexOf(e[y])==0){break;}}
	if(y<e.length)
	{
		for(z=0;z<i.length;++z){if(h.indexOf(i[z])==0){break;}}
		if(z==i.length){continue;}
	}
	h="http://4pda.ru/pages/go/?u="+encodeURIComponent(h);
	if(t=a.getAttribute('data-trackmark')){h+='&m='+t;}
	if(t=a.getAttribute('data-nodivert')){h+='&n='+t;}
	while(a&&a.tagName)
	{
		if(t=a.getAttribute('data-post')){h+='&e='+t;break;}
		a=a.parentNode;
	}
	if(!document.referrer)h+='&f='+encodeURIComponent(location.href);
	c[x].href=h;
}
