//
//  RootViewController.h
//  Cocos2D-CCRenderTexture-Demo
//
//  Copyright (c) 2011 Steffen Itterheim.
//	Distributed under MIT License.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
