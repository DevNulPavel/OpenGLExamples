//
//  NodeRenderTextureScene.h
//  Cocos2D-CCRenderTexture-Demo
//
//  Copyright (c) 2011 Steffen Itterheim.
//	Distributed under MIT License.
//

#import "CCScene.h"

@interface NodeRenderTextureScene : CCScene

@end
