/* 
 * File:   engine_common.h
 * Author: cl
 *
 * Created on June 10, 2011, 8:38 PM
 */

#ifndef ENGINE_COMMON_H
#define	ENGINE_COMMON_H

#define COLOR_TEXTURE_UNIT GL_TEXTURE0
#define SHADOW_TEXTURE_UNIT GL_TEXTURE1
#define NORMAL_TEXTURE_UNIT GL_TEXTURE2



#endif	/* ENGINE_COMMON_H */

