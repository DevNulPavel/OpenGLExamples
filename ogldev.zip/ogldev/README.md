Tutorials from both http://ogldev.atspace.co.uk/ and http://ogltutor.netau.net
