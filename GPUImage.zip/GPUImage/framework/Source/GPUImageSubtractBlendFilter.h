#import "GPUImageTwoInputFilter.h"

@interface GPUImageSubtractBlendFilter : GPUImageTwoInputFilter

@end
