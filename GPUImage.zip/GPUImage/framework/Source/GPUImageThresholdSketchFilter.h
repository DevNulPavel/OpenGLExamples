#import "GPUImageThresholdEdgeDetectionFilter.h"

@interface GPUImageThresholdSketchFilter : GPUImageThresholdEdgeDetectionFilter

@end
