#import "GPUImageSobelEdgeDetectionFilter.h"

@interface GPUImageXYDerivativeFilter : GPUImageSobelEdgeDetectionFilter

@end
