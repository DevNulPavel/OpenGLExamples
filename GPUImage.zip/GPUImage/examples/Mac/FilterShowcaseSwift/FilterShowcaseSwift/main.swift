import Cocoa

NSApplicationMain(C_ARGC, C_ARGV)