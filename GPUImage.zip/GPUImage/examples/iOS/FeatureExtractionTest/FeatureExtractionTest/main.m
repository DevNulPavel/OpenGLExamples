#import <UIKit/UIKit.h>

#import "FeatureExtractionAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FeatureExtractionAppDelegate class]));
    }
}
