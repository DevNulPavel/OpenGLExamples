#import <UIKit/UIKit.h>

#import "PhotoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PhotoAppDelegate class]));
    }
}
