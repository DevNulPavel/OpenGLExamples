#!/bin/sh

CFLAGS="-DPERF_TEST" ./build.sh native release
