Cheetah 2D Engine - fast, flexible and powerful 2D graphics engine.

* [Documentation](https://github.com/scriptum/Cheetah/wiki/Documentation)
* [Tutorials](https://github.com/scriptum/Cheetah/wiki/Tutorials)

If you want to build engine yourself see [INSTALL.txt](https://raw.github.com/scriptum/Cheetah/master/INSTALL.txt).

You may find daily build of engine with demos [here](http://dl.dropbox.com/u/59878867/Cheetah-2D-Engine-daily.tar.gz).
