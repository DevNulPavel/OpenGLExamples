Sample drawing:
![](https://github.com/krzysztofzablocki/smooth-drawing/raw/master/Example.png)
Purpose
--------------

Smooth drawing is a sample project showing exactly how to create a nice and smooth drawing application, it draws nice anti-aliased lines and the feel is really natural, you can read about it's creation at: http://www.merowing.info/2012/04/drawing-smooth-lines-with-cocos2d-ios-inspired-by-paper/
I decided to create this after finding out that there isn't really a complete solution released and many people try to make something like that but fail at some point. 

I hope you like it, spread the word so that more people will be able to learn / use this.

[Follow me on twitter][1]

ARC Compatibility
------------------

Project uses ARC, I put all the code inside LineDrawer class ( don't worry it's only ~500 lines ) so that you can just add -fobjc-arc on this class in non-ARC projects.

Spread the word and read my blog post about this project to learn more.

  [1]: http://twitter.com/merowing_

Building
------------------

This project now uses Cocos2d as a submodule. Cocos2d itself uses submodules now as well. Do not forget to git submodule update --init --recursive
