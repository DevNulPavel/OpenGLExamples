//
//  AppDelegate.h
//  Smooth Drawing

#import "cocos2d.h"

@interface AppDelegate : CCAppDelegate
@end