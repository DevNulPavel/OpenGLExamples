@class WaterNode;

@interface MainLayer : CCLayerColor {
@private
    WaterNode *_waterNode;
}

+ (CCScene *)scene;

@end