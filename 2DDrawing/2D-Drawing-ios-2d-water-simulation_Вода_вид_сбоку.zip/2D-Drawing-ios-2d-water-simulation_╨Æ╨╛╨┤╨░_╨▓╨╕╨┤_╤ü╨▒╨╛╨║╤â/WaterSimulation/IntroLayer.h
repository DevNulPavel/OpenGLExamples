@interface IntroLayer : CCLayer {
}

+ (CCScene *)scene;

@end
