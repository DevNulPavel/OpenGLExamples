ios-2d-water-simulation
=======================
Dynamic 2D Water Effects.<br />
The main idea has taken from http://gamedev.tutsplus.com/tutorials/implementation/make-a-splash-with-2d-water-effects/

![Alt text](http://s22.postimg.org/z8eml94ox/2013_06_05_0_48_56.png "Screen shot")
