The sprites in this demo are the property of Andreas Loew / CodeAndWeb.

They are included to demonstrate the animation feature of the UIKit loader.

The sprites must not be used in any project without the written permission of Andreas Loew.
