//
//  cocos2d_lib.m
//  cocos2d-lib
//
//  Created by Paul Renton on 6/1/13.
//
//

#import "cocos2d_lib.h"

@implementation cocos2d_lib

@end
