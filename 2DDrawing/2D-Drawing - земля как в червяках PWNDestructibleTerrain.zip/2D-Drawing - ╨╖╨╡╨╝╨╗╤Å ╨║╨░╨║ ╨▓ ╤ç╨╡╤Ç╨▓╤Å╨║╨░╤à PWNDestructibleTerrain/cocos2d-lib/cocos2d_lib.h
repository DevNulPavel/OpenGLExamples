//
//  cocos2d_lib.h
//  cocos2d-lib
//
//  Created by Paul Renton on 6/1/13.
//
//

#import <Foundation/Foundation.h>

@interface cocos2d_lib : NSObject

@end
