PWNDestructibleTerrain
======================

Proof of concept testing for Destructible Terrain in Cocos2D v2.x
The project is ARC enabled with Cocos2D added as a static library
