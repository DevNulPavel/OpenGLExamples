//
//  AsyncObject.m
//  SpaceTankWars
//
//  Created by Paul Renton on 6/1/13.
//
//

//
//  AsyncObject.m
//  PixelPile
//
//  Created by Lam Pham on 1/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AsyncObject.h"

@implementation AsyncObject
@synthesize selector = selector_;
@synthesize target = target_;
@synthesize data = data_;
@end
