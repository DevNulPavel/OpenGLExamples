//
//  CreditsLayer.h
//  DestructibleGround
//
//  Created by Jean-Philippe SARDA on 11/20/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// CreditsLayer
@interface CreditsLayer : CCLayer
{
}

// returns a CCScene that contains the CreditsLayer as the only child
+(CCScene *) scene;

@end

