//
//  TerrainTestScene.h
//  PWNDestructibleTerrain
//
//  Created by Paul Renton on 6/8/13.
//
//

#import "CCScene.h"

@class TestTerrainLayer;

@interface TerrainTestScene : CCScene {
    
    
    TestTerrainLayer * testLayer;
    
    
} // end ivars


@end
