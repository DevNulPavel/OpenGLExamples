//
//  Ripples.h
//  CocosShaderEffects
//
//  Created by Kalpesh Solanki on 1/10/13.
//
//

#import "CCLayer.h"
#import "cocos2d.h"

#define HEIGHTFIELD_SIZE 100
 

@interface RipplesLayer : CCLayer

@end
