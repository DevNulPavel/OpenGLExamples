//
//  main.cpp
//  GLTask2
//
//  Created by Pavel Ershov on 29.03.15.
//  Copyright (c) 2015 Pavel Ershov. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <GLUT/GLUT.h>
#include <OpenGL/OpenGL.h>
#include "math_3d.h"
#include "helpers.h"



GLuint vbo;
GLuint shaderProgram;

static void CreateVertexBuffer() {
    Vector3f Vertices[3];
    Vertices[0] = Vector3f(-1.0f, -1.0f, 0.0f);
    Vertices[1] = Vector3f(1.0f, -1.0f, 0.0f);
    Vertices[2] = Vector3f(0.0f, 1.0f, 0.0f);
    
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices), Vertices, GL_STATIC_DRAW);
}

static void createShaderProgram(){
    // вершинный
    const GLchar* vertexText[1];
    vertexText[0] = STRINGIFY(
       attribute vec3 position;
       void main()
       {
           gl_Position = vec4(0.5 * position.x, 0.5 * position.y, position.z, 1.0);
       }
    );
    GLint lengths[1];
    lengths[0] = (GLint)strlen(vertexText[0]);
    
    GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderObject, 1, vertexText, lengths);
    glCompileShader(vertexShaderObject);
    CHECK_SHADER_ERROR(vertexShaderObject, GL_VERTEX_SHADER);
    
    // фрагментный
    const GLchar* fragmentText[1];
    fragmentText[0] = STRINGIFY(
        void main()
        {
            gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
        }
    );
    GLint fragLengths[1];
    fragLengths[0] = (GLint)strlen(fragmentText[0]);
    
    GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShaderObject, 1, fragmentText, fragLengths);
    glCompileShader(fragmentShaderObject);
    CHECK_SHADER_ERROR(fragmentShaderObject, GL_FRAGMENT_SHADER);
    
    // сборка
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShaderObject);
    glAttachShader(shaderProgram, fragmentShaderObject);
    glLinkProgram(shaderProgram);
    CHECK_SHADER_LINK(shaderProgram);
    glValidateProgram(shaderProgram);
    CHECK_VALIDATE_PROGRAM(shaderProgram);
}


static void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    
    glUseProgram(shaderProgram);
    
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    
    glDrawArrays(GL_TRIANGLES, 0, 3);
    
    glDisableVertexAttribArray(0);
    
    glutSwapBuffers();
}

static void InitializeGlutCallbacks(){
    glutDisplayFunc(renderScene);
}

int main(int argc, char ** argv) {
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowSize(1024, 768);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Tutorial 02");
    
    printf("%s\n%s\n\n\n", glGetString(GL_RENDERER), glGetString(GL_VERSION));
    
    InitializeGlutCallbacks();
    
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    
    CreateVertexBuffer();
    createShaderProgram();
    
    
    glutMainLoop();
    
    return 0;
}
