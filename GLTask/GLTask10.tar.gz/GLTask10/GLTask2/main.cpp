//
//  main.cpp
//  GLTask2
//
//  Created by Pavel Ershov on 29.03.15.
//  Copyright (c) 2015 Pavel Ershov. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <GLUT/GLUT.h>
#include <OpenGL/OpenGL.h>
#include "math_3d.h"
#include "helpers.h"
#include <math.h>



GLuint vbo;
GLuint ibo;
GLuint shaderProgram;
Maxtrix4f worldMatrix;

GLuint worldMatrixLocation;


float curOffset = 0.0;



static void createFigureBuffers() {
    // создаем буффер вершин
    Vector3f vertices[4];
    vertices[0] = Vector3f(-1.0f, -1.0f, 0.0f);
    vertices[1] = Vector3f(0.0f, -1.0f, 0.0f);
    vertices[2] = Vector3f(1.0f, -1.0f, 0.0f);
    vertices[3] = Vector3f(0.0f, 1.0f, 0.0f);
    
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);         //  это массив вершин
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);  // подгружаем на видеокарту
    
    // создаем буффер индексов
    unsigned int indexes[] = {0, 3, 1,
                              1, 3, 2,
                              2, 3, 0,
                              0, 2, 1};
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo); // это массив индексов
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexes), indexes, GL_STATIC_DRAW);    // подгружаем на видеокарту
}

static void createShaderProgram(){
    // вершинный
    const GLchar* vertexText[1];
    vertexText[0] = STRINGIFY(
       attribute vec3 position;
       uniform mat4 u_matrix;
       varying vec4 color;
       void main()
       {
           gl_Position = u_matrix * vec4(position, 1.0);
           color = vec4(clamp(position, 0.0, 1.0), 1.0);
       }
    );
    GLint lengths[1];
    lengths[0] = (GLint)strlen(vertexText[0]);
    
    GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderObject, 1, vertexText, lengths);
    glCompileShader(vertexShaderObject);
    CHECK_SHADER_ERROR(vertexShaderObject, GL_VERTEX_SHADER);
    
    // фрагментный
    const GLchar* fragmentText[1];
    fragmentText[0] = STRINGIFY(
        varying vec4 color;
        void main()
        {
            gl_FragColor = color;
        }
    );
    GLint fragLengths[1];
    fragLengths[0] = (GLint)strlen(fragmentText[0]);
    
    GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShaderObject, 1, fragmentText, fragLengths);
    glCompileShader(fragmentShaderObject);
    CHECK_SHADER_ERROR(fragmentShaderObject, GL_FRAGMENT_SHADER);
    
    // сборка
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShaderObject);
    glAttachShader(shaderProgram, fragmentShaderObject);
    glLinkProgram(shaderProgram);
    CHECK_SHADER_LINK(shaderProgram);
    glValidateProgram(shaderProgram);
    CHECK_VALIDATE_PROGRAM(shaderProgram);
}

static void updateMatrices(){
    worldMatrix.m[0][0]=sinf(curOffset); worldMatrix.m[0][1]=0.0f;        worldMatrix.m[0][2]=0.0f;        worldMatrix.m[0][3]=0.0f;
    worldMatrix.m[1][0]=0.0f;        worldMatrix.m[1][1]=cosf(curOffset); worldMatrix.m[1][2]=0.0f;        worldMatrix.m[1][3]=0.0f;
    worldMatrix.m[2][0]=0.0f;        worldMatrix.m[2][1]=0.0f;        worldMatrix.m[2][2]=sinf(curOffset); worldMatrix.m[2][3]=0.0f;
    worldMatrix.m[3][0]=0.0f;        worldMatrix.m[3][1]=0.0f;        worldMatrix.m[3][2]=0.0f;        worldMatrix.m[3][3]=1.0f;
}

static void getShaderLocations(){
    worldMatrixLocation = glGetUniformLocation(shaderProgram, "u_matrix");
}

static void updateShaderUniforms(){
    curOffset += 0.01;
    if (curOffset >= M_PI*2) {
        curOffset = 0.0;
    }
    glUniformMatrix4fv(worldMatrixLocation, 1, GL_TRUE, &worldMatrix.m[0][0]);
}

static void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    
    glUseProgram(shaderProgram);
    
    updateMatrices();
    updateShaderUniforms();
    
    glEnableVertexAttribArray(0);
    
    // включаем буффер вершин
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    // нулевой аттрибут в шейдере -
    // каждая вершина состоит из 3х компонентов, не нормализованных
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    
    // включаем буффер индексов для отрисовки по индексам
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    // выполняем поиндексную отрсовку
    glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);
    
    glDisableVertexAttribArray(0);
    
    glutSwapBuffers();
    glutPostRedisplay();
}

static void initializeGlutCallbacks(){
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
}

int main(int argc, char ** argv) {
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowSize(480, 320);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Tutorial 02");
    
    printf("%s\n%s\n\n\n", glGetString(GL_RENDERER), glGetString(GL_VERSION));
    
    initializeGlutCallbacks();
    
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    
    createFigureBuffers();
    createShaderProgram();
    getShaderLocations();
    
    glutMainLoop();
    
    return 0;
}
