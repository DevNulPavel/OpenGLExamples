//
//  helpers.h
//  GLTask2
//
//  Created by Pavel Ershov on 29.03.15.
//  Copyright (c) 2015 Pavel Ershov. All rights reserved.
//

#ifndef GLTask2_helpers_h
#define GLTask2_helpers_h


#define STRINGIFY(A) #A

#define CHECK_SHADER_ERROR(vertexShaderObject, shaderType){   \
GLint success;  \
glGetShaderiv(vertexShaderObject, GL_COMPILE_STATUS, &success);\
if (!success) {\
GLchar InfoLog[1024];\
glGetShaderInfoLog(vertexShaderObject, 1024, NULL, InfoLog);\
fprintf(stderr, "Error compiling shader type %d: '%s'\n", shaderType, InfoLog);\
exit(1);\
}\
}\

#define CHECK_SHADER_LINK(ShaderProgram){   \
    GLint Success = 0;\
    GLchar ErrorLog[1024] = { 0 };\
    glGetProgramiv(ShaderProgram, GL_LINK_STATUS, &Success);\
    if (Success == 0) {\
        glGetProgramInfoLog(ShaderProgram, sizeof(ErrorLog), NULL, ErrorLog);\
        fprintf(stderr, "Error linking shader program: '%s'\n", ErrorLog);\
        exit(1);\
    }\
}\

#define CHECK_VALIDATE_PROGRAM(ShaderProgram){\
GLint Success = 0;\
GLchar ErrorLog[1024] = { 0 };\
glGetProgramiv(ShaderProgram, GL_VALIDATE_STATUS, &Success);\
if (!Success) {\
glGetProgramInfoLog(ShaderProgram, sizeof(ErrorLog), NULL, ErrorLog);\
fprintf(stderr, "Invalid shader program: '%s'\n", ErrorLog);\
exit(1);\
}\
}\

#endif
