//
//  main.cpp
//  GLTask2
//
//  Created by Pavel Ershov on 29.03.15.
//  Copyright (c) 2015 Pavel Ershov. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <GLUT/GLUT.h>
#include <OpenGL/OpenGL.h>
#include <math.h>
#include "math_3d.h"
#include "pipeline.h"
#include "helpers.h"
#include "camera.h"
#include "texture.h"


const int windowWidth = 480;
const int windowHeight = 320;


int itemsCount = 0;

GLuint vertexBO;
GLuint xyzVBO;
GLuint shaderProgram;

GLuint worldMatrixLocation;
GLuint textureLocation;

Pipeline pipeline;
Pipeline xyzPipe;
Camera camera(windowWidth, windowHeight);
Texture texture(GL_TEXTURE_2D, "test.png");
float rotateX;
float rotateY;
float curOffset;


static float func(float x, float y){
    return sin(x) * sinf(y);
}


static void createFigureBuffers() {
    // создаем буффер вершин
    
    long int xSize = 80;
    long int ySize = 80;
    double startX = -M_PI;
    double startY = -M_PI;
    double endX = M_PI;
    double endY = M_PI;
    double stepX = (endX - startX) / xSize;
    double stepY = (endY - startY) / ySize;
    
    GLfloat* cubeLines;
    size_t size = sizeof(GLfloat) * xSize * ySize * (24+1);
    cubeLines = (GLfloat*)malloc(size);
    memset(cubeLines, 0, size);
    
    int i = 0;
    for (double curX = startX; curX <= endX; curX += stepX) {
        for (double curY = startY; curY <= endY; curY += stepY) {
            // tri 1
            cubeLines[i] = curX;
            i++;
            cubeLines[i] = curY;
            i++;
            cubeLines[i] = func(curX, curY);
            i++;
            
            cubeLines[i] = curX + stepX;
            i++;
            cubeLines[i] = curY;
            i++;
            cubeLines[i] = func(curX + stepX, curY);
            i++;
            
            //2
            cubeLines[i] = curX + stepX;
            i++;
            cubeLines[i] = curY;
            i++;
            cubeLines[i] = func(curX + stepX, curY);
            i++;
            
            cubeLines[i] = curX + stepX;
            i++;
            cubeLines[i] = curY + stepY;
            i++;
            cubeLines[i] = func(curX + stepX, curY + stepY);
            i++;
            
            //3
            cubeLines[i] = curX + stepX;
            i++;
            cubeLines[i] = curY + stepY;
            i++;
            cubeLines[i] = func(curX + stepX, curY + stepY);
            i++;
            
            cubeLines[i] = curX;
            i++;
            cubeLines[i] = curY + stepY;
            i++;
            cubeLines[i] = func(curX, curY + stepY);
            i++;
            
            //4
            cubeLines[i] = curX;
            i++;
            cubeLines[i] = curY + stepY;
            i++;
            cubeLines[i] = func(curX, curY + stepY);
            i++;
            
            cubeLines[i] = curX;
            i++;
            cubeLines[i] = curY;
            i++;
            cubeLines[i] = func(curX, curY);
            i++;
        }
    }
    itemsCount = i;
    free(cubeLines);
    
    glGenBuffers(1, &vertexBO);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBO);         //  это массив вершин
    glBufferData(GL_ARRAY_BUFFER, size, cubeLines, GL_STATIC_DRAW);  // подгружаем на видеокарту
    
    
    
    GLfloat xyzLines[] = {  0.0, 0.0, 0.0,
                            1.0, 0.0, 0.0,
                            0.0, 0.0, 0.0,
                            0.0, 1.0, 0.0,
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 1.0};
    glGenBuffers(1, &xyzVBO);
    glBindBuffer(GL_ARRAY_BUFFER, xyzVBO);         //  это массив вершин
    glBufferData(GL_ARRAY_BUFFER, sizeof(xyzLines), xyzLines, GL_STATIC_DRAW);  // подгружаем на видеокарту
}

static void createShaderProgram(){
    // вершинный
    const GLchar* vertexText[1];
    vertexText[0] = STRINGIFY(
       attribute vec3 a_position;
       uniform mat4 u_matrix;
       varying vec3 v_color;
       void main()
       {
           gl_Position = u_matrix * vec4(a_position, 1.0);
           v_color = vec3(a_position.z*0.5+0.5, 0.5, 0.5);
       }
    );
    GLint lengths[1];
    lengths[0] = (GLint)strlen(vertexText[0]);
    
    GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderObject, 1, vertexText, lengths);
    glCompileShader(vertexShaderObject);
    CHECK_SHADER_ERROR(vertexShaderObject, GL_VERTEX_SHADER);
    
    // фрагментный
    const GLchar* fragmentText[1];
    fragmentText[0] = STRINGIFY(
        varying vec3 v_color;
        void main()
        {
            gl_FragColor = vec4(v_color, 1.0);
        }
    );
    GLint fragLengths[1];
    fragLengths[0] = (GLint)strlen(fragmentText[0]);
    
    GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShaderObject, 1, fragmentText, fragLengths);
    glCompileShader(fragmentShaderObject);
    CHECK_SHADER_ERROR(fragmentShaderObject, GL_FRAGMENT_SHADER);
    
    // сборка
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShaderObject);
    glAttachShader(shaderProgram, fragmentShaderObject);
    
    // позиция на индексе 0
    glBindAttribLocation(shaderProgram, 0, "a_position");
    
    glLinkProgram(shaderProgram);
    CHECK_SHADER_LINK(shaderProgram);
    glValidateProgram(shaderProgram);
    CHECK_VALIDATE_PROGRAM(shaderProgram);
}

static void updateTransform(){
    curOffset += 0.005;
    if (curOffset >= M_PI*2) {
        curOffset = 0.0;
    }
    
    // трансформ объекта
    pipeline.WorldPos(0, 0, 8.0);
    pipeline.Rotate(rotateX + sin(curOffset) * 15.0, rotateY + sin(curOffset) * 15.0, 0);
    
    // камера
    camera.OnRender();
    pipeline.SetCamera(camera.GetPos(), camera.GetTarget(), camera.GetUp());
    
    // перспективная проекция
    pipeline.SetPerspectiveProj(60.0, windowWidth, windowHeight, 1.0, 100.0);
    
    
    // xyz
    xyzPipe.WorldPos(0, 0, 1);
    xyzPipe.Rotate(rotateX + sin(curOffset) * 15.0, rotateY + sin(curOffset) * 15.0, 0);
    xyzPipe.SetCamera(camera.GetPos(), camera.GetTarget(), camera.GetUp());
    xyzPipe.SetPerspectiveProj(60.0, windowWidth, windowHeight, 1.0, 100.0);
}

static void getShaderLocations(){
    worldMatrixLocation = glGetUniformLocation(shaderProgram, "u_matrix");
    textureLocation = glGetUniformLocation(shaderProgram, "u_texture");
}


static void enableAttributePointers(){
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat)*3, 0); // каждая вершина состоит из 3х float
}

static void disableAttributePointers(){
    glDisableVertexAttribArray(0);
}

static void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glUseProgram(shaderProgram);
    
    updateTransform();
    
    // отрисовка графика
    glUniformMatrix4fv(worldMatrixLocation, 1, GL_TRUE, (const GLfloat*)pipeline.GetTrans());
    glBindBuffer(GL_ARRAY_BUFFER, vertexBO);
    enableAttributePointers();
    glDrawArrays(GL_LINES, 0, itemsCount);
    disableAttributePointers();
    
//    // отрисовка xyz
//    glUniformMatrix4fv(worldMatrixLocation, 1, GL_TRUE, (const GLfloat*)xyzPipe.GetTrans());
//    glBindBuffer(GL_ARRAY_BUFFER, xyzVBO);
//    enableAttributePointers();
//    glDrawArrays(GL_LINES, 0, 9);
//    disableAttributePointers();
    
    glutSwapBuffers();
    glutPostRedisplay();
}

static void loadTexture(){
    if (!texture.Load()) {
        printf("texture not load");
    }
}

static void handleKey(int key, int x, int y){
//    camera.OnKeyboard(key);
    switch (key) {
        case GLUT_KEY_UP:{
            rotateX += 5.0;
        }break;
        case GLUT_KEY_DOWN:{
            rotateX -= 5.0;
        }break;
        case GLUT_KEY_LEFT:{
            rotateY += 5.0;
        }break;
        case GLUT_KEY_RIGHT:{
            rotateY -= 5.0;
        }break;
    }
}

static void mouseHandle(int x, int y){
//    camera.OnMouse(x, y);
}

static void initializeGlutCallbacks(){
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutSpecialFunc(handleKey);
    glutPassiveMotionFunc(mouseHandle);
}

int main(int argc, char ** argv) {
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(windowWidth, windowHeight);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Tutorial 02");
    
    printf("%s\n%s\n\n\n", glGetString(GL_RENDERER), glGetString(GL_VERSION));
    
    initializeGlutCallbacks();
    
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
//    glFrontFace(GL_CW);
//    glCullFace(GL_BACK);
//    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);
    
    loadTexture();
    createFigureBuffers();
    createShaderProgram();
    getShaderLocations();
    
    glutMainLoop();
    
    return 0;
}
