//
//  main.cpp
//  GLTask2
//
//  Created by Pavel Ershov on 29.03.15.
//  Copyright (c) 2015 Pavel Ershov. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <GLUT/GLUT.h>
#include <OpenGL/OpenGL.h>
#include <math.h>
#include "math_3d.h"
#include "pipeline.h"
#include "helpers.h"
#include "camera.h"



GLuint vbo;
GLuint ibo;
GLuint cbo;
GLuint shaderProgram;

GLuint worldMatrixLocation;

Pipeline pipeline;
Camera camera;
float curOffset;



const int indexesCount = 36;
const int windowWidth = 480;
const int windowHeight = 320;


static void createFigureBuffers() {
    // создаем буффер вершин
    GLfloat cubeVertices[] = {
        // front
        -1.0, -1.0,  1.0,
        1.0, -1.0,  1.0,
        1.0,  1.0,  1.0,
        -1.0,  1.0,  1.0,
        // back
        -1.0, -1.0, -1.0,
        1.0, -1.0, -1.0,
        1.0,  1.0, -1.0,
        -1.0,  1.0, -1.0,
    };
    
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);         //  это массив вершин
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW);  // подгружаем на видеокарту
    
    // создаем буффер цветов
    GLfloat colors[] = {
        // front colors
        1.0, 0.0, 0.0,
        0.0, 1.0, 0.0,
        0.0, 0.0, 1.0,
        1.0, 1.0, 1.0,
        // back colors
        1.0, 0.0, 0.0,
        0.0, 1.0, 0.0,
        0.0, 0.0, 1.0,
        1.0, 1.0, 1.0,
    };
    glGenBuffers(1, &cbo);
    glBindBuffer(GL_ARRAY_BUFFER, cbo); // массив аттрибутов вершин
    glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);    // подгружаем на видеокарту
    
    // создаем буффер индексов
    unsigned int indexes[] = {
        // front
        0, 1, 2,
        2, 3, 0,
        // top
        3, 2, 6,
        6, 7, 3,
        // back
        7, 6, 5,
        5, 4, 7,
        // bottom
        4, 5, 1,
        1, 0, 4,
        // left
        4, 0, 3,
        3, 7, 4,
        // right
        1, 5, 6,
        6, 2, 1,
    };
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo); // это массив индексов
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexes), indexes, GL_STATIC_DRAW);    // подгружаем на видеокарту
}

static void createShaderProgram(){
    // вершинный
    const GLchar* vertexText[1];
    vertexText[0] = STRINGIFY(
       attribute vec3 a_position;
       attribute vec3 a_color;
       uniform mat4 u_matrix;
       varying vec4 v_color;
       void main()
       {
           gl_Position = u_matrix * vec4(a_position, 1.0);
           v_color = vec4(a_color, 1.0);
       }
    );
    GLint lengths[1];
    lengths[0] = (GLint)strlen(vertexText[0]);
    
    GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderObject, 1, vertexText, lengths);
    glCompileShader(vertexShaderObject);
    CHECK_SHADER_ERROR(vertexShaderObject, GL_VERTEX_SHADER);
    
    // фрагментный
    const GLchar* fragmentText[1];
    fragmentText[0] = STRINGIFY(
        varying vec4 v_color;
        void main()
        {
            gl_FragColor = v_color;
        }
    );
    GLint fragLengths[1];
    fragLengths[0] = (GLint)strlen(fragmentText[0]);
    
    GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShaderObject, 1, fragmentText, fragLengths);
    glCompileShader(fragmentShaderObject);
    CHECK_SHADER_ERROR(fragmentShaderObject, GL_FRAGMENT_SHADER);
    
    // сборка
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShaderObject);
    glAttachShader(shaderProgram, fragmentShaderObject);
    glLinkProgram(shaderProgram);
    CHECK_SHADER_LINK(shaderProgram);
    glValidateProgram(shaderProgram);
    CHECK_VALIDATE_PROGRAM(shaderProgram);
}

static void updateTransform(){
    curOffset += 0.01;
    if (curOffset >= M_PI*2) {
        curOffset = 0.0;
    }
    
    // трансформ объекта
    pipeline.WorldPos(sinf(curOffset), sinf(curOffset), 3.0);
    pipeline.Rotate(sinf(curOffset) * 90.0f, sinf(curOffset) * 90.0f, 0.0);
    
    // камера
    pipeline.SetCamera(camera.GetPos(), camera.GetTarget(), camera.GetUp());
    
    // перспективная проекция
    pipeline.SetPerspectiveProj(60.0, windowWidth, windowHeight, 1.0, 100.0);
}

static void getShaderLocations(){
    worldMatrixLocation = glGetUniformLocation(shaderProgram, "u_matrix");
}

static void updateShaderUniforms(){
    glUniformMatrix4fv(worldMatrixLocation, 1, GL_TRUE, (const GLfloat*)pipeline.GetTrans());
}

static void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glUseProgram(shaderProgram);
    
    updateTransform();
    updateShaderUniforms();
    
    // включаем буффер вершин
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    // 0 аттрибут
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0); // каждая вершина состоит из 3х float
    
    // включаем аттрибут цветов вершин
    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ARRAY_BUFFER, cbo);
    // первый аттрибут вершины
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
    
    // включаем буффер индексов для отрисовки по индексам
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    // выполняем поиндексную отрсовку
    glDrawElements(GL_TRIANGLES, indexesCount, GL_UNSIGNED_INT, 0);
    
    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    
    glutSwapBuffers();
    glutPostRedisplay();
}

static void handleKey(int key, int x, int y){
    camera.OnKeyboard(key);
}

static void initializeGlutCallbacks(){
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutSpecialFunc(handleKey);
}

int main(int argc, char ** argv) {
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(windowWidth, windowHeight);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Tutorial 02");
    
    printf("%s\n%s\n\n\n", glGetString(GL_RENDERER), glGetString(GL_VERSION));
    
    initializeGlutCallbacks();
    
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glEnable(GL_DEPTH_TEST);
    
    createFigureBuffers();
    createShaderProgram();
    getShaderLocations();
    
    glutMainLoop();
    
    return 0;
}
