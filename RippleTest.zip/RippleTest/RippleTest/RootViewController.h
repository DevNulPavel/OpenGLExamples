//
//  RootViewController.h
//  RippleTest
//
//  Created by Dave Hersey, Paracoders, Inc. on 12/4/11.
//  Ripples provided by Birkemose.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
