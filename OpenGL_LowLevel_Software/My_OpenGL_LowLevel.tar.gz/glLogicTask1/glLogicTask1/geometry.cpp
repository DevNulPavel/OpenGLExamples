#include <vector>
#include <cassert>
#include <cmath>
#include <iostream>
#include "geometry.h"

template <> template <> Vec3<int>::Vec3(const Vec3<float> &v) : x(int(v.x+.5)), y(int(v.y+.5)), z(int(v.z+.5)) {
}

template <> template <> Vec3<float>::Vec3(const Vec3<int> &v) : x(v.x), y(v.y), z(v.z) {
}


Matrix::Matrix(int r, int c) : m(std::vector<std::vector<float> >(r, std::vector<float>(c, 0.f))), rows(r), cols(c) { }

int Matrix::nrows() {
    return rows;
}

int Matrix::ncols() {
    return cols;
}

Matrix Matrix::identity(int dimensions) {
    Matrix E(dimensions, dimensions);
    for (int i=0; i<dimensions; i++) {
        for (int j=0; j<dimensions; j++) {
            E[i][j] = (i==j ? 1.f : 0.f);
        }
    }
    return E;
}

std::vector<float>& Matrix::operator[](const int i) {
    assert(i>=0 && i<rows);
    return m[i];
}

Matrix Matrix::operator*(const Matrix& a) {
    assert(cols == a.rows);
    Matrix result(rows, a.cols);
    for (int i=0; i<rows; i++) {
        for (int j=0; j<a.cols; j++) {
            result.m[i][j] = 0.f;
            for (int k=0; k<cols; k++) {
                result.m[i][j] += m[i][k]*a.m[k][j];
            }
        }
    }
    return result;
}

Matrix Matrix::transpose() {
    Matrix result(cols, rows);
    for(int i=0; i<rows; i++)
        for(int j=0; j<cols; j++)
            result[j][i] = m[i][j];
    return result;
}

Matrix Matrix::inverse() {
    assert(rows==cols);
    // augmenting the square matrix with the identity matrix of the same dimensions a => [ai]
    Matrix result(rows, cols*2);
    for(int i=0; i<rows; i++)
        for(int j=0; j<cols; j++)
            result[i][j] = m[i][j];
    for(int i=0; i<rows; i++)
        result[i][i+cols] = 1;
    // first pass
    for (int i=0; i<rows-1; i++) {
        // normalize the first row
        for(int j=result.cols-1; j>=0; j--)
            result[i][j] /= result[i][i];
        for (int k=i+1; k<rows; k++) {
            float coeff = result[k][i];
            for (int j=0; j<result.cols; j++) {
                result[k][j] -= result[i][j]*coeff;
            }
        }
    }
    // normalize the last row
    for(int j=result.cols-1; j>=rows-1; j--)
        result[rows-1][j] /= result[rows-1][rows-1];
    // second pass
    for (int i=rows-1; i>0; i--) {
        for (int k=i-1; k>=0; k--) {
            float coeff = result[k][i];
            for (int j=0; j<result.cols; j++) {
                result[k][j] -= result[i][j]*coeff;
            }
        }
    }
    // cut the identity matrix back
    Matrix truncate(rows, cols);
    for(int i=0; i<rows; i++)
        for(int j=0; j<cols; j++)
            truncate[i][j] = result[i][j+cols];
    return truncate;
}

std::ostream& operator<<(std::ostream& s, Matrix& m) {
    for (int i=0; i<m.nrows(); i++)  {
        for (int j=0; j<m.ncols(); j++) {
            s << m[i][j];
            if (j<m.ncols()-1) s << "\t";
        }
        s << "\n";
    }
    return s;
}




Vec3f m2v(Matrix m) {
    return Vec3f(m[0][0]/m[3][0],
                 m[1][0]/m[3][0],
                 m[2][0]/m[3][0]);
}

Matrix v2m(Vec3f v) {
    Matrix m(4, 1);
    m[0][0] = v.x;
    m[1][0] = v.y;
    m[2][0] = v.z;
    m[3][0] = 1.f;
    return m;
}

Matrix viewport(int x, int y, int w, int h, int depth) {
    // создание матрицы в которой куб мировых координат [-1,1]*[-1,1]*[-1,1] отображается в куб экранных координат
    // (высота, ширина, глубина)
    Matrix m = Matrix::identity(4);
    m[0][3] = x+w/2.f;
    m[1][3] = y+h/2.f;
    m[2][3] = depth/2.f;
    
    m[0][0] = w/2.f;
    m[1][1] = h/2.f;
    m[2][2] = depth/2.f;
    return m;
}

Matrix lookAt(Vec3f eye, Vec3f center, Vec3f up) {
    Vec3f z = (eye-center).normalize();
    Vec3f x = (up^z).normalize();   // векторное произведение (пересечение)
    Vec3f y = z^x.normalize();
    Matrix res = Matrix::identity(4);
    for (int i=0; i<3; i++) {
        res[0][i] = x[i];
        res[1][i] = y[i];
        res[2][i] = z[i];
        res[3][i] = center[i];
    }
    return res;
}

Matrix projectionMatrix(float coeff) {
    Matrix projection = Matrix::identity(4);
    projection[3][2] = coeff;
    return projection;
}

Matrix rotateMatrix(float xRotate, float yRotate, float zRotate){
    Matrix xRotateMatrix = Matrix::identity(4);
    xRotateMatrix[0][0] = 1;
    xRotateMatrix[1][1] = cosf(xRotate);
    xRotateMatrix[2][2] = cosf(xRotate);
    xRotateMatrix[2][1] = -sinf(xRotate);
    xRotateMatrix[1][2] = sinf(xRotate);
    xRotateMatrix[3][3] = 1;
    
    Matrix yRotateMatrix = Matrix::identity(4);
    yRotateMatrix[0][0] = cosf(yRotate);
    yRotateMatrix[1][1] = 1;
    yRotateMatrix[2][2] = cosf(yRotate);
    yRotateMatrix[2][0] = sinf(yRotate);
    yRotateMatrix[0][2] = -sinf(yRotate);
    yRotateMatrix[3][3] = 1;
    
    Matrix zRotateMatrix = Matrix::identity(4);
    zRotateMatrix[0][0] = cosf(zRotate);
    zRotateMatrix[1][1] = cosf(zRotate);
    zRotateMatrix[2][2] = 1;
    zRotateMatrix[1][0] = -sinf(zRotate);
    zRotateMatrix[0][1] = sinf(zRotate);
    zRotateMatrix[3][3] = 1;
    
    return xRotateMatrix * yRotateMatrix * zRotateMatrix;
}
