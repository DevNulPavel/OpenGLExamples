#ifndef __MODEL_H__
#define __MODEL_H__

#include <vector>
#include "geometry.h"

class Model {
private:
	std::vector<Vec3f> verts_;
    std::vector<Vec2f> uvCoord_;
    std::vector<Vec3f> normales_;
	std::vector<std::vector<int> > vertexIndexes_;
    std::vector<std::vector<int> > textureIndexes_;
    std::vector<std::vector<int> > normalIndexes_;
public:
	Model(const char *filename);
	~Model();

    // вершины - колво
    int vertsCount();
    int uvCoordsCount();
    int normalesCount();
    // индексы - кол-во
    int trianglesCount();
    int texIndexesCount();
    int normalIndexesCount();
    
    // векторы индексов
    std::vector<int> vertexIndexes(int idx);
    std::vector<int> textureIndexes(int idx);
    std::vector<int> normalIndexes(int idx);
    // вершины
    Vec3f vert(int i);
    Vec2f uvCoord(int i);
    Vec3f normal(int i);
};

#endif //__MODEL_H__
