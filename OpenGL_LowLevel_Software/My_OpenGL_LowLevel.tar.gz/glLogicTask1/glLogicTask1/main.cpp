#include <vector>
#include <cmath>
#include <limits>
#include "tgaimage.h"
#include "model.h"
#include "geometry.h"

const int width  = 800;
const int height = 800;
const int depth  = 255;
//Vec3f lightDir = Vec3f(-0.5, -1, -0.5).normalize();
int shadowbufferOffsetVal = 7;
Vec3i lightPosition = Vec3i(3, 2, 4);
float ambientLightPower = 0.5;
float reflectionLightCoeff = 1;
float perspectiveCoeff = 1.0;
Vec3f eyePos = Vec3f(0, 1, 3);
Vec3f lookToPos = Vec3f(0, 0, 0);
Vec3f rotation = Vec3f(0, 0, 0);


Model* model = NULL;
TGAImage* texture = NULL;
TGAImage* normalMap = NULL;
TGAImage* specularMap = NULL;
TGAImage* surfScatMap = NULL;
int* zbuffer = NULL;
int* shadowBuffer = NULL;

void triangleToShadowMap(Vec3i t0, Vec3i t1, Vec3i t2) {
    
    if (t0.y == t1.y && t0.y == t2.y) return; // это не треугольник
    
    if (t0.y > t1.y){
        std::swap(t0, t1);
    }
    if (t0.y > t2.y){
        std::swap(t0, t2);
    }
    if (t1.y > t2.y){
        std::swap(t1, t2);
    }
    
    int total_height = t2.y - t0.y;
    for (int i = 0; i < total_height; i++) {
        
        bool second_half = i > (t1.y - t0.y) || (t1.y == t0.y);
        int segment_height = second_half ? (t2.y - t1.y) : (t1.y-t0.y);
        float alpha = (float)i / total_height;
        float beta  = (float)(i - (second_half ? (t1.y-t0.y) : 0)) / segment_height; // be careful: with above conditions no division by zero here
        
        // интерполяция пикселя
        Vec3i A = Vec3f(t0) + Vec3f(t2-t0)*alpha;
        Vec3i B = second_half ? (Vec3f(t1) + Vec3f(t2-t1)*beta) : (Vec3f(t0) + Vec3f(t1-t0)*beta);
        
        if (A.x > B.x){
            std::swap(A, B);
        }
        
        for (int j = A.x; j <= B.x; j++) {
            float phi = (B.x == A.x) ? 1.0 : (float)(j-A.x)/(float)(B.x-A.x);
            
            Vec3i pixelPos = Vec3f(A) + Vec3f(B-A) * phi;              // позиция пикселя
            int idx = pixelPos.x + pixelPos.y*width;
            
            // клиппинг границ экрана
            if ((pixelPos.x > width) || (pixelPos.y > height) || (pixelPos.x < 0) || (pixelPos.y < 0)){
                continue;
            }
            
            // если значение в буффере глубины меньше, чем значение глубины у пикселя
            // то обновим значение в буффере глубины + отрисуем этот пиксель
            // если нет, то не рисуем пиксель
            bool goodShadowBuffer = shadowBuffer[idx] < pixelPos.z;
            
            if (goodShadowBuffer) {
                shadowBuffer[idx] = fmin(pixelPos.z, 255);
            }
        }
    }
}


void triangle(TGAImage &image,
              Vec3i t0, Vec3i t1, Vec3i t2,
              Vec2i tex0, Vec2i tex1, Vec2i tex2,
              Vec3f n0, Vec3f n1, Vec3f n2,
              Vec3i shad0, Vec3i shad1, Vec3i shad2) {
    
    if (t0.y == t1.y && t0.y == t2.y) return; // это не треугольник

    if (t0.y > t1.y){
        std::swap(t0, t1);
        std::swap(tex0, tex1);
        std::swap(n0, n1);
        std::swap(shad0, shad1);
    }
    if (t0.y > t2.y){
        std::swap(t0, t2);
        std::swap(tex0, tex2);
        std::swap(n0, n2);
        std::swap(shad0, shad2);
    }
    if (t1.y > t2.y){
        std::swap(t1, t2);
        std::swap(tex1, tex2);
        std::swap(n1, n2);
        std::swap(shad1, shad2);
    }
  
    int total_height = t2.y - t0.y;
    for (int i = 0; i < total_height; i++) {
        
        bool second_half = i > (t1.y - t0.y) || (t1.y == t0.y);
        int segment_height = second_half ? (t2.y - t1.y) : (t1.y-t0.y);
        float alpha = (float)i / total_height;
        float beta  = (float)(i - (second_half ? (t1.y-t0.y) : 0)) / segment_height; // be careful: with above conditions no division by zero here
        
        // интерполяция пикселя
        Vec3i A = Vec3f(t0) + Vec3f(t2-t0)*alpha;
        Vec3i B = second_half ? (Vec3f(t1) + Vec3f(t2-t1)*beta) : (Vec3f(t0) + Vec3f(t1-t0)*beta);
        // интерполяция позиции в текстуре
        Vec2i uvA = tex0 + (tex2 - tex0) * alpha;
        Vec2i uvB = second_half ? (tex1 + (tex2 - tex1)*beta) : (tex0 + (tex1 - tex0) * beta);
        // интерполяция нормали
        Vec3f nA = n0 + (n2 - n0) * alpha;
        Vec3f nB = second_half ? (n1 + (n2 - n1)*beta) : (n0 + (n1 - n0) * beta);
        // интерполяция пикселя
        Vec3i shadA = Vec3f(shad0) + Vec3f(shad2-shad0)*alpha;
        Vec3i shadB = second_half ? (Vec3f(shad1) + Vec3f(shad2-shad1)*beta) : (Vec3f(shad0) + Vec3f(shad1-shad0)*beta);
        
        if (A.x > B.x){
            std::swap(A, B);
            std::swap(uvA, uvB);
            std::swap(nA, nB);
            std::swap(shadA, shadB);
        }
        
        for (int j = A.x; j <= B.x; j++) {
            float phi = (B.x == A.x) ? 1.0 : (float)(j-A.x)/(float)(B.x-A.x);
            
            Vec3i pixelPos = Vec3f(A) + Vec3f(B-A) * phi;              // позиция пикселя
            Vec2i uvPixelPos = uvA + (uvB - uvA) * phi;    // координата UV данного пикселя для текстуры
            Vec3f normalForPixel = Vec3f(nA) + Vec3f(nB - nA) * phi;   // нормаль данного пикселя
            Vec3i shadowPos = Vec3f(shadA) + Vec3f(shadB-shadA) * phi; // позиция пикселя тени

            // вычислим направление для точечного света для данного пикселя
            Vec3f lightVectorForPixel = Vec3f(lightPosition) - Vec3f(pixelPos);
            Vec3f lightDir = (lightVectorForPixel).normalize();

            
            // клиппинг границ экрана
            if ((pixelPos.x >= width) || (pixelPos.y >= height) || (pixelPos.x < 0) || (pixelPos.y < 0)){
                continue;
            }
            
            int idx = pixelPos.x + pixelPos.y*width;
            
            // #### Карта нормалей #####
            if (normalMap) {
                // дергаем изменение нормали из карты нормалей
                TGAColor normalMapColor = normalMap->get(uvPixelPos.x, uvPixelPos.y);
                float normalDisplaceX = (normalMapColor.r / 255.0) - 0.5;
                float normalDisplaceY = (normalMapColor.g / 255.0) - 0.5;
                float normalDisplaceZ = (normalMapColor.b / 255.0) - 0.5;
                // корректируем нормаль
                normalForPixel.x = -normalDisplaceX; // !!! ИНВЕРТИРОВАННАЯ НОРМАЛЬ !!!!
                normalForPixel.y = -normalDisplaceY;
                normalForPixel.z = -normalDisplaceZ;
                normalForPixel = normalForPixel.normalize();
            }
            
            // ##### Карта бликов ####
            float intensiveChange = 0.0;
            if (specularMap) {
                TGAColor specularLightColor = specularMap->get(uvPixelPos.x, uvPixelPos.y);
                float reflectValueInMap = specularLightColor.val; // значение в карте бликов (0-255)
                float reflectionCoeff = -(normalForPixel * (normalForPixel*lightDir*2.0) - lightDir).normalize().z; // коэффициент отражения в точке (0.0-1.0)
                reflectionCoeff = fmax(reflectionCoeff, 0.0);
                intensiveChange = pow(reflectionCoeff, reflectValueInMap) * reflectionLightCoeff;
            }
            
            
            // самозатенение из буффера тени
            bool shadowTest = false;
            float shadowChangeVal = 0;

            // клиппинг границ экрана
            if ((shadowPos.x <= width) && (shadowPos.y <= height) && (shadowPos.x >= 0) && (shadowPos.y >= 0)){
                int shadowIdx = shadowPos.x + shadowPos.y*width;
                // shadowBuffer[shadowIdx] - значение в буффере глубины тени
                // shadowPos.z - дистанция между источником света и данным пикселем
                int curValue = shadowBuffer[shadowIdx];
                if (curValue > shadowPos.z + shadowbufferOffsetVal) {
                    shadowChangeVal = -0.5;
//                    shadowTest = true;
                }
            }
            
            // интенсивность света для данного пикселя
            // (нормаль пикселя после интерполяции на вектор света)
            float lightIntensive = (normalForPixel * lightDir);     // для направленного света
            lightIntensive += intensiveChange;
            lightIntensive += ambientLightPower;
            lightIntensive += shadowChangeVal;
            lightIntensive = fmax(lightIntensive, 0.0); // ограничение
            
            // если значение в буффере глубины меньше, чем значение глубины у пикселя
            // то обновим значение в буффере глубины + отрисуем этот пиксель
            // если нет, то не рисуем пиксель
            // zbuffer[idx] - значение в буффере глубины
            // pixelPos.z - значение глубины пикселя
            bool goodZBuffer = zbuffer[idx] < pixelPos.z;
            
            if (goodZBuffer) {
                zbuffer[idx] = fmin(pixelPos.z, 255);
                
                // может у нас нет текстуры?
                TGAColor pixelColor;
                if (texture) {
                    pixelColor = texture->get(uvPixelPos.x, uvPixelPos.y);
                }else{
                    pixelColor = TGAColor(255, 255, 255, 255);
                }
                
                
                // обновляем интенсивность цвета пикселя в зависимости от его освещенности
                int red = pixelColor.r * lightIntensive;
                int green = pixelColor.g * lightIntensive;
                int blue = pixelColor.b * lightIntensive;
                
                pixelColor.r = red > 255 ? 255 : red;
                pixelColor.g = green > 255 ? 255 : green;
                pixelColor.b = blue > 255 ? 255 : blue;
                
                if (shadowTest == true) {
                    pixelColor = TGAColor(255, 255, 255, 255);
                }
                
                image.set(pixelPos.x, pixelPos.y, pixelColor);
            }
        }
    }
}

int main(int argc, char** argv) {

    // загрузка модели и текстуры
    model = new Model("african_head.obj");
    
    
    // ############## отрисовка тени #############
    
    // создаем буффер тени
    shadowBuffer = new int[width*height]; // такой же массив глубины, но рендерим будем из точки источника света
    for (int i = 0; i < width*height; i++) {
        int value = std::numeric_limits<int>::min();
        shadowBuffer[i] = value;
    }
    
    // !!! матрицы для тени
    Matrix shadowViewPort = viewport(width/8, height/8, width*3/4, height*3/4, depth);
    // матрица перспективы для тени
    Matrix shadowProjection = projectionMatrix(-perspectiveCoeff / lightPosition.z);
    // создаем матрицу вида из точки с тенью
//    Matrix shadowViewMatrix = lookAt(lightDir * (-1.0), lookToPos, Vec3f(0.0, 1.0, 0.0));
    Matrix shadowViewMatrix = lookAt(lightPosition, lookToPos, Vec3f(0.0, 1.0, 0.0));
    // матрица модели (вращение, скейл и тд)
    Matrix shadowModelMatrix = rotateMatrix(rotation.x, rotation.y, rotation.z);
    // результат
    Matrix generateShadowMatrix = shadowViewPort * shadowProjection * shadowViewMatrix * shadowModelMatrix;
    
    // генерация в буффер тени
    for (int i = 0; i < model->trianglesCount(); i++) {
        std::vector<int> vertexIndexes = model->vertexIndexes(i);
        
        Vec3i screenCoords[3];
        
        for (int j = 0; j < 3; j++) {
            // дергаем вершину треугольника
            Vec3f v = model->vert(vertexIndexes[j]);
            // приводим эту вершину к нашему размеру экрана
            // перемножаем матрицу вида на матрицу проекции с точкой
            screenCoords[j] = m2v(generateShadowMatrix * v2m(v));
        }
        
        // координаты треугольника
        Vec3i t1 = screenCoords[0];
        Vec3i t2 = screenCoords[1];
        Vec3i t3 = screenCoords[2];
        
        // отрисовка треугольника со всеми параметрами
        triangleToShadowMap(t1, t2, t3);
    }
    // сохраним буффер глубины
    TGAImage shadowImage(width, height, TGAImage::GRAYSCALE);
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            shadowImage.set(i, j, TGAColor(shadowBuffer[i + j*width], 1));
        }
    }
    shadowImage.flip_vertically(); // i want to have the origin at the left bottom corner of the image
    shadowImage.write_tga_file("shadowBuffer.tga");
    
    
    
    // #############################################
    // ############## отрисовка модели #############
    // #############################################
    
    // буффер глубины
    zbuffer = new int[width*height]; // массив глубины (одномерный, с конвертацией)
    for (int i = 0; i < width*height; i++) {
        int value = std::numeric_limits<int>::min();
        zbuffer[i] = value; // заполняем минимальным значением
    }
    
    // диффузная текстура
    texture = new TGAImage();
    texture->read_tga_file("african_head_diffuse.tga");
    texture->flip_vertically();
    
    // текстура нормалей
    normalMap = new TGAImage();
    normalMap->read_tga_file("african_head_nm.tga");
    normalMap->flip_vertically();
    
    // карта бликов и вета
    specularMap = new TGAImage();
    specularMap->read_tga_file("african_head_spec.tga");
    specularMap->flip_vertically();
    
    
    // матрица преобразования в экранные координаты
    Matrix viewPort   = viewport(width/8, height/8, width*3/4, height*3/4, depth);
    // матрица перспективы
    Matrix projection = projectionMatrix(-perspectiveCoeff / eyePos.z);
    // матрица перехода к камере
    Matrix viewMatrix = lookAt(eyePos, lookToPos, Vec3f(0.0, 1.0, 0.0));
    // матрица модели (вращение, скейл и тд)
    Matrix modelMatrix = rotateMatrix(rotation.x, rotation.y, rotation.z);
    // результат
    Matrix resultVertexMatrix = viewPort * projection * viewMatrix * modelMatrix;
    
//    // для тени
    Matrix lightConvertProj = (shadowProjection * shadowViewMatrix * viewMatrix.inverse());
    Matrix resultShadowMatrix = viewPort * lightConvertProj * viewMatrix * modelMatrix;
    
    
    // отрисовка модели
    TGAImage image(width, height, TGAImage::RGB);
    for (int i = 0; i < model->trianglesCount(); i++) {
        std::vector<int> vertexIndexes = model->vertexIndexes(i);
        std::vector<int> textCoordIndexes = model->textureIndexes(i);
        std::vector<int> normalIndexes = model->normalIndexes(i);
        
        Vec3i screenCoords[3];
        Vec2i textureCoords[3];
        Vec3f normalValues[3];
        Vec3i shadowCoords[3];
        
        for (int j = 0; j < 3; j++) {
            // дергаем вершину треугольника
            Vec3f v = model->vert(vertexIndexes[j]);
            // приводим эту вершину к нашему размеру экрана
            // перемножаем матрицу вида на матрицу проекции с точкой
            screenCoords[j] = m2v(resultVertexMatrix * v2m(v));
            // без матрицы
            // координаты вершин в диапазоне от -1 до 1, поэтому мы приводим их к размеру нашей картинки, 0-800 и тд
//            screenCoords[j] = Vec3i((v.x + 1.0)*width/2.0, (v.y+1.0)*height/2.0, (v.z+1.0)*depth/2.0);
            
            
            // вычисляем фактические координаты UV в картинке
            Vec2f texturePos = model->uvCoord(textCoordIndexes[j]);
            // приводим к размеру текстуры
            int texWidth = 0;
            int texHeight = 0;
            if (texture) {
                texWidth = texture->get_width();
                texHeight = texture->get_height();
            }
            textureCoords[j] = Vec2i(texturePos.x * texWidth, texturePos.y * texHeight);
            
            
            // нормаль к вершине
            Vec3f normal = model->normal(normalIndexes[j]);
            normal = normal * (-1.0);   // вывернем нормаль, но правильно ли это
            normalValues[j] = normal;
            
            // вычисляем координату для текстуры теней
            Vec3f shadowPos = m2v(resultShadowMatrix * v2m(v));
            shadowCoords[j] = shadowPos;
        }
        
        // координаты треугольника
        Vec3i t1 = screenCoords[0];
        Vec3i t2 = screenCoords[1];
        Vec3i t3 = screenCoords[2];
        
        // координаты треугольника в текстуре
        Vec2i tex1 = textureCoords[0];
        Vec2i tex2 = textureCoords[1];
        Vec2i tex3 = textureCoords[2];
        
        // нормали к вершинам
        Vec3f n1 = normalValues[0];
        Vec3f n2 = normalValues[1];
        Vec3f n3 = normalValues[2];
        
        // позиции в карте теней
        Vec3i shad1 = shadowCoords[0];
        Vec3i shad2 = shadowCoords[1];
        Vec3i shad3 = shadowCoords[2];
        
        // отрисовка треугольника со всеми параметрами
        triangle(image, t1, t2, t3, tex1, tex2, tex3, n1, n2, n3, shad1, shad2, shad3);
    }

    image.flip_vertically(); // i want to have the origin at the left bottom corner of the image
    image.write_tga_file("output.tga");

    // сохраним буффер глубины
    TGAImage zbimage(width, height, TGAImage::GRAYSCALE);
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            zbimage.set(i, j, TGAColor(zbuffer[i + j*width], 1));
        }
    }
    zbimage.flip_vertically(); // i want to have the origin at the left bottom corner of the image
    zbimage.write_tga_file("zbuffer.tga");

    delete model;
    delete [] zbuffer;
    delete [] shadowBuffer;
    delete texture;
    delete normalMap;
    delete specularMap;
    return 0;
}

