// -------------------------------------------------------------------------------------------------
//  IntroLayer.h
//  LightTest
//
//  Created by Capsaic (SmashRiot.com | @SmashRiot) on 2013/08/12.
// -------------------------------------------------------------------------------------------------


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface IntroLayer : CCLayer
{
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
