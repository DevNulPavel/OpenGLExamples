//
//  CSEColorRamp.m
//  CocosShaderEffects
//
//  Created by Ray Wenderlich on 3/20/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CSEColorRamp.h"


@implementation CSEColorRamp {
    CCSprite *sprite;  //1
    int colorRampUniformLocation;  //2
    CCTexture2D *colorRampTexture; //3
}

- (id)init
{
    self = [super init];
    if (self) {
        // 1 здесь, мы создаем спрайт
        sprite = [CCSprite spriteWithFile:@"Default.png"];
        sprite.anchorPoint = CGPointZero;
        sprite.rotation = 90;
        sprite.position = ccp(0, 320);
        [self addChild:sprite];
        
        // 2 загружаем шейдеры
        const GLchar * fragmentSource = (GLchar*) [[NSString stringWithContentsOfFile:[CCFileUtils fullPathFromRelativePath:@"CSEColorRamp.fsh"] encoding:NSUTF8StringEncoding error:nil] UTF8String];
        sprite.shaderProgram = [[CCGLProgram alloc] initWithVertexShaderByteArray:ccPositionTextureA8Color_vert
                                       fragmentShaderByteArray:fragmentSource];
        [sprite.shaderProgram addAttribute:kCCAttributeNamePosition index:kCCVertexAttrib_Position]; // добавляем аттрибуты
        [sprite.shaderProgram addAttribute:kCCAttributeNameTexCoord index:kCCVertexAttrib_TexCoords]; //
        [sprite.shaderProgram link]; // ликуем (компилим шейдеры??)
        [sprite.shaderProgram updateUniforms]; // обновляем константные матрицы (юниформы)
        
        // 3 получаем расположение второй тектуры в шейдере,
        colorRampUniformLocation = glGetUniformLocation(sprite.shaderProgram->program_, "u_colorRampTexture");
        // назначаем ей индекс 1, 0 индекс - это текстура спрайта
        glUniform1i(colorRampUniformLocation, 1);
        
        // 4 создаем текстуру
        colorRampTexture = [[CCTextureCache sharedTextureCache] addImage:@"colorRamp.png"];
        [colorRampTexture setAliasTexParameters]; // отрубаем сглаживание, нужны исходные значения текстуры
        
        // 5 компилим шейдер??
        [sprite.shaderProgram use];
        // назначаем вторую текстуру в шейдере, как созданную, возвращаемся назад к нашей текстуре
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, [colorRampTexture name]);
        glActiveTexture(GL_TEXTURE0);
    }
    return self;
}

@end
